"use strict";(()=>{var e={};e.id=505,e.ids=[505],e.modules={20399:e=>{e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},30517:e=>{e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},78893:e=>{e.exports=require("buffer")},84770:e=>{e.exports=require("crypto")},92048:e=>{e.exports=require("fs")},19801:e=>{e.exports=require("os")},55315:e=>{e.exports=require("path")},76162:e=>{e.exports=require("stream")},21764:e=>{e.exports=require("util")},8678:e=>{e.exports=import("pg")},34081:(e,t,a)=>{a.a(e,async(e,r)=>{try{a.r(t),a.d(t,{originalPathname:()=>D,patchFetch:()=>l,requestAsyncStorage:()=>c,routeModule:()=>u,serverHooks:()=>m,staticGenerationAsyncStorage:()=>p});var n=a(49303),s=a(88716),o=a(60670),d=a(56011),i=e([d]);d=(i.then?(await i)():i)[0];let u=new n.AppRouteRouteModule({definition:{kind:s.x.APP_ROUTE,page:"/api/maintenance-rounds/[batchId]/[roundDate]/route",pathname:"/api/maintenance-rounds/[batchId]/[roundDate]",filename:"route",bundlePath:"app/api/maintenance-rounds/[batchId]/[roundDate]/route"},resolvedPagePath:"E:\\Web Project\\Nextjs\\HoaGiangManager\\app\\api\\maintenance-rounds\\[batchId]\\[roundDate]\\route.ts",nextConfigOutput:"standalone",userland:d}),{requestAsyncStorage:c,staticGenerationAsyncStorage:p,serverHooks:m}=u,D="/api/maintenance-rounds/[batchId]/[roundDate]/route";function l(){return(0,o.patchFetch)({serverHooks:m,staticGenerationAsyncStorage:p})}r()}catch(e){r(e)}})},56011:(e,t,a)=>{a.a(e,async(e,r)=>{try{a.r(t),a.d(t,{GET:()=>i});var n=a(87070),s=a(96899),o=a(97395),d=e([s,o]);async function i(e,{params:t}){try{let{user:a,error:r}=await (0,s.Y)(e);if(!a)return n.NextResponse.json({status:!1,error:r||"Unauthorized"},{status:401});let{batchId:d,roundDate:i}=t;if(!d||!i)return n.NextResponse.json({status:!1,error:"BatchId v\xe0 RoundDate l\xe0 bắt buộc"},{status:400});let l=i;if(!/^\d{4}-\d{2}-\d{2}$/.test(i))try{let e=new Date(i);if(isNaN(e.getTime()))return n.NextResponse.json({status:!1,error:"RoundDate kh\xf4ng hợp lệ"},{status:400});let t=e.getFullYear(),a=String(e.getMonth()+1).padStart(2,"0"),r=String(e.getDate()).padStart(2,"0");l=`${t}-${a}-${r}`}catch(e){return n.NextResponse.json({status:!1,error:"RoundDate kh\xf4ng hợp lệ"},{status:400})}console.log("Querying events for batch:",d,"roundDate:",l);let u=await o.Z.query(`
      SELECT 
        e."ID" as id,
        e."Title" as title,
        e."DeviceID" as "deviceId",
        d."Name" as "deviceName",
        d."Serial" as "deviceSerial",
        e."EventTypeID" as "eventTypeId",
        et."Name" as "eventTypeName",
        e."Description" as description,
        e."Status" as status,
        e."EventDate" as "eventDate",
        e."StartDate" as "startDate",
        e."EndDate" as "endDate",
        e."StaffID" as "staffId",
        s."Name" as "staffName",
        e."RelatedReportID" as "relatedReportId",
        e."Notes" as notes,
        e."Metadata" as metadata,
        e."CreatedAt" as "createdAt",
        e."UpdatedAt" as "updatedAt"
      FROM "Event" e
      LEFT JOIN "Device" d ON e."DeviceID" = d."ID"
      LEFT JOIN "EventType" et ON e."EventTypeID" = et."ID"
      LEFT JOIN "Staff" s ON e."StaffID" = s."ID"
      WHERE e."Metadata"::text LIKE $1
        AND e."Status" = 'completed'
      ORDER BY d."Name", e."ID"
      `,[`%${d}%`]);console.log("All completed events with batchId:",u.rows.length);let c=u.rows.filter(e=>{let t=null;if(e.metadata){if("string"==typeof e.metadata)try{t=JSON.parse(e.metadata)}catch(e){t=null}else t=e.metadata}if(!t||t.maintenanceBatchId!==d)return!1;let a=e.endDate||e.eventDate||e.startDate;return(a?new Date(a).toISOString().split("T")[0]:null)===l});console.log("Filtered events by roundDate:",c.length);let p=c.map(e=>{let t=null;if(e.metadata){if("string"==typeof e.metadata)try{t=JSON.parse(e.metadata)}catch(e){t=null}else t=e.metadata}return t&&t.maintenanceBatchId===d?{id:e.id,title:e.title,deviceId:e.deviceId,deviceName:e.deviceName,deviceSerial:e.deviceSerial,eventTypeId:e.eventTypeId,eventTypeName:e.eventTypeName,description:e.description,status:e.status,eventDate:e.eventDate?new Date(e.eventDate).toISOString().split("T")[0]:null,startDate:e.startDate?new Date(e.startDate).toISOString().split("T")[0]:null,endDate:e.endDate?new Date(e.endDate).toISOString().split("T")[0]:null,staffId:e.staffId,staffName:e.staffName,relatedReportId:e.relatedReportId,notes:e.notes,maintenanceBatchId:t.maintenanceBatchId,maintenanceType:t.maintenanceType||null,maintenanceProvider:t.maintenanceProvider||null,createdAt:e.createdAt?new Date(e.createdAt).toISOString():null,updatedAt:e.updatedAt?new Date(e.updatedAt).toISOString():null}:(console.log("Event filtered out - metadata mismatch:",{eventId:e.id,metadataBatchId:t?.maintenanceBatchId,expectedBatchId:d}),null)}).filter(e=>null!==e),m=p.length>0?{batchId:d,title:p[0].title||`Bảo tr\xec - ${i}`,maintenanceType:p[0].maintenanceType,maintenanceProvider:p[0].maintenanceProvider}:{batchId:d,title:`Bảo tr\xec - ${i}`,maintenanceType:null,maintenanceProvider:null},D=p.map(e=>e.relatedReportId).filter(e=>null!=e),I=new Date(i);I.setHours(0,0,0,0);let h=new Date(I);h.setDate(h.getDate()+1);let v=[];v=(v=(await o.Z.query(`
      SELECT 
        dr."ID" as id,
        dr."DamageContent" as "damageContent",
        dr."Status" as status,
        dr."ReportDate" as "reportDate",
        dr."CompletedDate" as "completedDate",
        reporter."Name" as "reporterName",
        handler."Name" as "handlerName"
      FROM "DamageReport" dr
      LEFT JOIN "Staff" reporter ON dr."ReporterID" = reporter."ID"
      LEFT JOIN "Staff" handler ON dr."HandlerID" = handler."ID"
      WHERE (
        dr."MaintenanceBatchId" = $1
        AND dr."CompletedDate" IS NOT NULL
        AND DATE(dr."CompletedDate") = $2::date
      )
      OR (
        dr."ID" = ANY($3::int[])
      )
      `,[d,i,D.length>0?D:[0]])).rows.map(e=>({id:e.id,damageContent:e.damageContent,status:parseInt(e.status),reportDate:e.reportDate?new Date(e.reportDate).toISOString().split("T")[0]:null,completedDate:e.completedDate?new Date(e.completedDate).toISOString().split("T")[0]:null,reporterName:e.reporterName,handlerName:e.handlerName}))).filter((e,t,a)=>t===a.findIndex(t=>t.id===e.id));let N={roundDate:i,batchInfo:m,totalDevices:p.length,completedDevices:p.filter(e=>"completed"===e.status).length,events:p,damageReports:v};return n.NextResponse.json({status:!0,data:N})}catch(e){return console.error("Get maintenance round detail error:",e),n.NextResponse.json({status:!1,error:e.message||"Đ\xe3 xảy ra lỗi khi lấy chi tiết đợt bảo tr\xec"},{status:500})}}[s,o]=d.then?(await d)():d,r()}catch(e){r(e)}})},73840:(e,t,a)=>{a.d(t,{RA:()=>d,WX:()=>i});var r=a(41482),n=a.n(r);let s=process.env.JWT_SECRET||"your-secret-key-change-this-in-production",o=process.env.JWT_EXPIRES_IN||"24h",d=e=>{if(!s)throw Error("JWT_SECRET is not configured");return n().sign(e,s,{expiresIn:o})},i=e=>{try{return n().verify(e,s)}catch(e){throw Error("Invalid token")}}},96899:(e,t,a)=>{a.a(e,async(e,r)=>{try{a.d(t,{Y:()=>d}),a(87070);var n=a(73840),s=a(97395),o=e([s]);async function d(e){try{let t=e.headers.get("authorization");if(!t||!t.startsWith("Bearer "))return{user:null,error:"No token provided"};let a=t.substring(7),r=(0,n.WX)(a),o=await s.Z.query(`SELECT u."Id", u."Email", u."NormalizedEmail"
       FROM "AspNetUsers" u
       WHERE u."Id" = $1`,[r.userId]);if(0===o.rows.length)return{user:null,error:"User not found"};let d=(await s.Z.query(`SELECT r."Name"
       FROM "AspNetRoles" r
       INNER JOIN "AspNetUserRoles" ur ON r."Id" = ur."RoleId"
       WHERE ur."UserId" = $1`,[r.userId])).rows.map(e=>e.Name);return{user:{userId:r.userId,email:r.email,roles:d},error:null}}catch(e){return console.error("Authentication error:",e.message||e),{user:null,error:e.message||"Invalid token"}}}s=(o.then?(await o)():o)[0],r()}catch(e){r(e)}})},97395:(e,t,a)=>{a.a(e,async(e,r)=>{try{a.d(t,{I:()=>c,Z:()=>u});var n=a(8678),s=a(16636),o=a.n(s),d=e([n]);n=(d.then?(await d)():d)[0],o().config(),o().config({path:".env.local",override:!0}),n.types.setTypeParser(1082,e=>e);let i=process.env.DATABASE_URL?.includes("localhost")||process.env.DATABASE_URL?.includes("127.0.0.1"),l=new n.Pool({connectionString:process.env.DATABASE_URL,ssl:!i&&{rejectUnauthorized:!1}});l.on("connect",e=>{e.query("SET TIME ZONE 'Asia/Ho_Chi_Minh'")});let u=l,c=async(e,t)=>{Date.now();try{let a=await l.query(e,t);return Date.now(),a}catch(t){throw console.error("Database query error",{text:e,error:t}),t}};r()}catch(e){r(e)}})}};var t=require("../../../../../webpack-runtime.js");t.C(e);var a=e=>t(t.s=e),r=t.X(0,[8948,5972,2695],()=>a(34081));module.exports=r})();