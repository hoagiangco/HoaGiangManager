"use strict";(()=>{var e={};e.id=1798,e.ids=[1798],e.modules={20399:e=>{e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},30517:e=>{e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},84770:e=>{e.exports=require("crypto")},92048:e=>{e.exports=require("fs")},19801:e=>{e.exports=require("os")},55315:e=>{e.exports=require("path")},8678:e=>{e.exports=import("pg")},87799:(e,t,a)=>{a.a(e,async(e,r)=>{try{a.r(t),a.d(t,{originalPathname:()=>u,patchFetch:()=>d,requestAsyncStorage:()=>c,routeModule:()=>l,serverHooks:()=>h,staticGenerationAsyncStorage:()=>g});var i=a(49303),n=a(88716),o=a(60670),p=a(77162),s=e([p]);p=(s.then?(await s)():s)[0];let l=new i.AppRouteRouteModule({definition:{kind:n.x.APP_ROUTE,page:"/api/weekly-schedule/export/route",pathname:"/api/weekly-schedule/export",filename:"route",bundlePath:"app/api/weekly-schedule/export/route"},resolvedPagePath:"E:\\Web Project\\Nextjs\\HoaGiangManager\\app\\api\\weekly-schedule\\export\\route.ts",nextConfigOutput:"standalone",userland:p}),{requestAsyncStorage:c,staticGenerationAsyncStorage:g,serverHooks:h}=l,u="/api/weekly-schedule/export/route";function d(){return(0,o.patchFetch)({serverHooks:h,staticGenerationAsyncStorage:g})}r()}catch(e){r(e)}})},77162:(e,t,a)=>{a.a(e,async(e,r)=>{try{a.r(t),a.d(t,{GET:()=>s});var i=a(87070),n=a(36299),o=e([n]);let d=new(n=(o.then?(await o)():o)[0]).Y,l=["Thứ 2","Thứ 3","Thứ 4","Thứ 5","Thứ 6","Thứ 7","Chủ Nhật"];function p(e,t){let a=new Date(e+"T00:00:00Z");return a.setUTCDate(a.getUTCDate()+t),`${String(a.getUTCDate()).padStart(2,"0")}/${String(a.getUTCMonth()+1).padStart(2,"0")}/${a.getUTCFullYear()}`}async function s(e){try{let{searchParams:t}=new URL(e.url),a=t.get("weekStart"),r=t.get("departmentIds");if(!a)return i.NextResponse.json({status:!1,error:"Missing weekStart"},{status:400});let o=n.Y.getMondayOf(a),s=r?r.split(",").map(Number).filter(Boolean):void 0,c=await d.getForExport(o,s),g=await d.getWeeklyMeta(o),h=g.note,u=g.creatorSignatureUrl,x=g.creatorName,m=`Từ ng\xe0y ${p(o,0)} đến ${p(o,6)}`,f=c.map(e=>e.departmentName.toUpperCase()).join(", "),w=`LỊCH L\xc0M VIỆC TUẦN BP. ${f}`,b=`
      <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body { font-family: Arial, sans-serif; font-size: 11px; background: #fff; color: #000; }
        .schedule-wrapper { padding: 10px; }
        .print-header { text-align: center; margin-bottom: 8px; }
        .print-header h2 { font-size: 14px; font-weight: bold; text-transform: uppercase; margin-bottom: 2px; }
        .print-header p { font-size: 12px; font-weight: bold; }
        table { width: 100%; border-collapse: collapse; }
        th, td { border: 1px solid #555; padding: 5px 6px; vertical-align: top; }
        th { background: #b8cce4; text-align: center; font-weight: bold; font-size: 11px; }
        th.date-row { background: #dce6f1; font-weight: normal; font-size: 10px; }
        .dept-header td { background: #dce6f1; font-weight: bold; text-align: left; font-size: 11px; padding: 4px 6px; }
        .staff-name { min-width: 120px; font-weight: 600; height: 60px; vertical-align: middle; }
        .day-cell { text-align: center; white-space: pre-wrap; min-width: 70px; line-height: 1.4; height: 60px; vertical-align: middle; }
        .footer-note { font-weight: bold; margin-top: 15px; font-size: 12px; white-space: pre-wrap; }
        .footer-signatures { display: flex; justify-content: space-between; margin-top: 30px; font-weight: bold; font-size: 12px; page-break-inside: avoid; }
        .footer-signatures > div { width: 30%; text-align: center; }
        .signature-space { width: 100%; height: 65px; display: flex; align-items: center; justify-content: center; margin-top: 4px; }
        .signature-img { max-height: 60px; max-width: 160px; object-fit: contain; }
        @media print {
          body { font-size: 10px; }
          @page { size: landscape; margin: 8mm; }
          th { background: #b8cce4 !important; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
          th.date-row { background: #dce6f1 !important; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
          .dept-header td { background: #dce6f1 !important; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
          .footer-note { font-size: 10px; }
          .footer-signatures { font-size: 10px; margin-top: 20px; }
        }
      </style>
    `,y=l.map(e=>`<th>${e}</th>`).join(""),v=Array.from({length:7},(e,t)=>`<th class="date-row">${function(e,t){let a=new Date(e+"T00:00:00Z");return a.setUTCDate(a.getUTCDate()+t),`${String(a.getUTCDate()).padStart(2,"0")}/${String(a.getUTCMonth()+1).padStart(2,"0")}/${String(a.getUTCFullYear()).slice(2)}`}(o,t)}</th>`).join(""),$=c.map(e=>{let t=`<tr class="dept-header"><td colspan="8">${e.departmentName.toUpperCase()}</td></tr>`,a=e.staff.map(e=>{let t=Array.from({length:7},(t,a)=>{let r=e.days[a+1],i=r?.content||"",n=r?.note||"",o=n?`${i}
${n}`:i;return`<td class="day-cell">${o.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/\n/g,"<br/>")}</td>`}).join("");return`<tr>
          <td class="staff-name">${e.staffName.replace(/&/g,"&amp;")}</td>
          ${t}
        </tr>`}).join("");return t+a}).join(""),T=`<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1"/>
  <title>${w} - ${m}</title>
  ${b}
</head>
<body>
  <div class="schedule-wrapper">
    <div class="print-header">
      <h2>${w}</h2>
      <p>${m}</p>
    </div>
    <table>
      <thead>
        <tr>
          <th rowspan="2">Họ v\xe0 t\xean</th>
          ${y}
        </tr>
        <tr>
          ${v}
        </tr>
      </thead>
      <tbody>
        ${$}
      </tbody>
    </table>
    
    ${h?`<div class="footer-note">Lưu \xfd:<br/>${h.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/\n/g,"<br/>")}</div>`:""}
    
    <div class="footer-signatures">
      <div>Duyệt</div>
      <div>
        Người lập
        <div class="signature-space">
          ${u?`<img src="${u}" class="signature-img" alt="Chữ k\xfd người lập" />`:""}
        </div>
        ${x?`<div>${x.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;")}</div>`:""}
      </div>
    </div>
  </div>
  <script>
    window.onload = () => {
      window.print();
    };
    window.onafterprint = () => {
      window.close();
    };
  </script>
</body>
</html>`;return new i.NextResponse(T,{headers:{"Content-Type":"text/html; charset=utf-8"}})}catch(e){return i.NextResponse.json({status:!1,error:e.message},{status:500})}}r()}catch(e){r(e)}})}};var t=require("../../../../webpack-runtime.js");t.C(e);var a=e=>t(t.s=e),r=t.X(0,[8948,5972,6299],()=>a(87799));module.exports=r})();