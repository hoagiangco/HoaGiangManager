"use strict";(()=>{var e={};e.id=9985,e.ids=[9985],e.modules={20399:e=>{e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},30517:e=>{e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},78893:e=>{e.exports=require("buffer")},84770:e=>{e.exports=require("crypto")},92048:e=>{e.exports=require("fs")},19801:e=>{e.exports=require("os")},55315:e=>{e.exports=require("path")},76162:e=>{e.exports=require("stream")},21764:e=>{e.exports=require("util")},8678:e=>{e.exports=import("pg")},58178:(e,t,a)=>{a.a(e,async(e,r)=>{try{a.r(t),a.d(t,{originalPathname:()=>h,patchFetch:()=>u,requestAsyncStorage:()=>l,routeModule:()=>c,serverHooks:()=>I,staticGenerationAsyncStorage:()=>p});var n=a(49303),s=a(88716),o=a(60670),i=a(1170),d=e([i]);i=(d.then?(await d)():d)[0];let c=new n.AppRouteRouteModule({definition:{kind:s.x.APP_ROUTE,page:"/api/events/batch/[batchId]/route",pathname:"/api/events/batch/[batchId]",filename:"route",bundlePath:"app/api/events/batch/[batchId]/route"},resolvedPagePath:"E:\\Web Project\\Nextjs\\HoaGiangManager\\app\\api\\events\\batch\\[batchId]\\route.ts",nextConfigOutput:"standalone",userland:i}),{requestAsyncStorage:l,staticGenerationAsyncStorage:p,serverHooks:I}=c,h="/api/events/batch/[batchId]/route";function u(){return(0,o.patchFetch)({serverHooks:I,staticGenerationAsyncStorage:p})}r()}catch(e){r(e)}})},1170:(e,t,a)=>{a.a(e,async(e,r)=>{try{a.r(t),a.d(t,{GET:()=>d});var n=a(87070),s=a(96899),o=a(97395),i=e([s,o]);async function d(e,{params:t}){try{let{user:a,error:r}=await (0,s.Y)(e);if(!a)return n.NextResponse.json({status:!1,error:r||"Unauthorized"},{status:401});let{batchId:i}=t;if(!i)return n.NextResponse.json({status:!1,error:"BatchId l\xe0 bắt buộc"},{status:400});let d=(await o.Z.query(`
      SELECT 
        e."ID" as id,
        e."Title" as title,
        e."DeviceID" as "deviceId",
        d."Name" as "deviceName",
        e."EventTypeID" as "eventTypeId",
        et."Name" as "eventTypeName",
        e."Description" as description,
        e."Status" as status,
        e."EventDate" as "eventDate",
        e."StartDate" as "startDate",
        e."EndDate" as "endDate",
        e."StaffID" as "staffId",
        s."Name" as "staffName",
        e."Metadata" as metadata,
        e."RelatedReportID" as "relatedReportId",
        e."CreatedAt" as "createdAt",
        e."UpdatedAt" as "updatedAt"
      FROM "Event" e
      LEFT JOIN "Device" d ON e."DeviceID" = d."ID"
      LEFT JOIN "EventType" et ON e."EventTypeID" = et."ID"
      LEFT JOIN "Staff" s ON e."StaffID" = s."ID"
      WHERE e."Metadata"::text LIKE $1
      ORDER BY e."EventDate" DESC, e."CreatedAt" DESC
      `,[`%${i}%`])).rows.map(e=>{let t=null;if(e.metadata){if("string"==typeof e.metadata)try{t=JSON.parse(e.metadata)}catch(e){t=null}else t=e.metadata}return t&&t.maintenanceBatchId===i?{id:e.id,title:e.title,deviceId:e.deviceId,deviceName:e.deviceName,eventTypeId:e.eventTypeId,eventTypeName:e.eventTypeName,description:e.description,status:e.status,eventDate:e.eventDate?new Date(e.eventDate).toISOString().split("T")[0]:null,startDate:e.startDate?new Date(e.startDate).toISOString().split("T")[0]:null,endDate:e.endDate?new Date(e.endDate).toISOString().split("T")[0]:null,staffId:e.staffId,staffName:e.staffName,maintenanceBatchId:t.maintenanceBatchId,maintenanceType:t.maintenanceType||null,maintenanceProvider:t.maintenanceProvider||null,relatedReportId:e.relatedReportId||null,createdAt:e.createdAt?new Date(e.createdAt).toISOString():null,updatedAt:e.updatedAt?new Date(e.updatedAt).toISOString():null}:null}).filter(e=>null!==e);return n.NextResponse.json({status:!0,data:d})}catch(e){return console.error("Get batch events error:",e),n.NextResponse.json({status:!1,error:e.message||"Đ\xe3 xảy ra lỗi khi lấy danh s\xe1ch event của batch"},{status:500})}}[s,o]=i.then?(await i)():i,r()}catch(e){r(e)}})},73840:(e,t,a)=>{a.d(t,{RA:()=>i,WX:()=>d});var r=a(41482),n=a.n(r);let s=process.env.JWT_SECRET||"your-secret-key-change-this-in-production",o=process.env.JWT_EXPIRES_IN||"24h",i=e=>{if(!s)throw Error("JWT_SECRET is not configured");return n().sign(e,s,{expiresIn:o})},d=e=>{try{return n().verify(e,s)}catch(e){throw Error("Invalid token")}}},96899:(e,t,a)=>{a.a(e,async(e,r)=>{try{a.d(t,{Y:()=>i}),a(87070);var n=a(73840),s=a(97395),o=e([s]);async function i(e){try{let t=e.headers.get("authorization");if(!t||!t.startsWith("Bearer "))return{user:null,error:"No token provided"};let a=t.substring(7),r=(0,n.WX)(a),o=await s.Z.query(`SELECT u."Id", u."Email", u."NormalizedEmail"
       FROM "AspNetUsers" u
       WHERE u."Id" = $1`,[r.userId]);if(0===o.rows.length)return{user:null,error:"User not found"};let i=(await s.Z.query(`SELECT r."Name"
       FROM "AspNetRoles" r
       INNER JOIN "AspNetUserRoles" ur ON r."Id" = ur."RoleId"
       WHERE ur."UserId" = $1`,[r.userId])).rows.map(e=>e.Name);return{user:{userId:r.userId,email:r.email,roles:i},error:null}}catch(e){return console.error("Authentication error:",e.message||e),{user:null,error:e.message||"Invalid token"}}}s=(o.then?(await o)():o)[0],r()}catch(e){r(e)}})},97395:(e,t,a)=>{a.a(e,async(e,r)=>{try{a.d(t,{I:()=>l,Z:()=>c});var n=a(8678),s=a(16636),o=a.n(s),i=e([n]);n=(i.then?(await i)():i)[0],o().config(),o().config({path:".env.local",override:!0}),n.types.setTypeParser(1082,e=>e);let d=process.env.DATABASE_URL?.includes("localhost")||process.env.DATABASE_URL?.includes("127.0.0.1"),u=new n.Pool({connectionString:process.env.DATABASE_URL,ssl:!d&&{rejectUnauthorized:!1}});u.on("connect",e=>{e.query("SET TIME ZONE 'Asia/Ho_Chi_Minh'")});let c=u,l=async(e,t)=>{Date.now();try{let a=await u.query(e,t);return Date.now(),a}catch(t){throw console.error("Database query error",{text:e,error:t}),t}};r()}catch(e){r(e)}})}};var t=require("../../../../../webpack-runtime.js");t.C(e);var a=e=>t(t.s=e),r=t.X(0,[8948,5972,2695],()=>a(58178));module.exports=r})();