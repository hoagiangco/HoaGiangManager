"use strict";(()=>{var e={};e.id=9582,e.ids=[9582],e.modules={20399:e=>{e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},30517:e=>{e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},78893:e=>{e.exports=require("buffer")},84770:e=>{e.exports=require("crypto")},92048:e=>{e.exports=require("fs")},19801:e=>{e.exports=require("os")},55315:e=>{e.exports=require("path")},76162:e=>{e.exports=require("stream")},21764:e=>{e.exports=require("util")},8678:e=>{e.exports=import("pg")},57957:(e,t,r)=>{r.a(e,async(e,a)=>{try{r.r(t),r.d(t,{originalPathname:()=>d,patchFetch:()=>c,requestAsyncStorage:()=>E,routeModule:()=>l,serverHooks:()=>I,staticGenerationAsyncStorage:()=>p});var s=r(49303),n=r(88716),o=r(60670),u=r(40228),i=e([u]);u=(i.then?(await i)():i)[0];let l=new s.AppRouteRouteModule({definition:{kind:n.x.APP_ROUTE,page:"/api/statistics/summary/route",pathname:"/api/statistics/summary",filename:"route",bundlePath:"app/api/statistics/summary/route"},resolvedPagePath:"E:\\Web Project\\Nextjs\\HoaGiangManager\\app\\api\\statistics\\summary\\route.ts",nextConfigOutput:"standalone",userland:u}),{requestAsyncStorage:E,staticGenerationAsyncStorage:p,serverHooks:I}=l,d="/api/statistics/summary/route";function c(){return(0,o.patchFetch)({serverHooks:I,staticGenerationAsyncStorage:p})}a()}catch(e){a(e)}})},40228:(e,t,r)=>{r.a(e,async(e,a)=>{try{r.r(t),r.d(t,{GET:()=>i,dynamic:()=>c});var s=r(87070),n=r(96899),o=r(97395),u=e([n,o]);[n,o]=u.then?(await u)():u;let c="force-dynamic";async function i(e){try{let{user:t,error:r}=await (0,n.Y)(e);if(!t||!t.roles?.includes("Admin")&&!t.roles?.includes("Manager"))return s.NextResponse.json({status:!1,error:"Unauthorized. Admin access required."},{status:401});let{searchParams:a}=new URL(e.url),u=a.get("departmentId"),i=a.get("locationId"),c=a.get("fromDate"),l=a.get("toDate"),E=a.get("categoryId"),p=a.get("status"),I=a.get("search"),d=a.get("maintenanceBatchId"),h=[],D=' AND ("IsDeleted" = false OR "IsDeleted" IS NULL)';c&&l&&(h.push(c,l),D+=' AND "ReportDate" >= $1 AND "ReportDate" <= $2'),u&&"0"!==u&&(h.push(u),D+=` AND "ReportingDepartmentID" = $${h.length}`),i&&"0"!==i&&(h.push(i),D+=` AND "DeviceID" IN (
        SELECT "ID" FROM "Device" WHERE "LocationID" IN (
          WITH RECURSIVE sub_locations AS (
            SELECT "ID" FROM "Location" WHERE "ID" = $${h.length}
            UNION ALL
            SELECT l."ID" FROM "Location" l
            INNER JOIN sub_locations sl ON l."ParentID" = sl."ID"
          )
          SELECT "ID" FROM sub_locations
        )
      )`),p&&"0"!==p&&(h.push(p),D+=` AND "Status" = $${h.length}`),I&&(h.push(`%${I}%`),D+=` AND (LOWER("DamageContent") LIKE LOWER($${h.length}) OR LOWER("DamageLocation") LIKE LOWER($${h.length}))`),d&&(h.push(d),D+=` AND "MaintenanceBatchId" = $${h.length}`);let R=`
      SELECT "Status", COUNT("ID") as count
      FROM "DamageReport"
      WHERE 1=1 ${D}
      GROUP BY "Status"
    `,g=await o.Z.query(R,h),N={total:0,pending:0,assigned:0,inProgress:0,completed:0,cancelled:0,rejected:0};g.rows.forEach(e=>{let t=parseInt(e.count);switch(N.total+=t,Number(e.Status)){case 1:N.pending+=t;break;case 2:N.assigned+=t;break;case 3:N.inProgress+=t;break;case 4:N.completed+=t;break;case 5:N.cancelled+=t;break;case 6:N.rejected+=t}});let L=[],m="";u&&"0"!==u&&(L.push(u),m+=` AND "DepartmentID" = $${L.length}`),i&&"0"!==i&&(L.push(i),m+=` AND "LocationID" IN (
        WITH RECURSIVE sub_locations AS (
          SELECT "ID" FROM "Location" WHERE "ID" = $${L.length}
          UNION ALL
          SELECT l."ID" FROM "Location" l
          INNER JOIN sub_locations sl ON l."ParentID" = sl."ID"
        )
        SELECT "ID" FROM sub_locations
      )`),E&&"0"!==E&&(L.push(E),m+=` AND "DeviceCategoryID" = $${L.length}`),p&&"0"!==p&&(L.push(p),m+=` AND "Status" = $${L.length}`),I&&(L.push(`%${I}%`),m+=` AND (LOWER("Name") LIKE LOWER($${L.length}) OR LOWER("Serial") LIKE LOWER($${L.length}))`);let S=`
      SELECT "Status", COUNT("ID") as count
      FROM "Device"
      WHERE 1=1 ${m}
      GROUP BY "Status"
    `,O=await o.Z.query(S,L),y={total:0,dangSuDung:0,dangSuaChua:0,huHong:0,daThanhLy:0,coHuHong:0};O.rows.forEach(e=>{let t=parseInt(e.count);switch(y.total+=t,Number(e.Status)){case 1:y.dangSuDung+=t;break;case 2:y.dangSuaChua+=t;break;case 3:y.huHong+=t;break;case 4:y.daThanhLy+=t;break;case 5:y.coHuHong+=t}});let A=[],T="";u&&"0"!==u&&(A.push(u),T+=` AND d."DepartmentID" = $${A.length}`),i&&"0"!==i&&(A.push(i),T+=` AND d."LocationID" IN (
        WITH RECURSIVE sub_locations AS (
          SELECT "ID" FROM "Location" WHERE "ID" = $${A.length}
          UNION ALL
          SELECT l."ID" FROM "Location" l
          INNER JOIN sub_locations sl ON l."ParentID" = sl."ID"
        )
        SELECT "ID" FROM sub_locations
      )`);let $=`
      SELECT COUNT(e."ID") as count
      FROM "Event" e
      LEFT JOIN "Device" d ON e."DeviceID" = d."ID"
      WHERE e."EventTypeID" IN (
        SELECT "ID" FROM "EventType" WHERE "Category" = 'maintenance'
      ) AND e."Status" != 'completed' AND e."Status" != 'cancelled'
      ${T}
    `,v=await o.Z.query($,A);return s.NextResponse.json({status:!0,data:{reports:N,devices:y,activeMaintenance:parseInt(v.rows[0]?.count||"0")}})}catch(e){return console.error("Statistics API Error:",e),s.NextResponse.json({status:!1,error:"Internal Server Error"},{status:500})}}a()}catch(e){a(e)}})},73840:(e,t,r)=>{r.d(t,{RA:()=>u,WX:()=>i});var a=r(41482),s=r.n(a);let n=process.env.JWT_SECRET||"your-secret-key-change-this-in-production",o=process.env.JWT_EXPIRES_IN||"24h",u=e=>{if(!n)throw Error("JWT_SECRET is not configured");return s().sign(e,n,{expiresIn:o})},i=e=>{try{return s().verify(e,n)}catch(e){throw Error("Invalid token")}}},96899:(e,t,r)=>{r.a(e,async(e,a)=>{try{r.d(t,{Y:()=>u}),r(87070);var s=r(73840),n=r(97395),o=e([n]);async function u(e){try{let t=e.headers.get("authorization");if(!t||!t.startsWith("Bearer "))return{user:null,error:"No token provided"};let r=t.substring(7),a=(0,s.WX)(r),o=await n.Z.query(`SELECT u."Id", u."Email", u."NormalizedEmail"
       FROM "AspNetUsers" u
       WHERE u."Id" = $1`,[a.userId]);if(0===o.rows.length)return{user:null,error:"User not found"};let u=(await n.Z.query(`SELECT r."Name"
       FROM "AspNetRoles" r
       INNER JOIN "AspNetUserRoles" ur ON r."Id" = ur."RoleId"
       WHERE ur."UserId" = $1`,[a.userId])).rows.map(e=>e.Name);return{user:{userId:a.userId,email:a.email,roles:u},error:null}}catch(e){return console.error("Authentication error:",e.message||e),{user:null,error:e.message||"Invalid token"}}}n=(o.then?(await o)():o)[0],a()}catch(e){a(e)}})},97395:(e,t,r)=>{r.a(e,async(e,a)=>{try{r.d(t,{I:()=>E,Z:()=>l});var s=r(8678),n=r(16636),o=r.n(n),u=e([s]);s=(u.then?(await u)():u)[0],o().config(),o().config({path:".env.local",override:!0}),s.types.setTypeParser(1082,e=>e);let i=process.env.DATABASE_URL?.includes("localhost")||process.env.DATABASE_URL?.includes("127.0.0.1"),c=new s.Pool({connectionString:process.env.DATABASE_URL,ssl:!i&&{rejectUnauthorized:!1}});c.on("connect",e=>{e.query("SET TIME ZONE 'Asia/Ho_Chi_Minh'")});let l=c,E=async(e,t)=>{Date.now();try{let r=await c.query(e,t);return Date.now(),r}catch(t){throw console.error("Database query error",{text:e,error:t}),t}};a()}catch(e){a(e)}})}};var t=require("../../../../webpack-runtime.js");t.C(e);var r=e=>t(t.s=e),a=t.X(0,[8948,5972,2695],()=>r(57957));module.exports=a})();