"use strict";(()=>{var e={};e.id=6852,e.ids=[6852],e.modules={20399:e=>{e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},30517:e=>{e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},78893:e=>{e.exports=require("buffer")},84770:e=>{e.exports=require("crypto")},92048:e=>{e.exports=require("fs")},19801:e=>{e.exports=require("os")},55315:e=>{e.exports=require("path")},76162:e=>{e.exports=require("stream")},21764:e=>{e.exports=require("util")},8678:e=>{e.exports=import("pg")},71262:(e,t,n)=>{n.a(e,async(e,r)=>{try{n.r(t),n.d(t,{originalPathname:()=>S,patchFetch:()=>d,requestAsyncStorage:()=>p,routeModule:()=>u,serverHooks:()=>l,staticGenerationAsyncStorage:()=>E});var a=n(49303),s=n(88716),i=n(60670),o=n(68026),c=e([o]);o=(c.then?(await c)():c)[0];let u=new a.AppRouteRouteModule({definition:{kind:s.x.APP_ROUTE,page:"/api/maintenance/notifications/route",pathname:"/api/maintenance/notifications",filename:"route",bundlePath:"app/api/maintenance/notifications/route"},resolvedPagePath:"E:\\Web Project\\Nextjs\\HoaGiangManager\\app\\api\\maintenance\\notifications\\route.ts",nextConfigOutput:"standalone",userland:o}),{requestAsyncStorage:p,staticGenerationAsyncStorage:E,serverHooks:l}=u,S="/api/maintenance/notifications/route";function d(){return(0,i.patchFetch)({serverHooks:l,staticGenerationAsyncStorage:E})}r()}catch(e){r(e)}})},68026:(e,t,n)=>{n.a(e,async(e,r)=>{try{n.r(t),n.d(t,{GET:()=>c,dynamic:()=>d});var a=n(87070),s=n(96899),i=n(97395),o=e([s,i]);[s,i]=o.then?(await o)():o;let d="force-dynamic";async function c(e){try{let{user:t,error:n}=await (0,s.Y)(e);if(!t)return a.NextResponse.json({status:!1,error:n||"Unauthorized"},{status:401});let r=new Date;r.setHours(0,0,0,0);let o=new Date(r);o.setDate(o.getDate()+30);let c=t.roles&&t.roles.includes("Admin"),d=t.userId,u=(await i.Z.query(`
      WITH current_staff AS (
        SELECT "ID" FROM "Staff" WHERE "UserId" = $4
      ),
      scoped_plans AS (
        SELECT
          COALESCE(p."Metadata"->>'maintenanceBatchId', 'no-batch-' || p."ID"::text) AS batch_id,
          p."NextDueDate" AS next_due_date
        FROM "DeviceReminderPlan" p
        WHERE p."IsActive" = true
          AND p."NextDueDate" IS NOT NULL
          AND (
            $3::boolean = true
            OR (
              p."Metadata" ? 'assignedStaffId'
              AND (p."Metadata"->>'assignedStaffId') ~ '^[0-9]+$'
              AND (p."Metadata"->>'assignedStaffId')::integer IN (SELECT "ID" FROM current_staff)
            )
          )
      ),
      plan_summary AS (
        SELECT
          COUNT(DISTINCT batch_id) FILTER (WHERE next_due_date < $1) AS overdue_batches,
          COUNT(*) FILTER (WHERE next_due_date < $1) AS overdue_devices,
          COUNT(DISTINCT batch_id) FILTER (WHERE next_due_date >= $1 AND next_due_date <= $2) AS upcoming_batches,
          COUNT(*) FILTER (WHERE next_due_date >= $1 AND next_due_date <= $2) AS upcoming_devices
        FROM scoped_plans
      ),
      scoped_events AS (
        SELECT
          COALESCE(e."Metadata"->>'maintenanceBatchId', 'event-' || e."ID"::text) AS batch_id,
          e."Status" AS status
        FROM "Event" e
        WHERE e."Status" IN ('planned', 'in_progress')
          AND e."Metadata" IS NOT NULL
          AND e."Metadata" ? 'maintenanceBatchId'
          AND (
            $3::boolean = true
            OR e."StaffID" IN (SELECT "ID" FROM current_staff)
          )
      ),
      event_summary AS (
        SELECT
          COUNT(DISTINCT batch_id) AS pending_batches,
          COUNT(*) AS pending_devices,
          COUNT(DISTINCT batch_id) FILTER (WHERE status = 'planned') AS planned_batches,
          COUNT(*) FILTER (WHERE status = 'planned') AS planned_devices,
          COUNT(DISTINCT batch_id) FILTER (WHERE status = 'in_progress') AS in_progress_batches,
          COUNT(*) FILTER (WHERE status = 'in_progress') AS in_progress_devices
        FROM scoped_events
      )
      SELECT
        COALESCE(ps.overdue_batches, 0)::int AS "overdueBatches",
        COALESCE(ps.overdue_devices, 0)::int AS "overdueDevices",
        COALESCE(ps.upcoming_batches, 0)::int AS "upcomingBatches",
        COALESCE(ps.upcoming_devices, 0)::int AS "upcomingDevices",
        COALESCE(es.pending_batches, 0)::int AS "pendingBatches",
        COALESCE(es.pending_devices, 0)::int AS "pendingDevices",
        COALESCE(es.planned_batches, 0)::int AS "plannedBatches",
        COALESCE(es.planned_devices, 0)::int AS "plannedDevices",
        COALESCE(es.in_progress_batches, 0)::int AS "inProgressBatches",
        COALESCE(es.in_progress_devices, 0)::int AS "inProgressDevices"
      FROM plan_summary ps
      CROSS JOIN event_summary es
      `,[r,o,c,d])).rows[0]||{};return a.NextResponse.json({status:!0,data:{overduePlans:u.overdueBatches||0,upcomingPlans:u.upcomingBatches||0,pendingEvents:u.pendingDevices||0,batches:{overdue:u.overdueBatches||0,upcoming:u.upcomingBatches||0,pending:u.pendingBatches||0,planned:u.plannedBatches||0,inProgress:u.inProgressBatches||0},devices:{overdue:u.overdueDevices||0,upcoming:u.upcomingDevices||0,pending:u.pendingDevices||0,planned:u.plannedDevices||0,inProgress:u.inProgressDevices||0}}})}catch(e){return console.error("Get maintenance notifications error:",e),a.NextResponse.json({status:!1,error:e.message||"Đ\xe3 xảy ra lỗi khi lấy th\xf4ng b\xe1o bảo tr\xec"},{status:500})}}r()}catch(e){r(e)}})},73840:(e,t,n)=>{n.d(t,{RA:()=>o,WX:()=>c});var r=n(41482),a=n.n(r);let s=process.env.JWT_SECRET||"your-secret-key-change-this-in-production",i=process.env.JWT_EXPIRES_IN||"24h",o=e=>{if(!s)throw Error("JWT_SECRET is not configured");return a().sign(e,s,{expiresIn:i})},c=e=>{try{return a().verify(e,s)}catch(e){throw Error("Invalid token")}}},96899:(e,t,n)=>{n.a(e,async(e,r)=>{try{n.d(t,{Y:()=>o}),n(87070);var a=n(73840),s=n(97395),i=e([s]);async function o(e){try{let t=e.headers.get("authorization");if(!t||!t.startsWith("Bearer "))return{user:null,error:"No token provided"};let n=t.substring(7),r=(0,a.WX)(n),i=await s.Z.query(`SELECT u."Id", u."Email", u."NormalizedEmail"
       FROM "AspNetUsers" u
       WHERE u."Id" = $1`,[r.userId]);if(0===i.rows.length)return{user:null,error:"User not found"};let o=(await s.Z.query(`SELECT r."Name"
       FROM "AspNetRoles" r
       INNER JOIN "AspNetUserRoles" ur ON r."Id" = ur."RoleId"
       WHERE ur."UserId" = $1`,[r.userId])).rows.map(e=>e.Name);return{user:{userId:r.userId,email:r.email,roles:o},error:null}}catch(e){return console.error("Authentication error:",e.message||e),{user:null,error:e.message||"Invalid token"}}}s=(i.then?(await i)():i)[0],r()}catch(e){r(e)}})},97395:(e,t,n)=>{n.a(e,async(e,r)=>{try{n.d(t,{I:()=>p,Z:()=>u});var a=n(8678),s=n(16636),i=n.n(s),o=e([a]);a=(o.then?(await o)():o)[0],i().config(),i().config({path:".env.local",override:!0}),a.types.setTypeParser(1082,e=>e);let c=process.env.DATABASE_URL?.includes("localhost")||process.env.DATABASE_URL?.includes("127.0.0.1"),d=new a.Pool({connectionString:process.env.DATABASE_URL,ssl:!c&&{rejectUnauthorized:!1}});d.on("connect",e=>{e.query("SET TIME ZONE 'Asia/Ho_Chi_Minh'")});let u=d,p=async(e,t)=>{Date.now();try{let n=await d.query(e,t);return Date.now(),n}catch(t){throw console.error("Database query error",{text:e,error:t}),t}};r()}catch(e){r(e)}})}};var t=require("../../../../webpack-runtime.js");t.C(e);var n=e=>t(t.s=e),r=t.X(0,[8948,5972,2695],()=>n(71262));module.exports=r})();