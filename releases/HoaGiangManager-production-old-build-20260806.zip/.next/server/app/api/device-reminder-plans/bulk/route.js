"use strict";(()=>{var e={};e.id=5939,e.ids=[5939],e.modules={20399:e=>{e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},30517:e=>{e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},78893:e=>{e.exports=require("buffer")},84770:e=>{e.exports=require("crypto")},92048:e=>{e.exports=require("fs")},19801:e=>{e.exports=require("os")},55315:e=>{e.exports=require("path")},76162:e=>{e.exports=require("stream")},21764:e=>{e.exports=require("util")},8678:e=>{e.exports=import("pg")},73136:(e,t,r)=>{r.a(e,async(e,a)=>{try{r.r(t),r.d(t,{originalPathname:()=>m,patchFetch:()=>l,requestAsyncStorage:()=>c,routeModule:()=>d,serverHooks:()=>y,staticGenerationAsyncStorage:()=>p});var n=r(49303),i=r(88716),s=r(60670),o=r(68962),u=e([o]);o=(u.then?(await u)():u)[0];let d=new n.AppRouteRouteModule({definition:{kind:i.x.APP_ROUTE,page:"/api/device-reminder-plans/bulk/route",pathname:"/api/device-reminder-plans/bulk",filename:"route",bundlePath:"app/api/device-reminder-plans/bulk/route"},resolvedPagePath:"E:\\Web Project\\Nextjs\\HoaGiangManager\\app\\api\\device-reminder-plans\\bulk\\route.ts",nextConfigOutput:"standalone",userland:o}),{requestAsyncStorage:c,staticGenerationAsyncStorage:p,serverHooks:y}=d,m="/api/device-reminder-plans/bulk/route";function l(){return(0,s.patchFetch)({serverHooks:y,staticGenerationAsyncStorage:p})}a()}catch(e){a(e)}})},68962:(e,t,r)=>{r.a(e,async(e,a)=>{try{r.r(t),r.d(t,{POST:()=>d});var n=r(87070),i=r(96899),s=r(64079),o=r(49051),u=r(69202),l=e([i,s,o]);[i,s,o]=l.then?(await l)():l;let c=e=>{if(!e)return null;let t=new Date(e);return Number.isNaN(t.getTime())?null:t};async function d(e){try{let{user:t,error:r}=await (0,i.Y)(e);if(!t)return n.NextResponse.json({status:!1,error:r||"Unauthorized"},{status:401});let{deviceIds:a,categoryId:l,eventTypeId:d,title:p,description:y,intervalValue:m,intervalUnit:g,startFrom:D,endAt:h,metadata:v}=await e.json();if(!d||d<=0)return n.NextResponse.json({status:!1,error:"EventTypeID l\xe0 bắt buộc"},{status:400});if(!m||m<=0)return n.NextResponse.json({status:!1,error:"IntervalValue phải lớn hơn 0"},{status:400});if(!g||!["day","week","month","year"].includes(g))return n.NextResponse.json({status:!1,error:"IntervalUnit kh\xf4ng hợp lệ"},{status:400});let f=c(D);if(!f)return n.NextResponse.json({status:!1,error:"StartFrom l\xe0 bắt buộc v\xe0 phải l\xe0 ng\xe0y hợp lệ"},{status:400});let I=new o.U,T=[];if(a&&Array.isArray(a)&&a.length>0)T=await I.getDevicesByIds(a);else{if(!l||!(l>0))return n.NextResponse.json({status:!1,error:"Phải cung cấp deviceIds hoặc categoryId"},{status:400});T=await I.getDeviceByCategory(l)}if(0===T.length)return n.NextResponse.json({status:!1,error:"Kh\xf4ng t\xecm thấy thiết bị n\xe0o"},{status:400});let A=v?.maintenanceBatchId||`batch-${new Date().toISOString().split("T")[0]}-${Date.now()}`,N={...v,maintenanceBatchId:A},E=N?.scheduleConfig,w=E?.scheduleType==="specific_dates"?(0,u.calculateNextDueDate)(f,m,g,E,!0,f):new Date(f),x=new s._,S=[];for(let e of T){let r={deviceId:e.id,reminderType:v?.reminderType||"maintenance",eventTypeId:d,title:p||`Bảo tr\xec định kỳ - ${e.name}`,description:y||null,intervalValue:m,intervalUnit:g,cronExpression:null,startFrom:f,endAt:c(h),nextDueDate:w,lastTriggeredAt:null,isActive:!0,metadata:N,createdBy:t.email||null,createdAt:new Date,updatedBy:t.email||null,updatedAt:new Date},a=await x.create(r);S.push(a)}return n.NextResponse.json({status:!0,data:{created:S.length,plans:S,maintenanceBatchId:A}})}catch(e){return console.error("Bulk create reminder plans error:",e),n.NextResponse.json({status:!1,error:e.message||"Đ\xe3 xảy ra lỗi khi tạo kế hoạch bảo tr\xec"},{status:500})}}a()}catch(e){a(e)}})},73840:(e,t,r)=>{r.d(t,{RA:()=>o,WX:()=>u});var a=r(41482),n=r.n(a);let i=process.env.JWT_SECRET||"your-secret-key-change-this-in-production",s=process.env.JWT_EXPIRES_IN||"24h",o=e=>{if(!i)throw Error("JWT_SECRET is not configured");return n().sign(e,i,{expiresIn:s})},u=e=>{try{return n().verify(e,i)}catch(e){throw Error("Invalid token")}}},96899:(e,t,r)=>{r.a(e,async(e,a)=>{try{r.d(t,{Y:()=>o}),r(87070);var n=r(73840),i=r(97395),s=e([i]);async function o(e){try{let t=e.headers.get("authorization");if(!t||!t.startsWith("Bearer "))return{user:null,error:"No token provided"};let r=t.substring(7),a=(0,n.WX)(r),s=await i.Z.query(`SELECT u."Id", u."Email", u."NormalizedEmail"
       FROM "AspNetUsers" u
       WHERE u."Id" = $1`,[a.userId]);if(0===s.rows.length)return{user:null,error:"User not found"};let o=(await i.Z.query(`SELECT r."Name"
       FROM "AspNetRoles" r
       INNER JOIN "AspNetUserRoles" ur ON r."Id" = ur."RoleId"
       WHERE ur."UserId" = $1`,[a.userId])).rows.map(e=>e.Name);return{user:{userId:a.userId,email:a.email,roles:o},error:null}}catch(e){return console.error("Authentication error:",e.message||e),{user:null,error:e.message||"Invalid token"}}}i=(s.then?(await s)():s)[0],a()}catch(e){a(e)}})},97395:(e,t,r)=>{r.a(e,async(e,a)=>{try{r.d(t,{I:()=>c,Z:()=>d});var n=r(8678),i=r(16636),s=r.n(i),o=e([n]);n=(o.then?(await o)():o)[0],s().config(),s().config({path:".env.local",override:!0}),n.types.setTypeParser(1082,e=>e);let u=process.env.DATABASE_URL?.includes("localhost")||process.env.DATABASE_URL?.includes("127.0.0.1"),l=new n.Pool({connectionString:process.env.DATABASE_URL,ssl:!u&&{rejectUnauthorized:!1}});l.on("connect",e=>{e.query("SET TIME ZONE 'Asia/Ho_Chi_Minh'")});let d=l,c=async(e,t)=>{Date.now();try{let r=await l.query(e,t);return Date.now(),r}catch(t){throw console.error("Database query error",{text:e,error:t}),t}};a()}catch(e){a(e)}})},64079:(e,t,r)=>{r.a(e,async(e,a)=>{try{r.d(t,{_:()=>u});var n=r(97395),i=r(1013),s=e([n]);n=(s.then?(await s)():s)[0];let o=e=>({id:e.id,deviceId:e.deviceId,reminderType:e.reminderType,eventTypeId:e.eventTypeId,title:e.title,description:e.description,intervalValue:e.intervalValue,intervalUnit:e.intervalUnit,cronExpression:e.cronExpression,startFrom:e.startFrom,endAt:e.endAt,nextDueDate:e.nextDueDate,lastTriggeredAt:e.lastTriggeredAt,isActive:e.isActive??!0,metadata:"string"==typeof e.metadata?(()=>{try{return JSON.parse(e.metadata)}catch(e){return null}})():e.metadata||null,createdBy:e.createdBy,createdAt:e.createdAt,updatedBy:e.updatedBy,updatedAt:e.updatedAt});class u{async list(e){let t=[],r="";return e&&e>0&&(t.push(e),r='WHERE p."DeviceID" = $1'),(await n.Z.query(`
      SELECT
        p."ID" as id,
        p."DeviceID" as "deviceId",
        d."Name" as "deviceName",
        p."ReminderType" as "reminderType",
        p."EventTypeID" as "eventTypeId",
        et."Name" as "eventTypeName",
        p."Title" as title,
        p."Description" as description,
        p."IntervalValue" as "intervalValue",
        p."IntervalUnit" as "intervalUnit",
        p."CronExpression" as "cronExpression",
        p."StartFrom" as "startFrom",
        p."EndAt" as "endAt",
        p."NextDueDate" as "nextDueDate",
        p."LastTriggeredAt" as "lastTriggeredAt",
        p."IsActive" as "isActive",
        p."Metadata" as metadata,
        p."CreatedBy" as "createdBy",
        p."CreatedAt" as "createdAt",
        p."UpdatedBy" as "updatedBy",
        p."UpdatedAt" as "updatedAt"
      FROM "DeviceReminderPlan" p
      LEFT JOIN "Device" d ON p."DeviceID" = d."ID"
      LEFT JOIN "EventType" et ON p."EventTypeID" = et."ID"
      ${r}
      ORDER BY p."IsActive" DESC, p."NextDueDate" NULLS LAST, p."ID" DESC
      `,t)).rows.map(e=>({...o(e),deviceName:e.deviceName||void 0,eventTypeName:e.eventTypeName||void 0}))}async getById(e){let t=await n.Z.query(`
      SELECT
        "ID" as id,
        "DeviceID" as "deviceId",
        "ReminderType" as "reminderType",
        "EventTypeID" as "eventTypeId",
        "Title" as title,
        "Description" as description,
        "IntervalValue" as "intervalValue",
        "IntervalUnit" as "intervalUnit",
        "CronExpression" as "cronExpression",
        "StartFrom" as "startFrom",
        "EndAt" as "endAt",
        "NextDueDate" as "nextDueDate",
        "LastTriggeredAt" as "lastTriggeredAt",
        "IsActive" as "isActive",
        "Metadata" as metadata,
        "CreatedBy" as "createdBy",
        "CreatedAt" as "createdAt",
        "UpdatedBy" as "updatedBy",
        "UpdatedAt" as "updatedAt"
      FROM "DeviceReminderPlan"
      WHERE "ID" = $1
      `,[e]);return 0===t.rows.length?null:o(t.rows[0])}async create(e){return(await n.Z.query(`
      INSERT INTO "DeviceReminderPlan" (
        "DeviceID",
        "ReminderType",
        "EventTypeID",
        "Title",
        "Description",
        "IntervalValue",
        "IntervalUnit",
        "CronExpression",
        "StartFrom",
        "EndAt",
        "NextDueDate",
        "LastTriggeredAt",
        "IsActive",
        "Metadata",
        "CreatedBy",
        "CreatedAt",
        "UpdatedBy",
        "UpdatedAt"
      ) VALUES (
        $1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13,
        $14::jsonb, $15, $16, $17, $18
      )
      RETURNING "ID"
      `,[e.deviceId,e.reminderType,e.eventTypeId||null,e.title||null,e.description||null,e.intervalValue||null,e.intervalUnit||null,e.cronExpression||null,e.startFrom||null,e.endAt||null,e.nextDueDate||null,e.lastTriggeredAt||null,e.isActive??!0,e.metadata?JSON.stringify(e.metadata):null,e.createdBy||null,e.createdAt||(0,i.ud)(),e.updatedBy||e.createdBy||null,e.updatedAt||(0,i.ud)()])).rows[0].ID}async update(e){return await n.Z.query(`
      UPDATE "DeviceReminderPlan" SET
        "DeviceID" = $1,
        "ReminderType" = $2,
        "EventTypeID" = $3,
        "Title" = $4,
        "Description" = $5,
        "IntervalValue" = $6,
        "IntervalUnit" = $7,
        "CronExpression" = $8,
        "StartFrom" = $9,
        "EndAt" = $10,
        "NextDueDate" = $11,
        "LastTriggeredAt" = $12,
        "IsActive" = $13,
        "Metadata" = $14::jsonb,
        "UpdatedBy" = $15,
        "UpdatedAt" = CURRENT_TIMESTAMP
      WHERE "ID" = $16
      `,[e.deviceId,e.reminderType,e.eventTypeId||null,e.title||null,e.description||null,e.intervalValue||null,e.intervalUnit||null,e.cronExpression||null,e.startFrom||null,e.endAt||null,e.nextDueDate||null,e.lastTriggeredAt||null,e.isActive??!0,e.metadata?JSON.stringify(e.metadata):null,e.updatedBy||null,e.id]),e.id}async delete(e){return await n.Z.query('DELETE FROM "DeviceReminderPlan" WHERE "ID" = $1',[e]),!0}}a()}catch(e){a(e)}})},1013:(e,t,r)=>{r.d(t,{J0:()=>s,My:()=>n,_Q:()=>o,rp:()=>i,ud:()=>a});let a=()=>{try{let e=new Date;return new Date(e.toLocaleString("en-US",{timeZone:"Asia/Ho_Chi_Minh"}))}catch{return new Date}},n=()=>{let e=a(),t=e.getFullYear(),r=String(e.getMonth()+1).padStart(2,"0"),n=String(e.getDate()).padStart(2,"0");return`${t}-${r}-${n}`},i=e=>{if(!e)return"";try{let t="string"==typeof e?new Date(e):e;if(Number.isNaN(t.getTime()))return"";return new Intl.DateTimeFormat("en-GB",{timeZone:"Asia/Ho_Chi_Minh",day:"2-digit",month:"2-digit",year:"numeric"}).format(t)}catch(e){return""}},s=e=>{if(!e)return"";try{let t="string"==typeof e?new Date(e):e;if(Number.isNaN(t.getTime()))return"";let r=new Intl.DateTimeFormat("en-GB",{timeZone:"Asia/Ho_Chi_Minh",day:"2-digit",month:"2-digit",year:"numeric"}).formatToParts(t),a=r.find(e=>"year"===e.type)?.value||"",n=r.find(e=>"month"===e.type)?.value||"",i=r.find(e=>"day"===e.type)?.value||"";return`${i}-${n}-${a}`}catch(e){return""}},o=(e,t)=>{if(!e&&!t)return"tất cả thời gian";let r=i(e)||"...",a=i(t)||"...";return`${r} đến ${a}`}},69202:(e,t,r)=>{r.r(t),r.d(t,{calculateNextDueDate:()=>l});var a=r(66615),n=r(69689),i=r(61494);function s(e,t){(0,i.Z)(2,arguments);var r=(0,n.Z)(e),s=(0,a.Z)(t);return isNaN(s)?new Date(NaN):(s&&r.setDate(r.getDate()+s),r)}function o(e,t){(0,i.Z)(2,arguments);var r=(0,n.Z)(e),s=(0,a.Z)(t);if(isNaN(s))return new Date(NaN);if(!s)return r;var o=r.getDate(),u=new Date(r.getTime());return(u.setMonth(r.getMonth()+s+1,0),o>=u.getDate())?u:(r.setFullYear(u.getFullYear(),u.getMonth(),o),r)}function u(e,t){return(0,i.Z)(2,arguments),o(e,12*(0,a.Z)(t))}let l=(e,t,r,l,d=!1,c)=>{let p=new Date(e);if(p.setHours(0,0,0,0),l?.scheduleType==="specific_dates"&&d){let e=new Date;e.setHours(0,0,0,0),p<e&&(p=e)}if(!l||"specific_dates"!==l.scheduleType){if(d)return new Date(p);if(c){let e=new Date(c);e.setHours(0,0,0,0);let a=new Date(e),n=0;for(;a<=p&&n<1e4;){switch(r){case"day":a.setDate(a.getDate()+t);break;case"week":a.setDate(a.getDate()+7*t);break;case"month":a.setMonth(a.getMonth()+t);break;case"year":a.setFullYear(a.getFullYear()+t)}n++}return a}let e=new Date(p);switch(r){case"day":e.setDate(e.getDate()+t);break;case"week":e.setDate(e.getDate()+7*t);break;case"month":e.setMonth(e.getMonth()+t);break;case"year":e.setFullYear(e.getFullYear()+t)}return e}if("week"===r){let e=l.specificDaysOfWeek;if(!e||0===e.length)return s(p,7);let r=p.getDay(),a=[...e].sort((e,t)=>e-t),n=(e,t)=>{let r=-e.getDay(),a=s(e,r);return s(a,t)};if(d){for(let e of a)if(e>=r)return n(p,e);let e=a[0];return n(s(p,7*t),e)}{for(let e of a)if(e>r)return n(p,e);let e=a[0];return n(s(p,7*t),e)}}if("month"===r||"year"===r){let e=l.specificDays;if(!e||0===e.length)return"month"===r?o(p,t):u(p,t);let s=p.getDate(),c=[...e].sort((e,t)=>e-t),y=(e,t)=>{let r=new Date(e.getFullYear(),e.getMonth()+1,0).getDate();return function(e,t){(0,i.Z)(2,arguments);var r=(0,n.Z)(e),s=(0,a.Z)(t);return r.setDate(s),r}(e,Math.min(t,r))};if(d){for(let e of c)if(e>=s)return y(p,e);return y("month"===r?o(p,t):u(p,t),c[0])}for(let e of c)if(e>s)return y(p,e);return y("month"===r?o(p,t):u(p,t),c[0])}return d?p:s(p,t)}},61494:(e,t,r)=>{r.d(t,{Z:()=>a});function a(e,t){if(t.length<e)throw TypeError(e+" argument"+(e>1?"s":"")+" required, but only "+t.length+" present")}},66615:(e,t,r)=>{r.d(t,{Z:()=>a});function a(e){if(null===e||!0===e||!1===e)return NaN;var t=Number(e);return isNaN(t)?t:t<0?Math.ceil(t):Math.floor(t)}},69689:(e,t,r)=>{r.d(t,{Z:()=>i});var a=r(22676),n=r(61494);function i(e){(0,n.Z)(1,arguments);var t=Object.prototype.toString.call(e);return e instanceof Date||"object"===(0,a.Z)(e)&&"[object Date]"===t?new Date(e.getTime()):"number"==typeof e||"[object Number]"===t?new Date(e):(("string"==typeof e||"[object String]"===t)&&"undefined"!=typeof console&&(console.warn("Starting with v2.0.0-beta.1 date-fns doesn't accept strings as date arguments. Please use `parseISO` to parse strings. See: https://github.com/date-fns/date-fns/blob/master/docs/upgradeGuide.md#string-arguments"),console.warn(Error().stack)),new Date(NaN))}},94255:(e,t,r)=>{var a,n,i,s,o;r.d(t,{Ly:()=>a,N3:()=>n,OD:()=>i,sd:()=>s,x6:()=>o}),function(e){e[e.DangSuDung=1]="DangSuDung",e[e.DangSuaChua=2]="DangSuaChua",e[e.HuHong=3]="HuHong",e[e.DaThanhLy=4]="DaThanhLy",e[e.CoHuHong=5]="CoHuHong"}(a||(a={})),function(e){e.Planned="planned",e.InProgress="in_progress",e.Completed="completed",e.Cancelled="cancelled",e.Missed="missed"}(n||(n={})),function(e){e[e.Pending=1]="Pending",e[e.Assigned=2]="Assigned",e[e.InProgress=3]="InProgress",e[e.Completed=4]="Completed",e[e.Cancelled=5]="Cancelled",e[e.Rejected=6]="Rejected"}(i||(i={})),function(e){e[e.Low=1]="Low",e[e.Normal=2]="Normal",e[e.High=3]="High",e[e.Urgent=4]="Urgent"}(s||(s={})),function(e){e.In="IN",e.Out="OUT"}(o||(o={}))},22676:(e,t,r)=>{r.d(t,{Z:()=>a});function a(e){return(a="function"==typeof Symbol&&"symbol"==typeof Symbol.iterator?function(e){return typeof e}:function(e){return e&&"function"==typeof Symbol&&e.constructor===Symbol&&e!==Symbol.prototype?"symbol":typeof e})(e)}}};var t=require("../../../../webpack-runtime.js");t.C(e);var r=e=>t(t.s=e),a=t.X(0,[8948,5972,2695,9051],()=>r(73136));module.exports=a})();