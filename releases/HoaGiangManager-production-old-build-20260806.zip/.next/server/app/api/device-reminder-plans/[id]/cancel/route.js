"use strict";(()=>{var e={};e.id=9993,e.ids=[9993],e.modules={20399:e=>{e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},30517:e=>{e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},78893:e=>{e.exports=require("buffer")},84770:e=>{e.exports=require("crypto")},92048:e=>{e.exports=require("fs")},19801:e=>{e.exports=require("os")},55315:e=>{e.exports=require("path")},76162:e=>{e.exports=require("stream")},21764:e=>{e.exports=require("util")},8678:e=>{e.exports=import("pg")},745:(e,t,r)=>{r.a(e,async(e,a)=>{try{r.r(t),r.d(t,{originalPathname:()=>v,patchFetch:()=>u,requestAsyncStorage:()=>p,routeModule:()=>o,serverHooks:()=>y,staticGenerationAsyncStorage:()=>c});var n=r(49303),i=r(88716),s=r(60670),d=r(49160),l=e([d]);d=(l.then?(await l)():l)[0];let o=new n.AppRouteRouteModule({definition:{kind:i.x.APP_ROUTE,page:"/api/device-reminder-plans/[id]/cancel/route",pathname:"/api/device-reminder-plans/[id]/cancel",filename:"route",bundlePath:"app/api/device-reminder-plans/[id]/cancel/route"},resolvedPagePath:"E:\\Web Project\\Nextjs\\HoaGiangManager\\app\\api\\device-reminder-plans\\[id]\\cancel\\route.ts",nextConfigOutput:"standalone",userland:d}),{requestAsyncStorage:p,staticGenerationAsyncStorage:c,serverHooks:y}=o,v="/api/device-reminder-plans/[id]/cancel/route";function u(){return(0,s.patchFetch)({serverHooks:y,staticGenerationAsyncStorage:c})}a()}catch(e){a(e)}})},49160:(e,t,r)=>{r.a(e,async(e,a)=>{try{r.r(t),r.d(t,{POST:()=>l});var n=r(87070),i=r(96899),s=r(64079),d=e([i,s]);async function l(e,{params:t}){try{let{user:r,error:a}=await (0,i.Y)(e);if(!r)return n.NextResponse.json({status:!1,error:a||"Unauthorized"},{status:401});let d=Number(t.id);if(!d||Number.isNaN(d))return n.NextResponse.json({status:!1,error:"ID kh\xf4ng hợp lệ"},{status:400});let{reason:l}=await e.json();if(!l||!l.trim())return n.NextResponse.json({status:!1,error:"L\xfd do hủy l\xe0 bắt buộc"},{status:400});let u=new s._,o=await u.getById(d);if(!o)return n.NextResponse.json({status:!1,error:"Kh\xf4ng t\xecm thấy kế hoạch"},{status:404});let p=o.metadata||{},c=p.cancelHistory||[];c.push({cancelReason:l.trim(),cancelledBy:r.email||"unknown",cancelledAt:new Date().toISOString()});let y={...o,isActive:!1,metadata:{...p,cancelHistory:c},updatedBy:r.email||null,updatedAt:new Date};return await u.update(y),n.NextResponse.json({status:!0,data:{id:o.id,message:"Đ\xe3 hủy kế hoạch th\xe0nh c\xf4ng"}})}catch(e){return console.error("Cancel reminder plan error:",e),n.NextResponse.json({status:!1,error:e.message||"Đ\xe3 xảy ra lỗi khi hủy kế hoạch"},{status:500})}}[i,s]=d.then?(await d)():d,a()}catch(e){a(e)}})},73840:(e,t,r)=>{r.d(t,{RA:()=>d,WX:()=>l});var a=r(41482),n=r.n(a);let i=process.env.JWT_SECRET||"your-secret-key-change-this-in-production",s=process.env.JWT_EXPIRES_IN||"24h",d=e=>{if(!i)throw Error("JWT_SECRET is not configured");return n().sign(e,i,{expiresIn:s})},l=e=>{try{return n().verify(e,i)}catch(e){throw Error("Invalid token")}}},96899:(e,t,r)=>{r.a(e,async(e,a)=>{try{r.d(t,{Y:()=>d}),r(87070);var n=r(73840),i=r(97395),s=e([i]);async function d(e){try{let t=e.headers.get("authorization");if(!t||!t.startsWith("Bearer "))return{user:null,error:"No token provided"};let r=t.substring(7),a=(0,n.WX)(r),s=await i.Z.query(`SELECT u."Id", u."Email", u."NormalizedEmail"
       FROM "AspNetUsers" u
       WHERE u."Id" = $1`,[a.userId]);if(0===s.rows.length)return{user:null,error:"User not found"};let d=(await i.Z.query(`SELECT r."Name"
       FROM "AspNetRoles" r
       INNER JOIN "AspNetUserRoles" ur ON r."Id" = ur."RoleId"
       WHERE ur."UserId" = $1`,[a.userId])).rows.map(e=>e.Name);return{user:{userId:a.userId,email:a.email,roles:d},error:null}}catch(e){return console.error("Authentication error:",e.message||e),{user:null,error:e.message||"Invalid token"}}}i=(s.then?(await s)():s)[0],a()}catch(e){a(e)}})},97395:(e,t,r)=>{r.a(e,async(e,a)=>{try{r.d(t,{I:()=>p,Z:()=>o});var n=r(8678),i=r(16636),s=r.n(i),d=e([n]);n=(d.then?(await d)():d)[0],s().config(),s().config({path:".env.local",override:!0}),n.types.setTypeParser(1082,e=>e);let l=process.env.DATABASE_URL?.includes("localhost")||process.env.DATABASE_URL?.includes("127.0.0.1"),u=new n.Pool({connectionString:process.env.DATABASE_URL,ssl:!l&&{rejectUnauthorized:!1}});u.on("connect",e=>{e.query("SET TIME ZONE 'Asia/Ho_Chi_Minh'")});let o=u,p=async(e,t)=>{Date.now();try{let r=await u.query(e,t);return Date.now(),r}catch(t){throw console.error("Database query error",{text:e,error:t}),t}};a()}catch(e){a(e)}})},64079:(e,t,r)=>{r.a(e,async(e,a)=>{try{r.d(t,{_:()=>l});var n=r(97395),i=r(1013),s=e([n]);n=(s.then?(await s)():s)[0];let d=e=>({id:e.id,deviceId:e.deviceId,reminderType:e.reminderType,eventTypeId:e.eventTypeId,title:e.title,description:e.description,intervalValue:e.intervalValue,intervalUnit:e.intervalUnit,cronExpression:e.cronExpression,startFrom:e.startFrom,endAt:e.endAt,nextDueDate:e.nextDueDate,lastTriggeredAt:e.lastTriggeredAt,isActive:e.isActive??!0,metadata:"string"==typeof e.metadata?(()=>{try{return JSON.parse(e.metadata)}catch(e){return null}})():e.metadata||null,createdBy:e.createdBy,createdAt:e.createdAt,updatedBy:e.updatedBy,updatedAt:e.updatedAt});class l{async list(e){let t=[],r="";return e&&e>0&&(t.push(e),r='WHERE p."DeviceID" = $1'),(await n.Z.query(`
      SELECT
        p."ID" as id,
        p."DeviceID" as "deviceId",
        d."Name" as "deviceName",
        p."ReminderType" as "reminderType",
        p."EventTypeID" as "eventTypeId",
        et."Name" as "eventTypeName",
        p."Title" as title,
        p."Description" as description,
        p."IntervalValue" as "intervalValue",
        p."IntervalUnit" as "intervalUnit",
        p."CronExpression" as "cronExpression",
        p."StartFrom" as "startFrom",
        p."EndAt" as "endAt",
        p."NextDueDate" as "nextDueDate",
        p."LastTriggeredAt" as "lastTriggeredAt",
        p."IsActive" as "isActive",
        p."Metadata" as metadata,
        p."CreatedBy" as "createdBy",
        p."CreatedAt" as "createdAt",
        p."UpdatedBy" as "updatedBy",
        p."UpdatedAt" as "updatedAt"
      FROM "DeviceReminderPlan" p
      LEFT JOIN "Device" d ON p."DeviceID" = d."ID"
      LEFT JOIN "EventType" et ON p."EventTypeID" = et."ID"
      ${r}
      ORDER BY p."IsActive" DESC, p."NextDueDate" NULLS LAST, p."ID" DESC
      `,t)).rows.map(e=>({...d(e),deviceName:e.deviceName||void 0,eventTypeName:e.eventTypeName||void 0}))}async getById(e){let t=await n.Z.query(`
      SELECT
        "ID" as id,
        "DeviceID" as "deviceId",
        "ReminderType" as "reminderType",
        "EventTypeID" as "eventTypeId",
        "Title" as title,
        "Description" as description,
        "IntervalValue" as "intervalValue",
        "IntervalUnit" as "intervalUnit",
        "CronExpression" as "cronExpression",
        "StartFrom" as "startFrom",
        "EndAt" as "endAt",
        "NextDueDate" as "nextDueDate",
        "LastTriggeredAt" as "lastTriggeredAt",
        "IsActive" as "isActive",
        "Metadata" as metadata,
        "CreatedBy" as "createdBy",
        "CreatedAt" as "createdAt",
        "UpdatedBy" as "updatedBy",
        "UpdatedAt" as "updatedAt"
      FROM "DeviceReminderPlan"
      WHERE "ID" = $1
      `,[e]);return 0===t.rows.length?null:d(t.rows[0])}async create(e){return(await n.Z.query(`
      INSERT INTO "DeviceReminderPlan" (
        "DeviceID",
        "ReminderType",
        "EventTypeID",
        "Title",
        "Description",
        "IntervalValue",
        "IntervalUnit",
        "CronExpression",
        "StartFrom",
        "EndAt",
        "NextDueDate",
        "LastTriggeredAt",
        "IsActive",
        "Metadata",
        "CreatedBy",
        "CreatedAt",
        "UpdatedBy",
        "UpdatedAt"
      ) VALUES (
        $1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13,
        $14::jsonb, $15, $16, $17, $18
      )
      RETURNING "ID"
      `,[e.deviceId,e.reminderType,e.eventTypeId||null,e.title||null,e.description||null,e.intervalValue||null,e.intervalUnit||null,e.cronExpression||null,e.startFrom||null,e.endAt||null,e.nextDueDate||null,e.lastTriggeredAt||null,e.isActive??!0,e.metadata?JSON.stringify(e.metadata):null,e.createdBy||null,e.createdAt||(0,i.ud)(),e.updatedBy||e.createdBy||null,e.updatedAt||(0,i.ud)()])).rows[0].ID}async update(e){return await n.Z.query(`
      UPDATE "DeviceReminderPlan" SET
        "DeviceID" = $1,
        "ReminderType" = $2,
        "EventTypeID" = $3,
        "Title" = $4,
        "Description" = $5,
        "IntervalValue" = $6,
        "IntervalUnit" = $7,
        "CronExpression" = $8,
        "StartFrom" = $9,
        "EndAt" = $10,
        "NextDueDate" = $11,
        "LastTriggeredAt" = $12,
        "IsActive" = $13,
        "Metadata" = $14::jsonb,
        "UpdatedBy" = $15,
        "UpdatedAt" = CURRENT_TIMESTAMP
      WHERE "ID" = $16
      `,[e.deviceId,e.reminderType,e.eventTypeId||null,e.title||null,e.description||null,e.intervalValue||null,e.intervalUnit||null,e.cronExpression||null,e.startFrom||null,e.endAt||null,e.nextDueDate||null,e.lastTriggeredAt||null,e.isActive??!0,e.metadata?JSON.stringify(e.metadata):null,e.updatedBy||null,e.id]),e.id}async delete(e){return await n.Z.query('DELETE FROM "DeviceReminderPlan" WHERE "ID" = $1',[e]),!0}}a()}catch(e){a(e)}})},1013:(e,t,r)=>{r.d(t,{J0:()=>s,My:()=>n,_Q:()=>d,rp:()=>i,ud:()=>a});let a=()=>{try{let e=new Date;return new Date(e.toLocaleString("en-US",{timeZone:"Asia/Ho_Chi_Minh"}))}catch{return new Date}},n=()=>{let e=a(),t=e.getFullYear(),r=String(e.getMonth()+1).padStart(2,"0"),n=String(e.getDate()).padStart(2,"0");return`${t}-${r}-${n}`},i=e=>{if(!e)return"";try{let t="string"==typeof e?new Date(e):e;if(Number.isNaN(t.getTime()))return"";return new Intl.DateTimeFormat("en-GB",{timeZone:"Asia/Ho_Chi_Minh",day:"2-digit",month:"2-digit",year:"numeric"}).format(t)}catch(e){return""}},s=e=>{if(!e)return"";try{let t="string"==typeof e?new Date(e):e;if(Number.isNaN(t.getTime()))return"";let r=new Intl.DateTimeFormat("en-GB",{timeZone:"Asia/Ho_Chi_Minh",day:"2-digit",month:"2-digit",year:"numeric"}).formatToParts(t),a=r.find(e=>"year"===e.type)?.value||"",n=r.find(e=>"month"===e.type)?.value||"",i=r.find(e=>"day"===e.type)?.value||"";return`${i}-${n}-${a}`}catch(e){return""}},d=(e,t)=>{if(!e&&!t)return"tất cả thời gian";let r=i(e)||"...",a=i(t)||"...";return`${r} đến ${a}`}}};var t=require("../../../../../webpack-runtime.js");t.C(e);var r=e=>t(t.s=e),a=t.X(0,[8948,5972,2695],()=>r(745));module.exports=a})();