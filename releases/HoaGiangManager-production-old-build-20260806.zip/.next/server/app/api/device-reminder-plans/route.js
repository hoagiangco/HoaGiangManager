"use strict";(()=>{var e={};e.id=6289,e.ids=[6289],e.modules={20399:e=>{e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},30517:e=>{e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},78893:e=>{e.exports=require("buffer")},84770:e=>{e.exports=require("crypto")},92048:e=>{e.exports=require("fs")},19801:e=>{e.exports=require("os")},55315:e=>{e.exports=require("path")},76162:e=>{e.exports=require("stream")},21764:e=>{e.exports=require("util")},8678:e=>{e.exports=import("pg")},28788:(e,t,r)=>{r.a(e,async(e,a)=>{try{r.r(t),r.d(t,{originalPathname:()=>v,patchFetch:()=>d,requestAsyncStorage:()=>p,routeModule:()=>l,serverHooks:()=>y,staticGenerationAsyncStorage:()=>c});var n=r(49303),i=r(88716),s=r(60670),u=r(3123),o=e([u]);u=(o.then?(await o)():o)[0];let l=new n.AppRouteRouteModule({definition:{kind:i.x.APP_ROUTE,page:"/api/device-reminder-plans/route",pathname:"/api/device-reminder-plans",filename:"route",bundlePath:"app/api/device-reminder-plans/route"},resolvedPagePath:"E:\\Web Project\\Nextjs\\HoaGiangManager\\app\\api\\device-reminder-plans\\route.ts",nextConfigOutput:"standalone",userland:u}),{requestAsyncStorage:p,staticGenerationAsyncStorage:c,serverHooks:y}=l,v="/api/device-reminder-plans/route";function d(){return(0,s.patchFetch)({serverHooks:y,staticGenerationAsyncStorage:c})}a()}catch(e){a(e)}})},3123:(e,t,r)=>{r.a(e,async(e,a)=>{try{r.r(t),r.d(t,{GET:()=>d,POST:()=>l,dynamic:()=>m});var n=r(87070),i=r(96899),s=r(64079),u=r(1013),o=e([i,s]);[i,s]=o.then?(await o)():o;let p=new Set(["day","week","month","year"]),c=new Set(["lifecycle","maintenance","warranty","movement","inspection","other","custom"]),y=e=>{if(!e)return null;let t=new Date(e);return Number.isNaN(t.getTime())?null:t},v=e=>e?"object"==typeof e?e:"string"==typeof e&&e.trim()?JSON.parse(e):null:null,m="force-dynamic";async function d(e){try{let{user:t,error:r}=await (0,i.Y)(e);if(!t)return n.NextResponse.json({status:!1,error:r||"Unauthorized"},{status:401});let{searchParams:a}=new URL(e.url),u=a.get("deviceId"),o=u?Number(u):void 0;if(u&&(Number.isNaN(o)||o<0))return n.NextResponse.json({status:!1,error:"deviceId kh\xf4ng hợp lệ"},{status:400});let d=new s._,l=await d.list(o);return n.NextResponse.json({status:!0,data:l})}catch(e){return console.error("Get reminder plans error:",e),n.NextResponse.json({status:!1,error:"Đ\xe3 xảy ra lỗi khi tải kế hoạch nhắc nhở"},{status:500})}}async function l(e){try{let{user:t,error:r}=await (0,i.Y)(e);if(!t)return n.NextResponse.json({status:!1,error:r||"Unauthorized"},{status:401});let a=await e.json();if(!a||"object"!=typeof a)return n.NextResponse.json({status:!1,error:"Dữ liệu kế hoạch kh\xf4ng hợp lệ"},{status:400});let o=Number(a.deviceId);if(!o||Number.isNaN(o))return n.NextResponse.json({status:!1,error:"Vui l\xf2ng chọn thiết bị"},{status:400});let d=String(a.reminderType||"").trim().toLowerCase();if(!d)return n.NextResponse.json({status:!1,error:"Vui l\xf2ng chọn loại nhắc nhở"},{status:400});if(!c.has(d))return n.NextResponse.json({status:!1,error:"Loại nhắc nhở kh\xf4ng hợp lệ"},{status:400});let l=a.eventTypeId?Number(a.eventTypeId):null;if(a.eventTypeId&&Number.isNaN(l))return n.NextResponse.json({status:!1,error:"eventTypeId kh\xf4ng hợp lệ"},{status:400});let m=a.intervalValue?Number(a.intervalValue):null,h=a.intervalUnit?String(a.intervalUnit).toLowerCase():null,D=a.cronExpression?String(a.cronExpression).trim():null;if(null!==m&&(Number.isNaN(m)||m<=0))return n.NextResponse.json({status:!1,error:"Gi\xe1 trị chu kỳ phải lớn hơn 0"},{status:400});if(h&&!p.has(h))return n.NextResponse.json({status:!1,error:"Đơn vị chu kỳ kh\xf4ng hợp lệ"},{status:400});if(!m&&!D)return n.NextResponse.json({status:!1,error:"H\xe3y nhập chu kỳ (interval) hoặc biểu thức Cron"},{status:400});let A=null;try{A=v(a.metadata)}catch(e){return n.NextResponse.json({status:!1,error:e.message||"Metadata phải l\xe0 JSON hợp lệ"},{status:400})}let N={deviceId:o,reminderType:d,eventTypeId:l,title:a.title?String(a.title).trim():null,description:a.description?String(a.description).trim():null,intervalValue:m,intervalUnit:h,cronExpression:D,startFrom:y(a.startFrom),endAt:y(a.endAt),nextDueDate:y(a.nextDueDate),lastTriggeredAt:y(a.lastTriggeredAt),isActive:void 0===a.isActive||!!a.isActive,metadata:A,createdBy:t.userId,createdAt:(0,u.ud)(),updatedBy:t.userId,updatedAt:(0,u.ud)()},T=new s._,g=await T.create(N);return n.NextResponse.json({status:g>0,data:{id:g}})}catch(e){return console.error("Create reminder plan error:",e),n.NextResponse.json({status:!1,error:e.message||"Đ\xe3 xảy ra lỗi khi tạo kế hoạch nhắc nhở"},{status:500})}}a()}catch(e){a(e)}})},73840:(e,t,r)=>{r.d(t,{RA:()=>u,WX:()=>o});var a=r(41482),n=r.n(a);let i=process.env.JWT_SECRET||"your-secret-key-change-this-in-production",s=process.env.JWT_EXPIRES_IN||"24h",u=e=>{if(!i)throw Error("JWT_SECRET is not configured");return n().sign(e,i,{expiresIn:s})},o=e=>{try{return n().verify(e,i)}catch(e){throw Error("Invalid token")}}},96899:(e,t,r)=>{r.a(e,async(e,a)=>{try{r.d(t,{Y:()=>u}),r(87070);var n=r(73840),i=r(97395),s=e([i]);async function u(e){try{let t=e.headers.get("authorization");if(!t||!t.startsWith("Bearer "))return{user:null,error:"No token provided"};let r=t.substring(7),a=(0,n.WX)(r),s=await i.Z.query(`SELECT u."Id", u."Email", u."NormalizedEmail"
       FROM "AspNetUsers" u
       WHERE u."Id" = $1`,[a.userId]);if(0===s.rows.length)return{user:null,error:"User not found"};let u=(await i.Z.query(`SELECT r."Name"
       FROM "AspNetRoles" r
       INNER JOIN "AspNetUserRoles" ur ON r."Id" = ur."RoleId"
       WHERE ur."UserId" = $1`,[a.userId])).rows.map(e=>e.Name);return{user:{userId:a.userId,email:a.email,roles:u},error:null}}catch(e){return console.error("Authentication error:",e.message||e),{user:null,error:e.message||"Invalid token"}}}i=(s.then?(await s)():s)[0],a()}catch(e){a(e)}})},97395:(e,t,r)=>{r.a(e,async(e,a)=>{try{r.d(t,{I:()=>p,Z:()=>l});var n=r(8678),i=r(16636),s=r.n(i),u=e([n]);n=(u.then?(await u)():u)[0],s().config(),s().config({path:".env.local",override:!0}),n.types.setTypeParser(1082,e=>e);let o=process.env.DATABASE_URL?.includes("localhost")||process.env.DATABASE_URL?.includes("127.0.0.1"),d=new n.Pool({connectionString:process.env.DATABASE_URL,ssl:!o&&{rejectUnauthorized:!1}});d.on("connect",e=>{e.query("SET TIME ZONE 'Asia/Ho_Chi_Minh'")});let l=d,p=async(e,t)=>{Date.now();try{let r=await d.query(e,t);return Date.now(),r}catch(t){throw console.error("Database query error",{text:e,error:t}),t}};a()}catch(e){a(e)}})},64079:(e,t,r)=>{r.a(e,async(e,a)=>{try{r.d(t,{_:()=>o});var n=r(97395),i=r(1013),s=e([n]);n=(s.then?(await s)():s)[0];let u=e=>({id:e.id,deviceId:e.deviceId,reminderType:e.reminderType,eventTypeId:e.eventTypeId,title:e.title,description:e.description,intervalValue:e.intervalValue,intervalUnit:e.intervalUnit,cronExpression:e.cronExpression,startFrom:e.startFrom,endAt:e.endAt,nextDueDate:e.nextDueDate,lastTriggeredAt:e.lastTriggeredAt,isActive:e.isActive??!0,metadata:"string"==typeof e.metadata?(()=>{try{return JSON.parse(e.metadata)}catch(e){return null}})():e.metadata||null,createdBy:e.createdBy,createdAt:e.createdAt,updatedBy:e.updatedBy,updatedAt:e.updatedAt});class o{async list(e){let t=[],r="";return e&&e>0&&(t.push(e),r='WHERE p."DeviceID" = $1'),(await n.Z.query(`
      SELECT
        p."ID" as id,
        p."DeviceID" as "deviceId",
        d."Name" as "deviceName",
        p."ReminderType" as "reminderType",
        p."EventTypeID" as "eventTypeId",
        et."Name" as "eventTypeName",
        p."Title" as title,
        p."Description" as description,
        p."IntervalValue" as "intervalValue",
        p."IntervalUnit" as "intervalUnit",
        p."CronExpression" as "cronExpression",
        p."StartFrom" as "startFrom",
        p."EndAt" as "endAt",
        p."NextDueDate" as "nextDueDate",
        p."LastTriggeredAt" as "lastTriggeredAt",
        p."IsActive" as "isActive",
        p."Metadata" as metadata,
        p."CreatedBy" as "createdBy",
        p."CreatedAt" as "createdAt",
        p."UpdatedBy" as "updatedBy",
        p."UpdatedAt" as "updatedAt"
      FROM "DeviceReminderPlan" p
      LEFT JOIN "Device" d ON p."DeviceID" = d."ID"
      LEFT JOIN "EventType" et ON p."EventTypeID" = et."ID"
      ${r}
      ORDER BY p."IsActive" DESC, p."NextDueDate" NULLS LAST, p."ID" DESC
      `,t)).rows.map(e=>({...u(e),deviceName:e.deviceName||void 0,eventTypeName:e.eventTypeName||void 0}))}async getById(e){let t=await n.Z.query(`
      SELECT
        "ID" as id,
        "DeviceID" as "deviceId",
        "ReminderType" as "reminderType",
        "EventTypeID" as "eventTypeId",
        "Title" as title,
        "Description" as description,
        "IntervalValue" as "intervalValue",
        "IntervalUnit" as "intervalUnit",
        "CronExpression" as "cronExpression",
        "StartFrom" as "startFrom",
        "EndAt" as "endAt",
        "NextDueDate" as "nextDueDate",
        "LastTriggeredAt" as "lastTriggeredAt",
        "IsActive" as "isActive",
        "Metadata" as metadata,
        "CreatedBy" as "createdBy",
        "CreatedAt" as "createdAt",
        "UpdatedBy" as "updatedBy",
        "UpdatedAt" as "updatedAt"
      FROM "DeviceReminderPlan"
      WHERE "ID" = $1
      `,[e]);return 0===t.rows.length?null:u(t.rows[0])}async create(e){return(await n.Z.query(`
      INSERT INTO "DeviceReminderPlan" (
        "DeviceID",
        "ReminderType",
        "EventTypeID",
        "Title",
        "Description",
        "IntervalValue",
        "IntervalUnit",
        "CronExpression",
        "StartFrom",
        "EndAt",
        "NextDueDate",
        "LastTriggeredAt",
        "IsActive",
        "Metadata",
        "CreatedBy",
        "CreatedAt",
        "UpdatedBy",
        "UpdatedAt"
      ) VALUES (
        $1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13,
        $14::jsonb, $15, $16, $17, $18
      )
      RETURNING "ID"
      `,[e.deviceId,e.reminderType,e.eventTypeId||null,e.title||null,e.description||null,e.intervalValue||null,e.intervalUnit||null,e.cronExpression||null,e.startFrom||null,e.endAt||null,e.nextDueDate||null,e.lastTriggeredAt||null,e.isActive??!0,e.metadata?JSON.stringify(e.metadata):null,e.createdBy||null,e.createdAt||(0,i.ud)(),e.updatedBy||e.createdBy||null,e.updatedAt||(0,i.ud)()])).rows[0].ID}async update(e){return await n.Z.query(`
      UPDATE "DeviceReminderPlan" SET
        "DeviceID" = $1,
        "ReminderType" = $2,
        "EventTypeID" = $3,
        "Title" = $4,
        "Description" = $5,
        "IntervalValue" = $6,
        "IntervalUnit" = $7,
        "CronExpression" = $8,
        "StartFrom" = $9,
        "EndAt" = $10,
        "NextDueDate" = $11,
        "LastTriggeredAt" = $12,
        "IsActive" = $13,
        "Metadata" = $14::jsonb,
        "UpdatedBy" = $15,
        "UpdatedAt" = CURRENT_TIMESTAMP
      WHERE "ID" = $16
      `,[e.deviceId,e.reminderType,e.eventTypeId||null,e.title||null,e.description||null,e.intervalValue||null,e.intervalUnit||null,e.cronExpression||null,e.startFrom||null,e.endAt||null,e.nextDueDate||null,e.lastTriggeredAt||null,e.isActive??!0,e.metadata?JSON.stringify(e.metadata):null,e.updatedBy||null,e.id]),e.id}async delete(e){return await n.Z.query('DELETE FROM "DeviceReminderPlan" WHERE "ID" = $1',[e]),!0}}a()}catch(e){a(e)}})},1013:(e,t,r)=>{r.d(t,{J0:()=>s,My:()=>n,_Q:()=>u,rp:()=>i,ud:()=>a});let a=()=>{try{let e=new Date;return new Date(e.toLocaleString("en-US",{timeZone:"Asia/Ho_Chi_Minh"}))}catch{return new Date}},n=()=>{let e=a(),t=e.getFullYear(),r=String(e.getMonth()+1).padStart(2,"0"),n=String(e.getDate()).padStart(2,"0");return`${t}-${r}-${n}`},i=e=>{if(!e)return"";try{let t="string"==typeof e?new Date(e):e;if(Number.isNaN(t.getTime()))return"";return new Intl.DateTimeFormat("en-GB",{timeZone:"Asia/Ho_Chi_Minh",day:"2-digit",month:"2-digit",year:"numeric"}).format(t)}catch(e){return""}},s=e=>{if(!e)return"";try{let t="string"==typeof e?new Date(e):e;if(Number.isNaN(t.getTime()))return"";let r=new Intl.DateTimeFormat("en-GB",{timeZone:"Asia/Ho_Chi_Minh",day:"2-digit",month:"2-digit",year:"numeric"}).formatToParts(t),a=r.find(e=>"year"===e.type)?.value||"",n=r.find(e=>"month"===e.type)?.value||"",i=r.find(e=>"day"===e.type)?.value||"";return`${i}-${n}-${a}`}catch(e){return""}},u=(e,t)=>{if(!e&&!t)return"tất cả thời gian";let r=i(e)||"...",a=i(t)||"...";return`${r} đến ${a}`}}};var t=require("../../../webpack-runtime.js");t.C(e);var r=e=>t(t.s=e),a=t.X(0,[8948,5972,2695],()=>r(28788));module.exports=a})();