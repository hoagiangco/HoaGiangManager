"use strict";(()=>{var e={};e.id=163,e.ids=[163],e.modules={20399:e=>{e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},30517:e=>{e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},27790:e=>{e.exports=require("assert")},78893:e=>{e.exports=require("buffer")},84770:e=>{e.exports=require("crypto")},92048:e=>{e.exports=require("fs")},32615:e=>{e.exports=require("http")},35240:e=>{e.exports=require("https")},98216:e=>{e.exports=require("net")},19801:e=>{e.exports=require("os")},55315:e=>{e.exports=require("path")},76162:e=>{e.exports=require("stream")},82452:e=>{e.exports=require("tls")},74175:e=>{e.exports=require("tty")},17360:e=>{e.exports=require("url")},21764:e=>{e.exports=require("util")},8678:e=>{e.exports=import("pg")},86515:(e,t,a)=>{a.a(e,async(e,r)=>{try{a.r(t),a.d(t,{originalPathname:()=>u,patchFetch:()=>o,requestAsyncStorage:()=>D,routeModule:()=>p,serverHooks:()=>m,staticGenerationAsyncStorage:()=>I});var n=a(49303),i=a(88716),s=a(60670),d=a(31329),l=e([d]);d=(l.then?(await l)():l)[0];let p=new n.AppRouteRouteModule({definition:{kind:i.x.APP_ROUTE,page:"/api/damage-reports/route",pathname:"/api/damage-reports",filename:"route",bundlePath:"app/api/damage-reports/route"},resolvedPagePath:"E:\\Web Project\\Nextjs\\HoaGiangManager\\app\\api\\damage-reports\\route.ts",nextConfigOutput:"standalone",userland:d}),{requestAsyncStorage:D,staticGenerationAsyncStorage:I,serverHooks:m}=p,u="/api/damage-reports/route";function o(){return(0,s.patchFetch)({serverHooks:m,staticGenerationAsyncStorage:I})}r()}catch(e){r(e)}})},31329:(e,t,a)=>{a.a(e,async(e,r)=>{try{a.r(t),a.d(t,{GET:()=>I,POST:()=>m});var n=a(87070),i=a(96899),s=a(63760),d=a(59555),l=a(94255),o=a(1013),p=a(20657),D=e([i,s,d]);async function I(e){try{let{user:t,error:r}=await (0,i.Y)(e);if(!t)return n.NextResponse.json({status:!1,error:r||"Unauthorized"},{status:401});let{searchParams:l}=new URL(e.url),D={},I=l.get("status");I&&(D.status=I);let m=l.get("priority");m&&(D.priority=parseInt(m));let u=l.get("deviceId");u&&(D.deviceId=parseInt(u));let c=l.get("reporterId");c&&(D.reporterId=parseInt(c));let E=l.get("handlerId");E&&(D.handlerId=parseInt(E));let w=l.get("departmentId");w&&(D.departmentId=parseInt(w));let R=l.get("search");R&&(D.search=R);let N=l.get("fromDate");N&&(D.fromDate=N);let g=l.get("toDate");g&&(D.toDate=g);let S=l.get("isDeleted");null!==S&&(D.isDeleted="true"===S);let T=new s.k,{isSupervisor:f}=await a.e(5371).then(a.bind(a,25371)),O=f(t.roles),h=new d.B,y=(0,p.Z)((0,o.ud)(),"yyyy-MM-dd");h.implementDuePlans(y,"system",0).catch(e=>{console.error("[damage-reports GET] implementDuePlans error:",e)});let C={...D,currentUserId:t.userId,isAdmin:O},L=await T.getAll(C);return n.NextResponse.json({status:!0,data:L})}catch(e){return console.error("Get damage reports error:",e),n.NextResponse.json({status:!1,error:"Đ\xe3 xảy ra lỗi"},{status:500})}}async function m(e){try{let{user:t,error:a}=await (0,i.Y)(e);if(!t)return n.NextResponse.json({status:!1,error:a||"Unauthorized"},{status:401});let r=await e.json();r.reportDate||(r.reportDate=(0,o.My)()),"maintenance"!==r.deviceSelection&&r.status!==l.OD.Completed?(r.status=l.OD.Pending,r.handlingDate=null,r.completedDate=null):r.status||(r.status=l.OD.Pending),r.priority||(r.priority=l.sd.Normal),void 0===r.createdBy&&(r.createdBy=t.userId);let d=new s.k,p=await d.create(r);return n.NextResponse.json({status:p>0,data:{id:p}})}catch(e){return console.error("Create damage report error:",e),n.NextResponse.json({status:!1,error:e.message||"Đ\xe3 xảy ra lỗi khi tạo b\xe1o c\xe1o"},{status:500})}}[i,s,d]=D.then?(await D)():D,r()}catch(e){r(e)}})},59555:(e,t,a)=>{a.a(e,async(e,r)=>{try{a.d(t,{B:()=>o});var n=a(97395),i=a(94255),s=a(1013),d=e([n]);n=(d.then?(await d)():d)[0];let l=!1;class o{async ensureArchiveSchema(){if(l)return;let e=await n.Z.connect();try{await e.query("BEGIN"),await e.query("SELECT pg_advisory_xact_lock(hashtext('work_plan_archive_schema'))");let t=await e.query(`SELECT is_nullable
         FROM information_schema.columns
         WHERE table_schema = 'public'
           AND table_name = 'WorkPlanItem'
           AND column_name = 'PlanDate'`);t.rows[0]?.is_nullable==="NO"&&await e.query('ALTER TABLE "WorkPlanItem" ALTER COLUMN "PlanDate" DROP NOT NULL'),await e.query(`
        CREATE INDEX IF NOT EXISTS idx_work_plan_item_archive
          ON "WorkPlanItem"("StaffID", "CreatedAt")
          WHERE "PlanDate" IS NULL AND "IsImplemented" = false
      `),await e.query("COMMIT"),l=!0}catch(t){throw await e.query("ROLLBACK"),t}finally{e.release()}}mapRowToVM(e){return{id:e.id,planDate:e.planDate,staffId:e.staffId,damageReportId:e.damageReportId,isNewTask:e.isNewTask,title:e.title,draftData:e.draftData,isImplemented:e.isImplemented,createdBy:e.createdBy,createdAt:e.createdAt,updatedAt:e.updatedAt,staffName:e.staffName,reportStatus:e.reportStatus?parseInt(e.reportStatus):void 0,reportStatusName:e.reportStatusName,reportHandlerId:e.reportHandlerId,reportHandlerName:e.reportHandlerName,deviceName:e.deviceName,location:e.location,deptName:e.deptName,damageContent:e.damageContent,maintenanceBatchId:e.maintenanceBatchId,maintenanceTitle:e.maintenanceTitle}}applyStatusLabel(e){let t={[i.OD.Pending]:"Chờ xử l\xfd",[i.OD.Assigned]:"Đ\xe3 ph\xe2n c\xf4ng",[i.OD.InProgress]:"Đang xử l\xfd",[i.OD.Completed]:"Ho\xe0n th\xe0nh",[i.OD.Cancelled]:"Đ\xe3 hủy",[i.OD.Rejected]:"Từ chối"};return e.reportStatus&&(e.reportStatusName=t[e.reportStatus]||"Kh\xf4ng x\xe1c định"),e}getListQuery(e,t="$2"){return`SELECT
        wpi."ID" as id,
        wpi."PlanDate" as "planDate",
        wpi."StaffID" as "staffId",
        wpi."DamageReportID" as "damageReportId",
        wpi."IsNewTask" as "isNewTask",
        wpi."Title" as title,
        wpi."DraftData" as "draftData",
        wpi."IsImplemented" as "isImplemented",
        wpi."CreatedBy" as "createdBy",
        wpi."CreatedAt" as "createdAt",
        wpi."UpdatedAt" as "updatedAt",
        s."Name" as "staffName",
        dr."Status" as "reportStatus",
        dr."DamageLocation" as "location",
        dr."DamageContent" as "damageContent",
        dr."MaintenanceBatchId" as "maintenanceBatchId",
        COALESCE(
          (SELECT "Title" FROM "DeviceReminderPlan" WHERE "Metadata"->>'maintenanceBatchId' = dr."MaintenanceBatchId" LIMIT 1),
          (SELECT "Title" FROM "Event" WHERE "Metadata"->>'maintenanceBatchId' = dr."MaintenanceBatchId" LIMIT 1)
        ) as "maintenanceTitle",
        dr."HandlerID" as "reportHandlerId",
        h."Name" as "reportHandlerName",
        dep."Name" as "deptName",
        d."Name" as "deviceName"
      FROM "WorkPlanItem" wpi
      LEFT JOIN "Staff" s ON wpi."StaffID" = s."ID"
      LEFT JOIN "DamageReport" dr ON wpi."DamageReportID" = dr."ID"
      LEFT JOIN "Staff" h ON dr."HandlerID" = h."ID"
      LEFT JOIN "Device" d ON dr."DeviceID" = d."ID"
      LEFT JOIN "Department" dep ON dr."ReportingDepartmentID" = dep."ID"
      WHERE ${e}
        AND (COALESCE(dr."HandlerID", wpi."StaffID") = ${t} OR ${t} = 0)
      ORDER BY wpi."ID" ASC`}async list(e,t){return(await n.Z.query(this.getListQuery('wpi."PlanDate" = $1'),[e,t])).rows.map(e=>this.applyStatusLabel(this.mapRowToVM(e)))}async listArchive(e){return await this.ensureArchiveSchema(),(await n.Z.query(this.getListQuery('wpi."PlanDate" IS NULL AND wpi."IsImplemented" = false',"$1"),[e])).rows.map(e=>this.applyStatusLabel(this.mapRowToVM(e)))}async getActiveDates(e,t,a){let r={text:`SELECT DISTINCT wpi."PlanDate"
             FROM "WorkPlanItem" wpi
             LEFT JOIN "DamageReport" dr ON wpi."DamageReportID" = dr."ID"
             WHERE wpi."PlanDate" IS NOT NULL
             AND wpi."PlanDate" >= $1 AND wpi."PlanDate" <= $2
             ${a>0?'AND COALESCE(dr."HandlerID", wpi."StaffID") = $3':""}`,values:a>0?[e,t,a]:[e,t]};return(await n.Z.query(r.text,r.values)).rows.map(e=>{let t=new Date(e.PlanDate);return`${t.getFullYear()}-${String(t.getMonth()+1).padStart(2,"0")}-${String(t.getDate()).padStart(2,"0")}`})}async getOverdueUnimplemented(e,t=!1){return(await n.Z.query(`SELECT
        wpi."ID" as id,
        wpi."PlanDate" as "planDate",
        wpi."StaffID" as "staffId",
        wpi."DamageReportID" as "damageReportId",
        wpi."IsNewTask" as "isNewTask",
        wpi."Title" as title,
        wpi."DraftData" as "draftData",
        wpi."IsImplemented" as "isImplemented",
        wpi."CreatedBy" as "createdBy",
        wpi."CreatedAt" as "createdAt",
        s."Name" as "staffName",
        dr."Status" as "reportStatus",
        dr."DamageLocation" as location,
        dr."DamageContent" as "damageContent",
        dr."MaintenanceBatchId" as "maintenanceBatchId",
        COALESCE(
          (SELECT "Title" FROM "DeviceReminderPlan" WHERE "Metadata"->>'maintenanceBatchId' = dr."MaintenanceBatchId" LIMIT 1),
          (SELECT "Title" FROM "Event" WHERE "Metadata"->>'maintenanceBatchId' = dr."MaintenanceBatchId" LIMIT 1)
        ) as "maintenanceTitle",
        dr."HandlerID" as "reportHandlerId",
        h."Name" as "reportHandlerName",
        d."Name" as "deviceName"
      FROM "WorkPlanItem" wpi
      LEFT JOIN "Staff" s ON wpi."StaffID" = s."ID"
      LEFT JOIN "DamageReport" dr ON wpi."DamageReportID" = dr."ID"
      LEFT JOIN "Staff" h ON dr."HandlerID" = h."ID"
      LEFT JOIN "Device" d ON dr."DeviceID" = d."ID"
      WHERE wpi."PlanDate" IS NOT NULL
        AND wpi."PlanDate" < CURRENT_DATE
        AND wpi."IsImplemented" = false
        AND wpi."IsNewTask" = true
        ${t?"":'AND (COALESCE(dr."HandlerID", wpi."StaffID") = $1 OR $1 = 0)'}
      ORDER BY wpi."PlanDate" DESC, wpi."ID" ASC`,t?[]:[e])).rows}async getPendingReports(e){return(await n.Z.query(`SELECT
        dr."ID" as id,
        dr."DamageContent" as content,
        dr."DamageLocation" as location,
        dr."ReportDate" as "reportDate",
        dr."Status" as status,
        dr."HandlerID" as "handlerId",
        dr."MaintenanceBatchId" as "maintenanceBatchId",
        COALESCE(
          (SELECT "Title" FROM "DeviceReminderPlan" WHERE "Metadata"->>'maintenanceBatchId' = dr."MaintenanceBatchId" LIMIT 1),
          (SELECT "Title" FROM "Event" WHERE "Metadata"->>'maintenanceBatchId' = dr."MaintenanceBatchId" LIMIT 1)
        ) as "maintenanceTitle",
        d."Name" as "deviceName"
      FROM "DamageReport" dr
      LEFT JOIN "Device" d ON dr."DeviceID" = d."ID"
      WHERE (dr."ReporterID" = $1 OR dr."HandlerID" = $1 OR $1 = 0)
      AND dr."Status" IN ('1', '2', '3')
      ORDER BY dr."ReportDate" DESC`,[e])).rows}async create(e){return await this.ensureArchiveSchema(),(await n.Z.query(`INSERT INTO "WorkPlanItem" (
        "PlanDate", "StaffID", "DamageReportID", "IsNewTask", "Title", "DraftData", "IsImplemented", "CreatedBy"
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
      RETURNING "ID"`,[e.planDate||null,e.staffId,e.damageReportId||null,e.isNewTask||!1,e.title,e.draftData?JSON.stringify(e.draftData):null,e.isImplemented||!1,e.createdBy||null])).rows[0].ID}async delete(e,t,a=!1){let r=a?{text:'DELETE FROM "WorkPlanItem" WHERE "ID" = $1',values:[e]}:{text:`DELETE FROM "WorkPlanItem" WHERE "ID" = $1 AND (
                  "StaffID" = $2 OR
                  "DamageReportID" IN (SELECT "ID" FROM "DamageReport" WHERE "HandlerID" = $2)
                )`,values:[e,t]};return((await n.Z.query(r.text,r.values)).rowCount??0)>0}async updateDate(e,t,a,r=!1){let i=r?{text:'UPDATE "WorkPlanItem" SET "PlanDate" = $1 WHERE "ID" = $2',values:[t,e]}:{text:`UPDATE "WorkPlanItem" SET "PlanDate" = $1 WHERE "ID" = $2 AND (
                  "StaffID" = $3 OR
                  "DamageReportID" IN (SELECT "ID" FROM "DamageReport" WHERE "HandlerID" = $3)
                )`,values:[t,e,a]};return((await n.Z.query(i.text,i.values)).rowCount??0)>0}async update(e,t,a,r,i,s=!1){let d=s?{text:'UPDATE "WorkPlanItem" SET "StaffID" = $1, "Title" = $2, "DraftData" = $3 WHERE "ID" = $4 AND "IsImplemented" = false',values:[t,a,r?JSON.stringify(r):null,e]}:{text:`UPDATE "WorkPlanItem" SET "StaffID" = $1, "Title" = $2, "DraftData" = $3 WHERE "ID" = $4 AND "IsImplemented" = false AND (
                  "StaffID" = $5 OR
                  "DamageReportID" IN (SELECT "ID" FROM "DamageReport" WHERE "HandlerID" = $5)
                )`,values:[t,a,r?JSON.stringify(r):null,e,i]};return((await n.Z.query(d.text,d.values)).rowCount??0)>0}async createDamageReportFromPlan(e,t,a){let r=t.DraftData;if(!r?.damageContent||""===r.damageContent.trim())throw Error("Vui l\xf2ng nhập nội dung c\xf4ng việc");let n=await e.query('SELECT "DepartmentID" FROM "Staff" WHERE "ID" = $1',[t.StaffID]),d=r.reportingDepartmentId||n.rows[0]?.DepartmentID||1,l=t.PlanDate||(0,s.ud)();return(await e.query(`INSERT INTO "DamageReport" (
        "DeviceID", "DamageLocation", "ReporterID", "ReportingDepartmentID",
        "HandlerID", "AssignedDate", "ReportDate", "DamageContent", "Images",
        "Status", "Priority", "CreatedBy", "UpdatedBy"
      )
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13)
      RETURNING "ID"`,[r.deviceId||null,r.damageLocation||t.Title||null,r.reporterId||t.StaffID,d,t.StaffID,l,l,r.damageContent,r.images?JSON.stringify(r.images):null,i.OD.Pending.toString(),(r.priority||i.sd.Normal).toString(),a,a])).rows[0].ID}async implementWithClient(e,t,a,r){let n=await e.query(`SELECT wpi.*
       FROM "WorkPlanItem" wpi
       LEFT JOIN "DamageReport" dr ON wpi."DamageReportID" = dr."ID"
       WHERE wpi."ID" = $1
       ${a?'AND COALESCE(dr."HandlerID", wpi."StaffID") = $2':""}
       FOR UPDATE OF wpi`,a?[t,a]:[t]);if(0===n.rows.length)return null;let d=n.rows[0];if(d.IsImplemented)return d.DamageReportID;let l=d.DamageReportID;return d.IsNewTask&&!l?l=await this.createDamageReportFromPlan(e,d,r):l&&await e.query(`UPDATE "DamageReport"
         SET "HandlerID" = COALESCE("HandlerID", $1),
             "AssignedDate" = COALESCE("AssignedDate", $2),
             "Status" = CASE WHEN "Status" = $3 THEN $4 ELSE "Status" END,
             "UpdatedBy" = $5,
             "UpdatedAt" = CURRENT_TIMESTAMP
         WHERE "ID" = $6`,[d.StaffID,d.PlanDate||(0,s.ud)(),i.OD.Pending.toString(),i.OD.Pending.toString(),r,l]),await e.query('UPDATE "WorkPlanItem" SET "IsImplemented" = TRUE, "DamageReportID" = $1, "UpdatedAt" = CURRENT_TIMESTAMP WHERE "ID" = $2',[l,t]),l}async implement(e,t,a){let r=await n.Z.connect();try{await r.query("BEGIN");let n=await this.implementWithClient(r,e,t,a);return await r.query("COMMIT"),n}catch(e){throw await r.query("ROLLBACK"),e}finally{r.release()}}async implementDuePlans(e,t="system",a=0){let r=await n.Z.query(`SELECT wpi."ID"
       FROM "WorkPlanItem" wpi
       LEFT JOIN "DamageReport" dr ON wpi."DamageReportID" = dr."ID"
       WHERE wpi."PlanDate" IS NOT NULL
         AND wpi."PlanDate" <= $1
         AND wpi."IsImplemented" = false
         AND (COALESCE(dr."HandlerID", wpi."StaffID") = $2 OR $2 = 0)
       ORDER BY wpi."PlanDate" ASC, wpi."ID" ASC`,[e,a]),i=0;for(let e of r.rows){let a=await n.Z.connect();try{await a.query("BEGIN");let r=await this.implementWithClient(a,e.ID,null,t);await a.query("COMMIT"),r&&(i+=1)}catch(e){throw await a.query("ROLLBACK"),e}finally{a.release()}}return i}}r()}catch(e){r(e)}})}};var t=require("../../../webpack-runtime.js");t.C(e);var a=e=>t(t.s=e),r=t.X(0,[8948,5972,2695,9092,810,657,583,3760],()=>a(86515));module.exports=r})();