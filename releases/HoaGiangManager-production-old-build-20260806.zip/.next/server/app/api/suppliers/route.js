"use strict";(()=>{var e={};e.id=1554,e.ids=[1554],e.modules={20399:e=>{e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},30517:e=>{e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},78893:e=>{e.exports=require("buffer")},84770:e=>{e.exports=require("crypto")},92048:e=>{e.exports=require("fs")},19801:e=>{e.exports=require("os")},55315:e=>{e.exports=require("path")},76162:e=>{e.exports=require("stream")},21764:e=>{e.exports=require("util")},8678:e=>{e.exports=import("pg")},97394:(e,r,t)=>{t.a(e,async(e,a)=>{try{t.r(r),t.d(r,{originalPathname:()=>d,patchFetch:()=>l,requestAsyncStorage:()=>c,routeModule:()=>p,serverHooks:()=>E,staticGenerationAsyncStorage:()=>I});var s=t(49303),o=t(88716),n=t(60670),i=t(21073),u=e([i]);i=(u.then?(await u)():u)[0];let p=new s.AppRouteRouteModule({definition:{kind:o.x.APP_ROUTE,page:"/api/suppliers/route",pathname:"/api/suppliers",filename:"route",bundlePath:"app/api/suppliers/route"},resolvedPagePath:"E:\\Web Project\\Nextjs\\HoaGiangManager\\app\\api\\suppliers\\route.ts",nextConfigOutput:"standalone",userland:i}),{requestAsyncStorage:c,staticGenerationAsyncStorage:I,serverHooks:E}=p,d="/api/suppliers/route";function l(){return(0,n.patchFetch)({serverHooks:E,staticGenerationAsyncStorage:I})}a()}catch(e){a(e)}})},21073:(e,r,t)=>{t.a(e,async(e,a)=>{try{t.r(r),t.d(r,{GET:()=>u,POST:()=>l});var s=t(87070),o=t(96899),n=t(91780),i=e([o,n]);async function u(e){try{let{user:r,error:t}=await (0,o.Y)(e);if(!r)return s.NextResponse.json({status:!1,error:t||"Unauthorized"},{status:401});let a=new URL(e.url).searchParams,i=a.get("search")||"",u=parseInt(a.get("categoryId")||"0"),l=parseInt(a.get("page")||"1"),p=parseInt(a.get("limit")||"10"),c=new n.p,I=await c.getPaginated({page:l,limit:p,search:i,categoryId:u});return s.NextResponse.json({status:!0,data:I.suppliers,total:I.total})}catch(e){return console.error("Get suppliers error:",e),s.NextResponse.json({status:!1,error:e.message||"Đ\xe3 xảy ra lỗi"},{status:500})}}async function l(e){try{let{user:r,error:a}=await (0,o.Y)(e);if(!r)return s.NextResponse.json({status:!1,error:a||"Unauthorized"},{status:401});let{isAdmin:i}=await t.e(5371).then(t.bind(t,25371));if(!i(r.roles))return s.NextResponse.json({status:!1,error:"Forbidden: Chỉ quản trị vi\xean mới được thao t\xe1c"},{status:403});let u=await e.json(),l=new n.p,p=await l.create(u);return s.NextResponse.json({status:p>0,data:{id:p}})}catch(e){return console.error("Create supplier error:",e),s.NextResponse.json({status:!1,error:e.message||"Đ\xe3 xảy ra lỗi khi tạo nh\xe0 cung cấp"},{status:500})}}[o,n]=i.then?(await i)():i,a()}catch(e){a(e)}})},73840:(e,r,t)=>{t.d(r,{RA:()=>i,WX:()=>u});var a=t(41482),s=t.n(a);let o=process.env.JWT_SECRET||"your-secret-key-change-this-in-production",n=process.env.JWT_EXPIRES_IN||"24h",i=e=>{if(!o)throw Error("JWT_SECRET is not configured");return s().sign(e,o,{expiresIn:n})},u=e=>{try{return s().verify(e,o)}catch(e){throw Error("Invalid token")}}},96899:(e,r,t)=>{t.a(e,async(e,a)=>{try{t.d(r,{Y:()=>i}),t(87070);var s=t(73840),o=t(97395),n=e([o]);async function i(e){try{let r=e.headers.get("authorization");if(!r||!r.startsWith("Bearer "))return{user:null,error:"No token provided"};let t=r.substring(7),a=(0,s.WX)(t),n=await o.Z.query(`SELECT u."Id", u."Email", u."NormalizedEmail"
       FROM "AspNetUsers" u
       WHERE u."Id" = $1`,[a.userId]);if(0===n.rows.length)return{user:null,error:"User not found"};let i=(await o.Z.query(`SELECT r."Name"
       FROM "AspNetRoles" r
       INNER JOIN "AspNetUserRoles" ur ON r."Id" = ur."RoleId"
       WHERE ur."UserId" = $1`,[a.userId])).rows.map(e=>e.Name);return{user:{userId:a.userId,email:a.email,roles:i},error:null}}catch(e){return console.error("Authentication error:",e.message||e),{user:null,error:e.message||"Invalid token"}}}o=(n.then?(await n)():n)[0],a()}catch(e){a(e)}})},97395:(e,r,t)=>{t.a(e,async(e,a)=>{try{t.d(r,{I:()=>c,Z:()=>p});var s=t(8678),o=t(16636),n=t.n(o),i=e([s]);s=(i.then?(await i)():i)[0],n().config(),n().config({path:".env.local",override:!0}),s.types.setTypeParser(1082,e=>e);let u=process.env.DATABASE_URL?.includes("localhost")||process.env.DATABASE_URL?.includes("127.0.0.1"),l=new s.Pool({connectionString:process.env.DATABASE_URL,ssl:!u&&{rejectUnauthorized:!1}});l.on("connect",e=>{e.query("SET TIME ZONE 'Asia/Ho_Chi_Minh'")});let p=l,c=async(e,r)=>{Date.now();try{let t=await l.query(e,r);return Date.now(),t}catch(r){throw console.error("Database query error",{text:e,error:r}),r}};a()}catch(e){a(e)}})},91780:(e,r,t)=>{t.a(e,async(e,a)=>{try{t.d(r,{p:()=>n});var s=t(97395),o=e([s]);s=(o.then?(await o)():o)[0];class n{async getPaginated({page:e=1,limit:r=10,search:t="",categoryId:a=0}){let o=[],n=['s."IsActive" = true'];t&&(o.push(`%${t}%`),n.push(`(
        s."Name" ILIKE $${o.length} OR 
        s."TaxCode" ILIKE $${o.length} OR
        s."ContactPerson" ILIKE $${o.length} OR
        s."Phone" ILIKE $${o.length} OR
        s."Zalo" ILIKE $${o.length}
      )`)),a>0&&(o.push(a),n.push(`
        EXISTS (
          SELECT 1 FROM public."SupplierCategoryMapping" scm 
          WHERE scm."SupplierID" = s."ID" AND scm."CategoryID" = $${o.length}
        )
      `));let i=n.length>0?`WHERE ${n.join(" AND ")}`:"",u=`SELECT COUNT(*) FROM public."Supplier" s ${i}`,l=`
      SELECT 
        s.*, 
        COALESCE(
          json_agg(
            json_build_object('ID', c."ID", 'Name', c."Name")
          ) FILTER (WHERE c."ID" IS NOT NULL), '[]'
        ) as "Categories",
        COALESCE(
          array_agg(c."ID") FILTER (WHERE c."ID" IS NOT NULL), '{}'
        ) as "CategoryIDs"
      FROM public."Supplier" s 
      LEFT JOIN public."SupplierCategoryMapping" scm ON s."ID" = scm."SupplierID"
      LEFT JOIN public."SupplierCategory" c ON scm."CategoryID" = c."ID"
      ${i} 
      GROUP BY s."ID"
      ORDER BY s."ID" DESC 
      LIMIT ${r} OFFSET ${(e-1)*r}
    `,[p,c]=await Promise.all([(0,s.I)(u,o),(0,s.I)(l,o)]);return{suppliers:c.rows,total:parseInt(p.rows[0].count)}}async getById(e){let r=`
      SELECT 
        s.*, 
        COALESCE(
          json_agg(
            json_build_object('ID', c."ID", 'Name', c."Name")
          ) FILTER (WHERE c."ID" IS NOT NULL), '[]'
        ) as "Categories",
        COALESCE(
          array_agg(c."ID") FILTER (WHERE c."ID" IS NOT NULL), '{}'
        ) as "CategoryIDs"
      FROM public."Supplier" s 
      LEFT JOIN public."SupplierCategoryMapping" scm ON s."ID" = scm."SupplierID"
      LEFT JOIN public."SupplierCategory" c ON scm."CategoryID" = c."ID"
      WHERE s."ID" = $1
      GROUP BY s."ID"
    `;return(await (0,s.I)(r,[e])).rows[0]}async create(e){let r=`
      INSERT INTO public."Supplier" (
        "Name", "TaxCode", "ContactPerson", "Phone", "Zalo", "Email", "Address", "Notes"
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
      RETURNING "ID"
    `,t=[e.Name,e.TaxCode||null,e.ContactPerson||null,e.Phone||null,e.Zalo||null,e.Email||null,e.Address||null,e.Notes||null],a=(await (0,s.I)(r,t)).rows[0].ID;if(e.CategoryIDs&&e.CategoryIDs.length>0)for(let r of e.CategoryIDs)await (0,s.I)('INSERT INTO public."SupplierCategoryMapping" ("SupplierID", "CategoryID") VALUES ($1, $2)',[a,r]);return a}async update(e,r){let t=`
      UPDATE public."Supplier" SET
        "Name" = COALESCE($1, "Name"),
        "TaxCode" = $2,
        "ContactPerson" = $3,
        "Phone" = $4,
        "Zalo" = $5,
        "Email" = $6,
        "Address" = $7,
        "Notes" = $8,
        "UpdatedAt" = CURRENT_TIMESTAMP
      WHERE "ID" = $9
      RETURNING "ID"
    `,a=[r.Name,void 0!==r.TaxCode?r.TaxCode:null,void 0!==r.ContactPerson?r.ContactPerson:null,void 0!==r.Phone?r.Phone:null,void 0!==r.Zalo?r.Zalo:null,void 0!==r.Email?r.Email:null,void 0!==r.Address?r.Address:null,void 0!==r.Notes?r.Notes:null,e],o=await (0,s.I)(t,a);if(void 0!==r.CategoryIDs&&(await (0,s.I)('DELETE FROM public."SupplierCategoryMapping" WHERE "SupplierID" = $1',[e]),r.CategoryIDs.length>0))for(let t of r.CategoryIDs)await (0,s.I)('INSERT INTO public."SupplierCategoryMapping" ("SupplierID", "CategoryID") VALUES ($1, $2)',[e,t]);return!!o.rowCount&&o.rowCount>0}async delete(e){let r=await (0,s.I)('UPDATE public."Supplier" SET "IsActive" = false WHERE "ID" = $1',[e]);return!!r.rowCount&&r.rowCount>0}}a()}catch(e){a(e)}})}};var r=require("../../../webpack-runtime.js");r.C(e);var t=e=>r(r.s=e),a=r.X(0,[8948,5972,2695],()=>t(97394));module.exports=a})();