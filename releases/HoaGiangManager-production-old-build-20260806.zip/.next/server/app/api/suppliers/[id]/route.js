"use strict";(()=>{var e={};e.id=2369,e.ids=[2369],e.modules={20399:e=>{e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},30517:e=>{e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},78893:e=>{e.exports=require("buffer")},84770:e=>{e.exports=require("crypto")},92048:e=>{e.exports=require("fs")},19801:e=>{e.exports=require("os")},55315:e=>{e.exports=require("path")},76162:e=>{e.exports=require("stream")},21764:e=>{e.exports=require("util")},8678:e=>{e.exports=import("pg")},34271:(e,r,t)=>{t.a(e,async(e,s)=>{try{t.r(r),t.d(r,{originalPathname:()=>d,patchFetch:()=>l,requestAsyncStorage:()=>c,routeModule:()=>p,serverHooks:()=>E,staticGenerationAsyncStorage:()=>I});var a=t(49303),o=t(88716),n=t(60670),i=t(33594),u=e([i]);i=(u.then?(await u)():u)[0];let p=new a.AppRouteRouteModule({definition:{kind:o.x.APP_ROUTE,page:"/api/suppliers/[id]/route",pathname:"/api/suppliers/[id]",filename:"route",bundlePath:"app/api/suppliers/[id]/route"},resolvedPagePath:"E:\\Web Project\\Nextjs\\HoaGiangManager\\app\\api\\suppliers\\[id]\\route.ts",nextConfigOutput:"standalone",userland:i}),{requestAsyncStorage:c,staticGenerationAsyncStorage:I,serverHooks:E}=p,d="/api/suppliers/[id]/route";function l(){return(0,n.patchFetch)({serverHooks:E,staticGenerationAsyncStorage:I})}s()}catch(e){s(e)}})},33594:(e,r,t)=>{t.a(e,async(e,s)=>{try{t.r(r),t.d(r,{DELETE:()=>p,GET:()=>u,PUT:()=>l});var a=t(87070),o=t(96899),n=t(91780),i=e([o,n]);async function u(e,{params:r}){try{let{user:t,error:s}=await (0,o.Y)(e);if(!t)return a.NextResponse.json({status:!1,error:s||"Unauthorized"},{status:401});let i=new n.p,u=await i.getById(parseInt(r.id));if(!u)return a.NextResponse.json({status:!1,error:"Kh\xf4ng t\xecm thấy nh\xe0 cung cấp"},{status:404});return a.NextResponse.json({status:!0,data:u})}catch(e){return console.error("Get supplier details error:",e),a.NextResponse.json({status:!1,error:e.message||"Đ\xe3 xảy ra lỗi"},{status:500})}}async function l(e,{params:r}){try{let{user:s,error:i}=await (0,o.Y)(e);if(!s)return a.NextResponse.json({status:!1,error:i||"Unauthorized"},{status:401});let{isAdmin:u}=await t.e(5371).then(t.bind(t,25371));if(!u(s.roles))return a.NextResponse.json({status:!1,error:"Forbidden: Chỉ quản trị vi\xean mới được thao t\xe1c"},{status:403});let l=await e.json(),p=new n.p,c=await p.update(parseInt(r.id),l);return a.NextResponse.json({status:c,message:c?"Cập nhật th\xe0nh c\xf4ng":"Cập nhật thất bại"})}catch(e){return console.error("Update supplier error:",e),a.NextResponse.json({status:!1,error:e.message||"Đ\xe3 xảy ra lỗi khi cập nhật"},{status:500})}}async function p(e,{params:r}){try{let{user:s,error:i}=await (0,o.Y)(e);if(!s)return a.NextResponse.json({status:!1,error:i||"Unauthorized"},{status:401});let{isAdmin:u}=await t.e(5371).then(t.bind(t,25371));if(!u(s.roles))return a.NextResponse.json({status:!1,error:"Forbidden: Chỉ quản trị vi\xean mới được thao t\xe1c"},{status:403});let l=new n.p,p=await l.delete(parseInt(r.id));return a.NextResponse.json({status:p,message:p?"X\xf3a th\xe0nh c\xf4ng":"X\xf3a thất bại"})}catch(e){return console.error("Delete supplier error:",e),a.NextResponse.json({status:!1,error:e.message||"Đ\xe3 xảy ra lỗi khi x\xf3a"},{status:500})}}[o,n]=i.then?(await i)():i,s()}catch(e){s(e)}})},73840:(e,r,t)=>{t.d(r,{RA:()=>i,WX:()=>u});var s=t(41482),a=t.n(s);let o=process.env.JWT_SECRET||"your-secret-key-change-this-in-production",n=process.env.JWT_EXPIRES_IN||"24h",i=e=>{if(!o)throw Error("JWT_SECRET is not configured");return a().sign(e,o,{expiresIn:n})},u=e=>{try{return a().verify(e,o)}catch(e){throw Error("Invalid token")}}},96899:(e,r,t)=>{t.a(e,async(e,s)=>{try{t.d(r,{Y:()=>i}),t(87070);var a=t(73840),o=t(97395),n=e([o]);async function i(e){try{let r=e.headers.get("authorization");if(!r||!r.startsWith("Bearer "))return{user:null,error:"No token provided"};let t=r.substring(7),s=(0,a.WX)(t),n=await o.Z.query(`SELECT u."Id", u."Email", u."NormalizedEmail"
       FROM "AspNetUsers" u
       WHERE u."Id" = $1`,[s.userId]);if(0===n.rows.length)return{user:null,error:"User not found"};let i=(await o.Z.query(`SELECT r."Name"
       FROM "AspNetRoles" r
       INNER JOIN "AspNetUserRoles" ur ON r."Id" = ur."RoleId"
       WHERE ur."UserId" = $1`,[s.userId])).rows.map(e=>e.Name);return{user:{userId:s.userId,email:s.email,roles:i},error:null}}catch(e){return console.error("Authentication error:",e.message||e),{user:null,error:e.message||"Invalid token"}}}o=(n.then?(await n)():n)[0],s()}catch(e){s(e)}})},97395:(e,r,t)=>{t.a(e,async(e,s)=>{try{t.d(r,{I:()=>c,Z:()=>p});var a=t(8678),o=t(16636),n=t.n(o),i=e([a]);a=(i.then?(await i)():i)[0],n().config(),n().config({path:".env.local",override:!0}),a.types.setTypeParser(1082,e=>e);let u=process.env.DATABASE_URL?.includes("localhost")||process.env.DATABASE_URL?.includes("127.0.0.1"),l=new a.Pool({connectionString:process.env.DATABASE_URL,ssl:!u&&{rejectUnauthorized:!1}});l.on("connect",e=>{e.query("SET TIME ZONE 'Asia/Ho_Chi_Minh'")});let p=l,c=async(e,r)=>{Date.now();try{let t=await l.query(e,r);return Date.now(),t}catch(r){throw console.error("Database query error",{text:e,error:r}),r}};s()}catch(e){s(e)}})},91780:(e,r,t)=>{t.a(e,async(e,s)=>{try{t.d(r,{p:()=>n});var a=t(97395),o=e([a]);a=(o.then?(await o)():o)[0];class n{async getPaginated({page:e=1,limit:r=10,search:t="",categoryId:s=0}){let o=[],n=['s."IsActive" = true'];t&&(o.push(`%${t}%`),n.push(`(
        s."Name" ILIKE $${o.length} OR 
        s."TaxCode" ILIKE $${o.length} OR
        s."ContactPerson" ILIKE $${o.length} OR
        s."Phone" ILIKE $${o.length} OR
        s."Zalo" ILIKE $${o.length}
      )`)),s>0&&(o.push(s),n.push(`
        EXISTS (
          SELECT 1 FROM public."SupplierCategoryMapping" scm 
          WHERE scm."SupplierID" = s."ID" AND scm."CategoryID" = $${o.length}
        )
      `));let i=n.length>0?`WHERE ${n.join(" AND ")}`:"",u=`SELECT COUNT(*) FROM public."Supplier" s ${i}`,l=`
      SELECT 
        s.*, 
        COALESCE(
          json_agg(
            json_build_object('ID', c."ID", 'Name', c."Name")
          ) FILTER (WHERE c."ID" IS NOT NULL), '[]'
        ) as "Categories",
        COALESCE(
          array_agg(c."ID") FILTER (WHERE c."ID" IS NOT NULL), '{}'
        ) as "CategoryIDs"
      FROM public."Supplier" s 
      LEFT JOIN public."SupplierCategoryMapping" scm ON s."ID" = scm."SupplierID"
      LEFT JOIN public."SupplierCategory" c ON scm."CategoryID" = c."ID"
      ${i} 
      GROUP BY s."ID"
      ORDER BY s."ID" DESC 
      LIMIT ${r} OFFSET ${(e-1)*r}
    `,[p,c]=await Promise.all([(0,a.I)(u,o),(0,a.I)(l,o)]);return{suppliers:c.rows,total:parseInt(p.rows[0].count)}}async getById(e){let r=`
      SELECT 
        s.*, 
        COALESCE(
          json_agg(
            json_build_object('ID', c."ID", 'Name', c."Name")
          ) FILTER (WHERE c."ID" IS NOT NULL), '[]'
        ) as "Categories",
        COALESCE(
          array_agg(c."ID") FILTER (WHERE c."ID" IS NOT NULL), '{}'
        ) as "CategoryIDs"
      FROM public."Supplier" s 
      LEFT JOIN public."SupplierCategoryMapping" scm ON s."ID" = scm."SupplierID"
      LEFT JOIN public."SupplierCategory" c ON scm."CategoryID" = c."ID"
      WHERE s."ID" = $1
      GROUP BY s."ID"
    `;return(await (0,a.I)(r,[e])).rows[0]}async create(e){let r=`
      INSERT INTO public."Supplier" (
        "Name", "TaxCode", "ContactPerson", "Phone", "Zalo", "Email", "Address", "Notes"
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
      RETURNING "ID"
    `,t=[e.Name,e.TaxCode||null,e.ContactPerson||null,e.Phone||null,e.Zalo||null,e.Email||null,e.Address||null,e.Notes||null],s=(await (0,a.I)(r,t)).rows[0].ID;if(e.CategoryIDs&&e.CategoryIDs.length>0)for(let r of e.CategoryIDs)await (0,a.I)('INSERT INTO public."SupplierCategoryMapping" ("SupplierID", "CategoryID") VALUES ($1, $2)',[s,r]);return s}async update(e,r){let t=`
      UPDATE public."Supplier" SET
        "Name" = COALESCE($1, "Name"),
        "TaxCode" = $2,
        "ContactPerson" = $3,
        "Phone" = $4,
        "Zalo" = $5,
        "Email" = $6,
        "Address" = $7,
        "Notes" = $8,
        "UpdatedAt" = CURRENT_TIMESTAMP
      WHERE "ID" = $9
      RETURNING "ID"
    `,s=[r.Name,void 0!==r.TaxCode?r.TaxCode:null,void 0!==r.ContactPerson?r.ContactPerson:null,void 0!==r.Phone?r.Phone:null,void 0!==r.Zalo?r.Zalo:null,void 0!==r.Email?r.Email:null,void 0!==r.Address?r.Address:null,void 0!==r.Notes?r.Notes:null,e],o=await (0,a.I)(t,s);if(void 0!==r.CategoryIDs&&(await (0,a.I)('DELETE FROM public."SupplierCategoryMapping" WHERE "SupplierID" = $1',[e]),r.CategoryIDs.length>0))for(let t of r.CategoryIDs)await (0,a.I)('INSERT INTO public."SupplierCategoryMapping" ("SupplierID", "CategoryID") VALUES ($1, $2)',[e,t]);return!!o.rowCount&&o.rowCount>0}async delete(e){let r=await (0,a.I)('UPDATE public."Supplier" SET "IsActive" = false WHERE "ID" = $1',[e]);return!!r.rowCount&&r.rowCount>0}}s()}catch(e){s(e)}})}};var r=require("../../../../webpack-runtime.js");r.C(e);var t=e=>r(r.s=e),s=r.X(0,[8948,5972,2695],()=>t(34271));module.exports=s})();