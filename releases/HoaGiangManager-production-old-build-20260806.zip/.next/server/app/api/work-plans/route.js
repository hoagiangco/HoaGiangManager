(()=>{var e={};e.id=5300,e.ids=[5300],e.modules={20399:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},30517:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},84770:e=>{"use strict";e.exports=require("crypto")},92048:e=>{"use strict";e.exports=require("fs")},19801:e=>{"use strict";e.exports=require("os")},55315:e=>{"use strict";e.exports=require("path")},8678:e=>{"use strict";e.exports=import("pg")},96684:(e,t,a)=>{"use strict";a.a(e,async(e,r)=>{try{a.r(t),a.d(t,{originalPathname:()=>I,patchFetch:()=>d,requestAsyncStorage:()=>c,routeModule:()=>p,serverHooks:()=>D,staticGenerationAsyncStorage:()=>u});var n=a(49303),s=a(88716),i=a(60670),o=a(83050),l=e([o]);o=(l.then?(await l)():l)[0];let p=new n.AppRouteRouteModule({definition:{kind:s.x.APP_ROUTE,page:"/api/work-plans/route",pathname:"/api/work-plans",filename:"route",bundlePath:"app/api/work-plans/route"},resolvedPagePath:"E:\\Web Project\\Nextjs\\HoaGiangManager\\app\\api\\work-plans\\route.ts",nextConfigOutput:"standalone",userland:o}),{requestAsyncStorage:c,staticGenerationAsyncStorage:u,serverHooks:D}=p,I="/api/work-plans/route";function d(){return(0,i.patchFetch)({serverHooks:D,staticGenerationAsyncStorage:u})}r()}catch(e){r(e)}})},83050:(e,t,a)=>{"use strict";a.a(e,async(e,r)=>{try{a.r(t),a.d(t,{DELETE:()=>c,GET:()=>d,POST:()=>p});var n=a(87070),s=a(59555),i=a(20657),o=a(1013),l=e([s]);let u=new(s=(l.then?(await l)():l)[0]).B;async function d(e){try{let{searchParams:t}=new URL(e.url),a=t.get("date"),r=t.get("staffId"),s="true"===t.get("archive");if(!r)return n.NextResponse.json({status:!1,error:"Missing staffId"},{status:400});if(s){let e=await u.listArchive(parseInt(r));return n.NextResponse.json({status:!0,data:e})}if(!a)return n.NextResponse.json({status:!1,error:"Missing date"},{status:400});let l=(0,i.Z)((0,o.ud)(),"yyyy-MM-dd");a<=l&&await u.implementDuePlans(l,"system",parseInt(r));let d=await u.list(a,parseInt(r));return n.NextResponse.json({status:!0,data:d})}catch(e){return n.NextResponse.json({status:!1,error:e.message},{status:500})}}async function p(e){try{let t=await e.json(),a=await u.create(t);return n.NextResponse.json({status:!0,data:{id:a}})}catch(e){return n.NextResponse.json({status:!1,error:e.message},{status:500})}}async function c(e){try{let{searchParams:t}=new URL(e.url),a=t.get("id"),r=t.get("staffId"),s="true"===t.get("isAdmin");if(!a||!r)return n.NextResponse.json({status:!1,error:"Missing id or staffId"},{status:400});let i=await u.delete(parseInt(a),parseInt(r),s);return n.NextResponse.json({status:i})}catch(e){return n.NextResponse.json({status:!1,error:e.message},{status:500})}}r()}catch(e){r(e)}})},97395:(e,t,a)=>{"use strict";a.a(e,async(e,r)=>{try{a.d(t,{I:()=>c,Z:()=>p});var n=a(8678),s=a(16636),i=a.n(s),o=e([n]);n=(o.then?(await o)():o)[0],i().config(),i().config({path:".env.local",override:!0}),n.types.setTypeParser(1082,e=>e);let l=process.env.DATABASE_URL?.includes("localhost")||process.env.DATABASE_URL?.includes("127.0.0.1"),d=new n.Pool({connectionString:process.env.DATABASE_URL,ssl:!l&&{rejectUnauthorized:!1}});d.on("connect",e=>{e.query("SET TIME ZONE 'Asia/Ho_Chi_Minh'")});let p=d,c=async(e,t)=>{Date.now();try{let a=await d.query(e,t);return Date.now(),a}catch(t){throw console.error("Database query error",{text:e,error:t}),t}};r()}catch(e){r(e)}})},59555:(e,t,a)=>{"use strict";a.a(e,async(e,r)=>{try{a.d(t,{B:()=>d});var n=a(97395),s=a(94255),i=a(1013),o=e([n]);n=(o.then?(await o)():o)[0];let l=!1;class d{async ensureArchiveSchema(){if(l)return;let e=await n.Z.connect();try{await e.query("BEGIN"),await e.query("SELECT pg_advisory_xact_lock(hashtext('work_plan_archive_schema'))");let t=await e.query(`SELECT is_nullable
         FROM information_schema.columns
         WHERE table_schema = 'public'
           AND table_name = 'WorkPlanItem'
           AND column_name = 'PlanDate'`);t.rows[0]?.is_nullable==="NO"&&await e.query('ALTER TABLE "WorkPlanItem" ALTER COLUMN "PlanDate" DROP NOT NULL'),await e.query(`
        CREATE INDEX IF NOT EXISTS idx_work_plan_item_archive
          ON "WorkPlanItem"("StaffID", "CreatedAt")
          WHERE "PlanDate" IS NULL AND "IsImplemented" = false
      `),await e.query("COMMIT"),l=!0}catch(t){throw await e.query("ROLLBACK"),t}finally{e.release()}}mapRowToVM(e){return{id:e.id,planDate:e.planDate,staffId:e.staffId,damageReportId:e.damageReportId,isNewTask:e.isNewTask,title:e.title,draftData:e.draftData,isImplemented:e.isImplemented,createdBy:e.createdBy,createdAt:e.createdAt,updatedAt:e.updatedAt,staffName:e.staffName,reportStatus:e.reportStatus?parseInt(e.reportStatus):void 0,reportStatusName:e.reportStatusName,reportHandlerId:e.reportHandlerId,reportHandlerName:e.reportHandlerName,deviceName:e.deviceName,location:e.location,deptName:e.deptName,damageContent:e.damageContent,maintenanceBatchId:e.maintenanceBatchId,maintenanceTitle:e.maintenanceTitle}}applyStatusLabel(e){let t={[s.OD.Pending]:"Chờ xử l\xfd",[s.OD.Assigned]:"Đ\xe3 ph\xe2n c\xf4ng",[s.OD.InProgress]:"Đang xử l\xfd",[s.OD.Completed]:"Ho\xe0n th\xe0nh",[s.OD.Cancelled]:"Đ\xe3 hủy",[s.OD.Rejected]:"Từ chối"};return e.reportStatus&&(e.reportStatusName=t[e.reportStatus]||"Kh\xf4ng x\xe1c định"),e}getListQuery(e,t="$2"){return`SELECT
        wpi."ID" as id,
        wpi."PlanDate" as "planDate",
        wpi."StaffID" as "staffId",
        wpi."DamageReportID" as "damageReportId",
        wpi."IsNewTask" as "isNewTask",
        wpi."Title" as title,
        wpi."DraftData" as "draftData",
        wpi."IsImplemented" as "isImplemented",
        wpi."CreatedBy" as "createdBy",
        wpi."CreatedAt" as "createdAt",
        wpi."UpdatedAt" as "updatedAt",
        s."Name" as "staffName",
        dr."Status" as "reportStatus",
        dr."DamageLocation" as "location",
        dr."DamageContent" as "damageContent",
        dr."MaintenanceBatchId" as "maintenanceBatchId",
        COALESCE(
          (SELECT "Title" FROM "DeviceReminderPlan" WHERE "Metadata"->>'maintenanceBatchId' = dr."MaintenanceBatchId" LIMIT 1),
          (SELECT "Title" FROM "Event" WHERE "Metadata"->>'maintenanceBatchId' = dr."MaintenanceBatchId" LIMIT 1)
        ) as "maintenanceTitle",
        dr."HandlerID" as "reportHandlerId",
        h."Name" as "reportHandlerName",
        dep."Name" as "deptName",
        d."Name" as "deviceName"
      FROM "WorkPlanItem" wpi
      LEFT JOIN "Staff" s ON wpi."StaffID" = s."ID"
      LEFT JOIN "DamageReport" dr ON wpi."DamageReportID" = dr."ID"
      LEFT JOIN "Staff" h ON dr."HandlerID" = h."ID"
      LEFT JOIN "Device" d ON dr."DeviceID" = d."ID"
      LEFT JOIN "Department" dep ON dr."ReportingDepartmentID" = dep."ID"
      WHERE ${e}
        AND (COALESCE(dr."HandlerID", wpi."StaffID") = ${t} OR ${t} = 0)
      ORDER BY wpi."ID" ASC`}async list(e,t){return(await n.Z.query(this.getListQuery('wpi."PlanDate" = $1'),[e,t])).rows.map(e=>this.applyStatusLabel(this.mapRowToVM(e)))}async listArchive(e){return await this.ensureArchiveSchema(),(await n.Z.query(this.getListQuery('wpi."PlanDate" IS NULL AND wpi."IsImplemented" = false',"$1"),[e])).rows.map(e=>this.applyStatusLabel(this.mapRowToVM(e)))}async getActiveDates(e,t,a){let r={text:`SELECT DISTINCT wpi."PlanDate"
             FROM "WorkPlanItem" wpi
             LEFT JOIN "DamageReport" dr ON wpi."DamageReportID" = dr."ID"
             WHERE wpi."PlanDate" IS NOT NULL
             AND wpi."PlanDate" >= $1 AND wpi."PlanDate" <= $2
             ${a>0?'AND COALESCE(dr."HandlerID", wpi."StaffID") = $3':""}`,values:a>0?[e,t,a]:[e,t]};return(await n.Z.query(r.text,r.values)).rows.map(e=>{let t=new Date(e.PlanDate);return`${t.getFullYear()}-${String(t.getMonth()+1).padStart(2,"0")}-${String(t.getDate()).padStart(2,"0")}`})}async getOverdueUnimplemented(e,t=!1){return(await n.Z.query(`SELECT
        wpi."ID" as id,
        wpi."PlanDate" as "planDate",
        wpi."StaffID" as "staffId",
        wpi."DamageReportID" as "damageReportId",
        wpi."IsNewTask" as "isNewTask",
        wpi."Title" as title,
        wpi."DraftData" as "draftData",
        wpi."IsImplemented" as "isImplemented",
        wpi."CreatedBy" as "createdBy",
        wpi."CreatedAt" as "createdAt",
        s."Name" as "staffName",
        dr."Status" as "reportStatus",
        dr."DamageLocation" as location,
        dr."DamageContent" as "damageContent",
        dr."MaintenanceBatchId" as "maintenanceBatchId",
        COALESCE(
          (SELECT "Title" FROM "DeviceReminderPlan" WHERE "Metadata"->>'maintenanceBatchId' = dr."MaintenanceBatchId" LIMIT 1),
          (SELECT "Title" FROM "Event" WHERE "Metadata"->>'maintenanceBatchId' = dr."MaintenanceBatchId" LIMIT 1)
        ) as "maintenanceTitle",
        dr."HandlerID" as "reportHandlerId",
        h."Name" as "reportHandlerName",
        d."Name" as "deviceName"
      FROM "WorkPlanItem" wpi
      LEFT JOIN "Staff" s ON wpi."StaffID" = s."ID"
      LEFT JOIN "DamageReport" dr ON wpi."DamageReportID" = dr."ID"
      LEFT JOIN "Staff" h ON dr."HandlerID" = h."ID"
      LEFT JOIN "Device" d ON dr."DeviceID" = d."ID"
      WHERE wpi."PlanDate" IS NOT NULL
        AND wpi."PlanDate" < CURRENT_DATE
        AND wpi."IsImplemented" = false
        AND wpi."IsNewTask" = true
        ${t?"":'AND (COALESCE(dr."HandlerID", wpi."StaffID") = $1 OR $1 = 0)'}
      ORDER BY wpi."PlanDate" DESC, wpi."ID" ASC`,t?[]:[e])).rows}async getPendingReports(e){return(await n.Z.query(`SELECT
        dr."ID" as id,
        dr."DamageContent" as content,
        dr."DamageLocation" as location,
        dr."ReportDate" as "reportDate",
        dr."Status" as status,
        dr."HandlerID" as "handlerId",
        dr."MaintenanceBatchId" as "maintenanceBatchId",
        COALESCE(
          (SELECT "Title" FROM "DeviceReminderPlan" WHERE "Metadata"->>'maintenanceBatchId' = dr."MaintenanceBatchId" LIMIT 1),
          (SELECT "Title" FROM "Event" WHERE "Metadata"->>'maintenanceBatchId' = dr."MaintenanceBatchId" LIMIT 1)
        ) as "maintenanceTitle",
        d."Name" as "deviceName"
      FROM "DamageReport" dr
      LEFT JOIN "Device" d ON dr."DeviceID" = d."ID"
      WHERE (dr."ReporterID" = $1 OR dr."HandlerID" = $1 OR $1 = 0)
      AND dr."Status" IN ('1', '2', '3')
      ORDER BY dr."ReportDate" DESC`,[e])).rows}async create(e){return await this.ensureArchiveSchema(),(await n.Z.query(`INSERT INTO "WorkPlanItem" (
        "PlanDate", "StaffID", "DamageReportID", "IsNewTask", "Title", "DraftData", "IsImplemented", "CreatedBy"
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
      RETURNING "ID"`,[e.planDate||null,e.staffId,e.damageReportId||null,e.isNewTask||!1,e.title,e.draftData?JSON.stringify(e.draftData):null,e.isImplemented||!1,e.createdBy||null])).rows[0].ID}async delete(e,t,a=!1){let r=a?{text:'DELETE FROM "WorkPlanItem" WHERE "ID" = $1',values:[e]}:{text:`DELETE FROM "WorkPlanItem" WHERE "ID" = $1 AND (
                  "StaffID" = $2 OR
                  "DamageReportID" IN (SELECT "ID" FROM "DamageReport" WHERE "HandlerID" = $2)
                )`,values:[e,t]};return((await n.Z.query(r.text,r.values)).rowCount??0)>0}async updateDate(e,t,a,r=!1){let s=r?{text:'UPDATE "WorkPlanItem" SET "PlanDate" = $1 WHERE "ID" = $2',values:[t,e]}:{text:`UPDATE "WorkPlanItem" SET "PlanDate" = $1 WHERE "ID" = $2 AND (
                  "StaffID" = $3 OR
                  "DamageReportID" IN (SELECT "ID" FROM "DamageReport" WHERE "HandlerID" = $3)
                )`,values:[t,e,a]};return((await n.Z.query(s.text,s.values)).rowCount??0)>0}async update(e,t,a,r,s,i=!1){let o=i?{text:'UPDATE "WorkPlanItem" SET "StaffID" = $1, "Title" = $2, "DraftData" = $3 WHERE "ID" = $4 AND "IsImplemented" = false',values:[t,a,r?JSON.stringify(r):null,e]}:{text:`UPDATE "WorkPlanItem" SET "StaffID" = $1, "Title" = $2, "DraftData" = $3 WHERE "ID" = $4 AND "IsImplemented" = false AND (
                  "StaffID" = $5 OR
                  "DamageReportID" IN (SELECT "ID" FROM "DamageReport" WHERE "HandlerID" = $5)
                )`,values:[t,a,r?JSON.stringify(r):null,e,s]};return((await n.Z.query(o.text,o.values)).rowCount??0)>0}async createDamageReportFromPlan(e,t,a){let r=t.DraftData;if(!r?.damageContent||""===r.damageContent.trim())throw Error("Vui l\xf2ng nhập nội dung c\xf4ng việc");let n=await e.query('SELECT "DepartmentID" FROM "Staff" WHERE "ID" = $1',[t.StaffID]),o=r.reportingDepartmentId||n.rows[0]?.DepartmentID||1,l=t.PlanDate||(0,i.ud)();return(await e.query(`INSERT INTO "DamageReport" (
        "DeviceID", "DamageLocation", "ReporterID", "ReportingDepartmentID",
        "HandlerID", "AssignedDate", "ReportDate", "DamageContent", "Images",
        "Status", "Priority", "CreatedBy", "UpdatedBy"
      )
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13)
      RETURNING "ID"`,[r.deviceId||null,r.damageLocation||t.Title||null,r.reporterId||t.StaffID,o,t.StaffID,l,l,r.damageContent,r.images?JSON.stringify(r.images):null,s.OD.Pending.toString(),(r.priority||s.sd.Normal).toString(),a,a])).rows[0].ID}async implementWithClient(e,t,a,r){let n=await e.query(`SELECT wpi.*
       FROM "WorkPlanItem" wpi
       LEFT JOIN "DamageReport" dr ON wpi."DamageReportID" = dr."ID"
       WHERE wpi."ID" = $1
       ${a?'AND COALESCE(dr."HandlerID", wpi."StaffID") = $2':""}
       FOR UPDATE OF wpi`,a?[t,a]:[t]);if(0===n.rows.length)return null;let o=n.rows[0];if(o.IsImplemented)return o.DamageReportID;let l=o.DamageReportID;return o.IsNewTask&&!l?l=await this.createDamageReportFromPlan(e,o,r):l&&await e.query(`UPDATE "DamageReport"
         SET "HandlerID" = COALESCE("HandlerID", $1),
             "AssignedDate" = COALESCE("AssignedDate", $2),
             "Status" = CASE WHEN "Status" = $3 THEN $4 ELSE "Status" END,
             "UpdatedBy" = $5,
             "UpdatedAt" = CURRENT_TIMESTAMP
         WHERE "ID" = $6`,[o.StaffID,o.PlanDate||(0,i.ud)(),s.OD.Pending.toString(),s.OD.Pending.toString(),r,l]),await e.query('UPDATE "WorkPlanItem" SET "IsImplemented" = TRUE, "DamageReportID" = $1, "UpdatedAt" = CURRENT_TIMESTAMP WHERE "ID" = $2',[l,t]),l}async implement(e,t,a){let r=await n.Z.connect();try{await r.query("BEGIN");let n=await this.implementWithClient(r,e,t,a);return await r.query("COMMIT"),n}catch(e){throw await r.query("ROLLBACK"),e}finally{r.release()}}async implementDuePlans(e,t="system",a=0){let r=await n.Z.query(`SELECT wpi."ID"
       FROM "WorkPlanItem" wpi
       LEFT JOIN "DamageReport" dr ON wpi."DamageReportID" = dr."ID"
       WHERE wpi."PlanDate" IS NOT NULL
         AND wpi."PlanDate" <= $1
         AND wpi."IsImplemented" = false
         AND (COALESCE(dr."HandlerID", wpi."StaffID") = $2 OR $2 = 0)
       ORDER BY wpi."PlanDate" ASC, wpi."ID" ASC`,[e,a]),s=0;for(let e of r.rows){let a=await n.Z.connect();try{await a.query("BEGIN");let r=await this.implementWithClient(a,e.ID,null,t);await a.query("COMMIT"),r&&(s+=1)}catch(e){throw await a.query("ROLLBACK"),e}finally{a.release()}}return s}}r()}catch(e){r(e)}})},1013:(e,t,a)=>{"use strict";a.d(t,{J0:()=>i,My:()=>n,_Q:()=>o,rp:()=>s,ud:()=>r});let r=()=>{try{let e=new Date;return new Date(e.toLocaleString("en-US",{timeZone:"Asia/Ho_Chi_Minh"}))}catch{return new Date}},n=()=>{let e=r(),t=e.getFullYear(),a=String(e.getMonth()+1).padStart(2,"0"),n=String(e.getDate()).padStart(2,"0");return`${t}-${a}-${n}`},s=e=>{if(!e)return"";try{let t="string"==typeof e?new Date(e):e;if(Number.isNaN(t.getTime()))return"";return new Intl.DateTimeFormat("en-GB",{timeZone:"Asia/Ho_Chi_Minh",day:"2-digit",month:"2-digit",year:"numeric"}).format(t)}catch(e){return""}},i=e=>{if(!e)return"";try{let t="string"==typeof e?new Date(e):e;if(Number.isNaN(t.getTime()))return"";let a=new Intl.DateTimeFormat("en-GB",{timeZone:"Asia/Ho_Chi_Minh",day:"2-digit",month:"2-digit",year:"numeric"}).formatToParts(t),r=a.find(e=>"year"===e.type)?.value||"",n=a.find(e=>"month"===e.type)?.value||"",s=a.find(e=>"day"===e.type)?.value||"";return`${s}-${n}-${r}`}catch(e){return""}},o=(e,t)=>{if(!e&&!t)return"tất cả thời gian";let a=s(e)||"...",r=s(t)||"...";return`${a} đến ${r}`}},16636:(e,t,a)=>{let r=a(92048),n=a(55315),s=a(19801),i=a(84770),o=a(71564).version,l=/(?:^|^)\s*(?:export\s+)?([\w.-]+)(?:\s*=\s*?|:\s+?)(\s*'(?:\\'|[^'])*'|\s*"(?:\\"|[^"])*"|\s*`(?:\\`|[^`])*`|[^#\r\n]+)?\s*(?:#.*)?(?:$|$)/mg;function d(e){console.log(`[dotenv@${o}][DEBUG] ${e}`)}function p(e){console.log(`[dotenv@${o}] ${e}`)}function c(e){return e&&e.DOTENV_KEY&&e.DOTENV_KEY.length>0?e.DOTENV_KEY:process.env.DOTENV_KEY&&process.env.DOTENV_KEY.length>0?process.env.DOTENV_KEY:""}function u(e){let t=null;if(e&&e.path&&e.path.length>0){if(Array.isArray(e.path))for(let a of e.path)r.existsSync(a)&&(t=a.endsWith(".vault")?a:`${a}.vault`);else t=e.path.endsWith(".vault")?e.path:`${e.path}.vault`}else t=n.resolve(process.cwd(),".env.vault");return r.existsSync(t)?t:null}function D(e){return"~"===e[0]?n.join(s.homedir(),e.slice(1)):e}let I={configDotenv:function(e){let t;let a=n.resolve(process.cwd(),".env"),s="utf8",i=!!(e&&e.debug),o=!e||!("quiet"in e)||e.quiet;e&&e.encoding?s=e.encoding:i&&d("No encoding is specified. UTF-8 is used by default");let l=[a];if(e&&e.path){if(Array.isArray(e.path))for(let t of(l=[],e.path))l.push(D(t));else l=[D(e.path)]}let c={};for(let a of l)try{let t=I.parse(r.readFileSync(a,{encoding:s}));I.populate(c,t,e)}catch(e){i&&d(`Failed to load ${a} ${e.message}`),t=e}let u=process.env;if(e&&null!=e.processEnv&&(u=e.processEnv),I.populate(u,c,e),i||!o){let e=Object.keys(c).length,a=[];for(let e of l)try{let t=n.relative(process.cwd(),e);a.push(t)}catch(a){i&&d(`Failed to load ${e} ${a.message}`),t=a}p(`injecting env (${e}) from ${a.join(",")}`)}return t?{parsed:c,error:t}:{parsed:c}},_configVault:function(e){let t=!!(e&&e.debug),a=!e||!("quiet"in e)||e.quiet;(t||!a)&&p("Loading env from encrypted .env.vault");let r=I._parseVault(e),n=process.env;return e&&null!=e.processEnv&&(n=e.processEnv),I.populate(n,r,e),{parsed:r}},_parseVault:function(e){let t;let a=u(e=e||{});e.path=a;let r=I.configDotenv(e);if(!r.parsed){let e=Error(`MISSING_DATA: Cannot parse ${a} for an unknown reason`);throw e.code="MISSING_DATA",e}let n=c(e).split(","),s=n.length;for(let e=0;e<s;e++)try{let a=n[e].trim(),s=function(e,t){let a;try{a=new URL(t)}catch(e){if("ERR_INVALID_URL"===e.code){let e=Error("INVALID_DOTENV_KEY: Wrong format. Must be in valid uri format like dotenv://:key_1234@dotenvx.com/vault/.env.vault?environment=development");throw e.code="INVALID_DOTENV_KEY",e}throw e}let r=a.password;if(!r){let e=Error("INVALID_DOTENV_KEY: Missing key part");throw e.code="INVALID_DOTENV_KEY",e}let n=a.searchParams.get("environment");if(!n){let e=Error("INVALID_DOTENV_KEY: Missing environment part");throw e.code="INVALID_DOTENV_KEY",e}let s=`DOTENV_VAULT_${n.toUpperCase()}`,i=e.parsed[s];if(!i){let e=Error(`NOT_FOUND_DOTENV_ENVIRONMENT: Cannot locate environment ${s} in your .env.vault file.`);throw e.code="NOT_FOUND_DOTENV_ENVIRONMENT",e}return{ciphertext:i,key:r}}(r,a);t=I.decrypt(s.ciphertext,s.key);break}catch(t){if(e+1>=s)throw t}return I.parse(t)},config:function(e){if(0===c(e).length)return I.configDotenv(e);let t=u(e);if(!t){var a;return a=`You set DOTENV_KEY but you are missing a .env.vault file at ${t}. Did you forget to build it?`,console.log(`[dotenv@${o}][WARN] ${a}`),I.configDotenv(e)}return I._configVault(e)},decrypt:function(e,t){let a=Buffer.from(t.slice(-64),"hex"),r=Buffer.from(e,"base64"),n=r.subarray(0,12),s=r.subarray(-16);r=r.subarray(12,-16);try{let e=i.createDecipheriv("aes-256-gcm",a,n);return e.setAuthTag(s),`${e.update(r)}${e.final()}`}catch(r){let e=r instanceof RangeError,t="Invalid key length"===r.message,a="Unsupported state or unable to authenticate data"===r.message;if(e||t){let e=Error("INVALID_DOTENV_KEY: It must be 64 characters long (or more)");throw e.code="INVALID_DOTENV_KEY",e}if(a){let e=Error("DECRYPTION_FAILED: Please check your DOTENV_KEY");throw e.code="DECRYPTION_FAILED",e}throw r}},parse:function(e){let t;let a={},r=e.toString();for(r=r.replace(/\r\n?/mg,"\n");null!=(t=l.exec(r));){let e=t[1],r=t[2]||"",n=(r=r.trim())[0];r=r.replace(/^(['"`])([\s\S]*)\1$/mg,"$2"),'"'===n&&(r=(r=r.replace(/\\n/g,"\n")).replace(/\\r/g,"\r")),a[e]=r}return a},populate:function(e,t,a={}){let r=!!(a&&a.debug),n=!!(a&&a.override);if("object"!=typeof t){let e=Error("OBJECT_REQUIRED: Please check the processEnv argument being passed to populate");throw e.code="OBJECT_REQUIRED",e}for(let a of Object.keys(t))Object.prototype.hasOwnProperty.call(e,a)?(!0===n&&(e[a]=t[a]),r&&(!0===n?d(`"${a}" is already defined and WAS overwritten`):d(`"${a}" is already defined and was NOT overwritten`))):e[a]=t[a]}};e.exports.configDotenv=I.configDotenv,e.exports._configVault=I._configVault,e.exports._parseVault=I._parseVault,e.exports.config=I.config,e.exports.decrypt=I.decrypt,e.exports.parse=I.parse,e.exports.populate=I.populate,e.exports=I},94255:(e,t,a)=>{"use strict";var r,n,s,i,o;a.d(t,{Ly:()=>r,N3:()=>n,OD:()=>s,sd:()=>i,x6:()=>o}),function(e){e[e.DangSuDung=1]="DangSuDung",e[e.DangSuaChua=2]="DangSuaChua",e[e.HuHong=3]="HuHong",e[e.DaThanhLy=4]="DaThanhLy",e[e.CoHuHong=5]="CoHuHong"}(r||(r={})),function(e){e.Planned="planned",e.InProgress="in_progress",e.Completed="completed",e.Cancelled="cancelled",e.Missed="missed"}(n||(n={})),function(e){e[e.Pending=1]="Pending",e[e.Assigned=2]="Assigned",e[e.InProgress=3]="InProgress",e[e.Completed=4]="Completed",e[e.Cancelled=5]="Cancelled",e[e.Rejected=6]="Rejected"}(s||(s={})),function(e){e[e.Low=1]="Low",e[e.Normal=2]="Normal",e[e.High=3]="High",e[e.Urgent=4]="Urgent"}(i||(i={})),function(e){e.In="IN",e.Out="OUT"}(o||(o={}))},71564:e=>{"use strict";e.exports=JSON.parse('{"name":"dotenv","version":"16.6.1","description":"Loads environment variables from .env file","main":"lib/main.js","types":"lib/main.d.ts","exports":{".":{"types":"./lib/main.d.ts","require":"./lib/main.js","default":"./lib/main.js"},"./config":"./config.js","./config.js":"./config.js","./lib/env-options":"./lib/env-options.js","./lib/env-options.js":"./lib/env-options.js","./lib/cli-options":"./lib/cli-options.js","./lib/cli-options.js":"./lib/cli-options.js","./package.json":"./package.json"},"scripts":{"dts-check":"tsc --project tests/types/tsconfig.json","lint":"standard","pretest":"npm run lint && npm run dts-check","test":"tap run --allow-empty-coverage --disable-coverage --timeout=60000","test:coverage":"tap run --show-full-coverage --timeout=60000 --coverage-report=text --coverage-report=lcov","prerelease":"npm test","release":"standard-version"},"repository":{"type":"git","url":"git://github.com/motdotla/dotenv.git"},"homepage":"https://github.com/motdotla/dotenv#readme","funding":"https://dotenvx.com","keywords":["dotenv","env",".env","environment","variables","config","settings"],"readmeFilename":"README.md","license":"BSD-2-Clause","devDependencies":{"@types/node":"^18.11.3","decache":"^4.6.2","sinon":"^14.0.1","standard":"^17.0.0","standard-version":"^9.5.0","tap":"^19.2.0","typescript":"^4.8.4"},"engines":{"node":">=12"},"browser":{"fs":false}}')}};var t=require("../../../webpack-runtime.js");t.C(e);var a=e=>t(t.s=e),r=t.X(0,[8948,5972,657],()=>a(96684));module.exports=r})();