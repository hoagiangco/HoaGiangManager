(()=>{var e={};e.id=5221,e.ids=[5221],e.modules={72934:e=>{"use strict";e.exports=require("next/dist/client/components/action-async-storage.external.js")},54580:e=>{"use strict";e.exports=require("next/dist/client/components/request-async-storage.external.js")},45869:e=>{"use strict";e.exports=require("next/dist/client/components/static-generation-async-storage.external.js")},20399:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},27790:e=>{"use strict";e.exports=require("assert")},84770:e=>{"use strict";e.exports=require("crypto")},17702:e=>{"use strict";e.exports=require("events")},92048:e=>{"use strict";e.exports=require("fs")},32615:e=>{"use strict";e.exports=require("http")},32694:e=>{"use strict";e.exports=require("http2")},35240:e=>{"use strict";e.exports=require("https")},19801:e=>{"use strict";e.exports=require("os")},55315:e=>{"use strict";e.exports=require("path")},76162:e=>{"use strict";e.exports=require("stream")},74175:e=>{"use strict";e.exports=require("tty")},17360:e=>{"use strict";e.exports=require("url")},21764:e=>{"use strict";e.exports=require("util")},71568:e=>{"use strict";e.exports=require("zlib")},52214:(e,t,a)=>{"use strict";a.r(t),a.d(t,{GlobalError:()=>i.a,__next_app__:()=>f,originalPathname:()=>p,pages:()=>c,routeModule:()=>x,tree:()=>d}),a(34644),a(68032),a(35866),a(34750),a(69034);var r=a(23191),n=a(88716),s=a(37922),i=a.n(s),o=a(95231),l={};for(let e in o)0>["default","tree","pages","GlobalError","originalPathname","__next_app__","routeModule"].indexOf(e)&&(l[e]=()=>o[e]);a.d(t,l);let d=["",{children:["(dashboard)",{children:["dashboard",{children:["weekly-schedule",{children:["__PAGE__",{},{page:[()=>Promise.resolve().then(a.bind(a,34644)),"E:\\Web Project\\Nextjs\\HoaGiangManager\\app\\(dashboard)\\dashboard\\weekly-schedule\\page.tsx"]}]},{}]},{}]},{layout:[()=>Promise.resolve().then(a.bind(a,68032)),"E:\\Web Project\\Nextjs\\HoaGiangManager\\app\\(dashboard)\\layout.tsx"],"not-found":[()=>Promise.resolve().then(a.t.bind(a,35866,23)),"next/dist/client/components/not-found-error"],metadata:{icon:[],apple:[],openGraph:[],twitter:[],manifest:"/manifest.webmanifest"}}]},{layout:[()=>Promise.resolve().then(a.bind(a,34750)),"E:\\Web Project\\Nextjs\\HoaGiangManager\\app\\layout.tsx"],loading:[()=>Promise.resolve().then(a.bind(a,69034)),"E:\\Web Project\\Nextjs\\HoaGiangManager\\app\\loading.tsx"],"not-found":[()=>Promise.resolve().then(a.t.bind(a,35866,23)),"next/dist/client/components/not-found-error"],metadata:{icon:[],apple:[],openGraph:[],twitter:[],manifest:"/manifest.webmanifest"}}],c=["E:\\Web Project\\Nextjs\\HoaGiangManager\\app\\(dashboard)\\dashboard\\weekly-schedule\\page.tsx"],p="/(dashboard)/dashboard/weekly-schedule/page",f={require:a,loadChunk:()=>Promise.resolve()},x=new r.AppPageRouteModule({definition:{kind:n.x.APP_PAGE,page:"/(dashboard)/dashboard/weekly-schedule/page",pathname:"/dashboard/weekly-schedule",bundlePath:"",filename:"",appPaths:[]},userland:{loaderTree:d}})},14991:(e,t,a)=>{Promise.resolve().then(a.bind(a,56578))},56578:(e,t,a)=>{"use strict";a.r(t),a.d(t,{default:()=>j,dynamic:()=>h});var r=a(10326),n=a(17577),s=a(60962),i=a(69134);a(70641);var o=a(93621),l=a(88585),d=a(5758),c=a(21972),p=a(91126),f=a(75122),x=a(5817);let h="force-dynamic";function u({children:e}){return"undefined"==typeof document?null:(0,s.createPortal)(e,document.body)}let g=["Thứ 2","Thứ 3","Thứ 4","Thứ 5","Thứ 6","Thứ 7","Chủ Nhật"];function m(e){let t=new Date(e),a=t.getDay();return t.setDate(t.getDate()+(0===a?-6:1-a)),t.setHours(0,0,0,0),t}function b(e){return`${String(e.getDate()).padStart(2,"0")}/${String(e.getMonth()+1).padStart(2,"0")}/${e.getFullYear()}`}function w({staffId:e,staffName:t,dayIndex:a,cell:s,pendingTasks:i,onSave:o}){let[l,d]=(0,n.useState)(!1),[c,p]=(0,n.useState)(s.content),[f,x]=(0,n.useState)(s.note||""),[h,u]=(0,n.useState)("text"),[m,b]=(0,n.useState)({}),[w,y]=(0,n.useState)([]),j=(0,n.useRef)(null);(0,n.useRef)(null);let k=s.content||"";return(0,r.jsxs)("div",{className:"ws-cell-wrapper",ref:j,children:[(0,r.jsxs)("div",{className:`ws-cell ${l?"ws-cell--active":""} ${k?"":"ws-cell--empty"}`,onClick:()=>d(!0),title:`${t} - ${g[a-1]}: ${k||"Nhấp để nhập"}`,children:[r.jsx("span",{className:"ws-cell-text",children:k||r.jsx("span",{className:"ws-cell-placeholder",children:"+"})}),s.note&&!l&&r.jsx("span",{className:"ws-cell-note",children:s.note})]}),l&&!1]})}function y({open:e,onClose:t,allStaff:a,selectedIds:s,departments:i,onSave:o,saving:l}){let[d,c]=(0,n.useState)(new Set(s)),[p,f]=(0,n.useState)(0),[x,h]=(0,n.useState)("");if(!e)return null;let u=a.filter(e=>(!(p>0)||e.departmentId===p)&&(!x||!!e.name.toLowerCase().includes(x.toLowerCase()))),g={};for(let e of u){let t=e.departmentName||"Kh\xf4ng x\xe1c định";g[t]||(g[t]=[]),g[t].push(e)}let m=e=>{let t=new Set(d);t.has(e)?t.delete(e):t.add(e),c(t)};return r.jsx("div",{className:"ws-modal-overlay",onClick:t,children:(0,r.jsxs)("div",{className:"ws-modal",onClick:e=>e.stopPropagation(),children:[(0,r.jsxs)("div",{className:"ws-modal-header",children:[(0,r.jsxs)("h3",{children:[r.jsx("i",{className:"fas fa-user-check"})," Chọn nh\xe2n vi\xean tham gia lịch tuần"]}),r.jsx("button",{className:"ws-popup-close",onClick:t,children:"✕"})]}),(0,r.jsxs)("div",{className:"ws-modal-toolbar",children:[r.jsx("input",{type:"text",className:"ws-modal-search",placeholder:"T\xecm nh\xe2n vi\xean...",value:x,onChange:e=>h(e.target.value)}),(0,r.jsxs)("select",{className:"ws-select",value:p,onChange:e=>f(Number(e.target.value)),children:[r.jsx("option",{value:0,children:"Tất cả bộ phận"}),i.map(e=>r.jsx("option",{value:e.id,children:e.name},e.id))]}),r.jsx("button",{className:"ws-modal-action-btn",onClick:()=>{let e=new Set(d);u.forEach(t=>e.add(t.id)),c(e)},children:"Chọn tất cả"}),r.jsx("button",{className:"ws-modal-action-btn ws-modal-action-btn--danger",onClick:()=>{let e=new Set(d);u.forEach(t=>e.delete(t.id)),c(e)},children:"Bỏ chọn"})]}),(0,r.jsxs)("div",{className:"ws-modal-body",children:[Object.entries(g).map(([e,t])=>(0,r.jsxs)("div",{className:"ws-modal-dept-group",children:[r.jsx("div",{className:"ws-modal-dept-title",children:e}),r.jsx("div",{className:"ws-modal-staff-list",children:t.map(e=>(0,r.jsxs)("label",{className:`ws-modal-staff-item ${d.has(e.id)?"checked":""}`,children:[r.jsx("input",{type:"checkbox",checked:d.has(e.id),onChange:()=>m(e.id)}),r.jsx("span",{className:"ws-modal-staff-name",children:e.name})]},e.id))})]},e)),0===Object.keys(g).length&&r.jsx("div",{className:"ws-pick-empty",children:"Kh\xf4ng t\xecm thấy nh\xe2n vi\xean"})]}),(0,r.jsxs)("div",{className:"ws-modal-footer",children:[(0,r.jsxs)("span",{className:"ws-modal-count",children:[d.size," nh\xe2n vi\xean đ\xe3 chọn"]}),(0,r.jsxs)("div",{style:{display:"flex",gap:8},children:[r.jsx("button",{className:"ws-btn ws-btn--outline",onClick:t,style:{padding:"8px 20px"},children:"Hủy"}),r.jsx("button",{className:"ws-btn ws-btn--primary",onClick:()=>o(Array.from(d)),disabled:l,style:{padding:"8px 24px"},children:l?(0,r.jsxs)(r.Fragment,{children:[r.jsx("i",{className:"fas fa-circle-notch fa-spin"})," Đang lưu..."]}):(0,r.jsxs)(r.Fragment,{children:[r.jsx("i",{className:"fas fa-check"})," Lưu"]})})]})]})]})})}function j(){let{user:e,hasRole:t}=(0,i.a)(),a=t("SuperAdmin"),[s,h]=(0,n.useState)(!0),[j,v]=(0,n.useState)(!1),[S,N]=(0,n.useState)(()=>m(new Date)),[C,z]=(0,n.useState)([]),[R,I]=(0,n.useState)(0),[T,W]=(0,n.useState)([]),[P,M]=(0,n.useState)({}),[q,A]=(0,n.useState)([]),[D,L]=(0,n.useState)(new Set),[$,H]=(0,n.useState)(!1),[G,Z]=(0,n.useState)(!1),[_,B]=(0,n.useState)({}),[E,F]=(0,n.useState)(""),[U,Y]=(0,n.useState)(null),[K,V]=(0,n.useState)(null),[X,O]=(0,n.useState)(null),[J,Q]=(0,n.useState)(null),[ee,et]=(0,n.useState)(null),[ea,er]=(0,n.useState)(null),[en,es]=(0,n.useState)(!1),[ei,eo]=(0,n.useState)(!1),[el,ed]=(0,n.useState)(!1),ec=(0,n.useRef)({}),ep=(0,n.useRef)(null),ef=(0,n.useRef)(null),ex=(0,d.Z)(S,"yyyy-MM-dd"),eh=(0,c.Z)(S,6),eu=(0,n.useCallback)(async()=>{h(!0);try{let e=await o.Z.get(`/weekly-schedule?weekStart=${ex}&departmentId=${R}`);if(e.data.status){F(e.data.weeklyNote||""),e.data.weeklyMeta?(Y(e.data.weeklyMeta.approvedImageUrl||null),V(e.data.weeklyMeta.approvedAt||null),O(e.data.weeklyMeta.approvedBy||null),Q(e.data.weeklyMeta.creatorSignatureUrl||null),et(e.data.weeklyMeta.creatorName||null),er(e.data.weeklyMeta.creatorSignedAt||null)):(Y(null),V(null),O(null),Q(null),et(null),er(null));let t=e.data.data;W(t);let a={};for(let e of t)for(let t of e.staff)for(let e=1;e<=7;e++)a[`${t.staffId}:${e}`]=t.days[e]||{content:"",note:""};B(a);let r=t.flatMap(e=>e.staff.map(e=>e.staffId)),n={};await Promise.allSettled(r.map(e=>o.Z.get(`/work-plans/pending?staffId=${e}`).then(t=>{t.data.status&&(n[e]=t.data.data)}))),M(n)}}catch{l.Am.error("Kh\xf4ng thể tải lịch l\xe0m việc")}finally{h(!1)}},[ex,R]),eg=(0,n.useCallback)(t=>{ep.current&&clearTimeout(ep.current),ep.current=setTimeout(async()=>{let a=Object.entries(t);if(0!==a.length){ec.current={},v(!0);try{let t=a.map(([e,t])=>{let[a,r]=e.split(":").map(Number);return{weekStartDate:ex,staffId:a,dayOfWeek:r,content:t.content,note:t.note||""}});await o.Z.put("/weekly-schedule",{cells:t,createdBy:e?.id})}catch{l.Am.error("Lưu thất bại, thử lại sau")}finally{v(!1)}}},800)},[ex,e?.id]),em=(0,n.useCallback)(t=>{ef.current&&clearTimeout(ef.current),ef.current=setTimeout(async()=>{v(!0);try{await o.Z.put("/weekly-schedule",{weekStart:ex,weeklyNote:t,createdBy:e?.id})}catch{l.Am.error("Lưu ghi ch\xfa thất bại")}finally{v(!1)}},800)},[ex,e?.id]),eb=async t=>{let a=t.target.files?.[0];if(a){if(!a.type.startsWith("image/")){l.Am.error("Vui l\xf2ng chọn file h\xecnh ảnh (PNG, JPG, JPEG, v.v.)");return}eo(!0);try{let t=new FormData;t.append("file",a);let r=await o.Z.post("/files/upload",t,{headers:{"Content-Type":"multipart/form-data"}}),n=r.data.url||r.data.path;if(!n)throw Error(r.data.error||"Upload kh\xf4ng th\xe0nh c\xf4ng");let s=e?.fullName||e?.userName||e?.email||"SuperAdmin";await o.Z.put("/weekly-schedule",{weekStart:ex,approvedImageUrl:n,approvedBy:s}),Y(n),V(new Date().toISOString()),O(s),l.Am.success("Đ\xe3 tải l\xean ảnh lịch đ\xe3 duyệt th\xe0nh c\xf4ng!")}catch(e){l.Am.error(e.response?.data?.error||e.message||"Lỗi khi tải ảnh lịch")}finally{eo(!1),t.target.value=""}}},ew=async()=>{if(confirm("Bạn c\xf3 chắc chắn muốn x\xf3a ảnh lịch đ\xe3 duyệt của tuần n\xe0y?")){eo(!0);try{await o.Z.put("/weekly-schedule",{weekStart:ex,approvedImageUrl:null}),Y(null),V(null),O(null),l.Am.success("Đ\xe3 x\xf3a ảnh lịch đ\xe3 duyệt")}catch{l.Am.error("Kh\xf4ng thể x\xf3a ảnh lịch đ\xe3 duyệt")}finally{eo(!1)}}},ey=async()=>{if(confirm("Bạn c\xf3 chắc chắn muốn x\xf3a chữ k\xfd người lập của tuần n\xe0y?"))try{await o.Z.put("/weekly-schedule",{weekStart:ex,creatorSignatureUrl:null,creatorName:null}),Q(null),et(null),er(null),l.Am.success("Đ\xe3 x\xf3a chữ k\xfd người lập")}catch{l.Am.error("Kh\xf4ng thể x\xf3a chữ k\xfd người lập")}},ej=(0,n.useCallback)((e,t,a,r)=>{let n=`${e}:${t}`,s={content:a,note:r};B(e=>({...e,[n]:s})),ec.current[n]=s,eg({...ec.current})},[eg]),ek=async e=>{Z(!0);try{await o.Z.put("/weekly-schedule/staff",{staffIds:e}),L(new Set(e)),H(!1),l.Am.success("Đ\xe3 cập nhật danh s\xe1ch nh\xe2n vi\xean"),eu()}catch{l.Am.error("Lưu thất bại")}finally{Z(!1)}};if(!a)return(0,r.jsxs)("div",{className:"ws-access-denied",children:[r.jsx("div",{className:"ws-denied-icon",children:r.jsx("i",{className:"fas fa-lock"})}),r.jsx("h3",{children:"Kh\xf4ng c\xf3 quyền truy cập"}),r.jsx("p",{children:"Chức năng n\xe0y chỉ d\xe0nh cho Super Admin."})]});let ev=Array.from({length:7},(e,t)=>{let a=(0,c.Z)(S,t);return{label:g[t],date:`${String(a.getDate()).padStart(2,"0")}/${String(a.getMonth()+1).padStart(2,"0")}/${String(a.getFullYear()).slice(2)}`}});return(0,r.jsxs)(r.Fragment,{children:[r.jsx("style",{children:`
        /* ============================== Weekly Schedule Styles ============================== */
        .ws-page { padding: 0 0 40px 0; min-height: 100vh; background: linear-gradient(135deg, #f0f4ff 0%, #e8f0fe 100%); }

        .ws-header {
          background: linear-gradient(135deg, #1a56db 0%, #1e40af 100%);
          color: #fff; padding: 24px 28px 20px; border-radius: 0 0 20px 20px;
          margin-bottom: 24px; box-shadow: 0 4px 20px rgba(26,86,219,0.3);
        }
        .ws-header-top { display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 12px; }
        .ws-header h1 { font-size: 1.5rem; font-weight: 700; margin: 0; display: flex; align-items: center; gap: 10px; }
        .ws-header h1 i { opacity: 0.85; }
        .ws-header-sub { font-size: 0.9rem; opacity: 0.85; margin-top: 4px; }
        .ws-header-actions { display: flex; align-items: center; gap: 10px; flex-wrap: wrap; }

        .ws-toolbar {
          display: flex; align-items: center; gap: 14px; padding: 14px 28px;
          background: #fff; border-radius: 14px; margin: 0 16px 20px;
          box-shadow: 0 2px 12px rgba(0,0,0,0.07); flex-wrap: wrap;
        }
        .ws-week-nav { display: flex; align-items: center; gap: 8px; }
        .ws-week-label { font-weight: 700; font-size: 1.05rem; color: #1a56db; min-width: 220px; text-align: center; }
        .ws-btn-nav {
          width: 36px; height: 36px; border-radius: 50%; border: 2px solid #1a56db;
          background: transparent; color: #1a56db; font-size: 14px; cursor: pointer;
          display: flex; align-items: center; justify-content: center; transition: all .2s;
        }
        .ws-btn-nav:hover { background: #1a56db; color: #fff; }
        .ws-toolbar-sep { width: 1px; height: 32px; background: #e5e7eb; }

        .ws-select {
          border: 2px solid #e5e7eb; border-radius: 8px; padding: 6px 12px;
          font-size: 0.9rem; color: #1e293b; background: #fff; cursor: pointer;
          outline: none; transition: border .2s;
        }
        .ws-select:focus { border-color: #1a56db; }

        .ws-btn {
          padding: 7px 16px; border-radius: 8px; font-size: 0.875rem; font-weight: 600;
          cursor: pointer; border: none; display: inline-flex; align-items: center; gap: 6px; transition: all .2s;
        }
        .ws-btn--primary { background: #1a56db; color: #fff; }
        .ws-btn--primary:hover { background: #1e40af; transform: translateY(-1px); }
        .ws-btn--primary:disabled { opacity: 0.6; cursor: not-allowed; transform: none; }
        .ws-btn--outline { background: #fff; color: #1a56db; border: 2px solid #1a56db; }
        .ws-btn--outline:hover { background: #eff6ff; }
        .ws-btn--print { background: linear-gradient(135deg, #059669, #047857); color: #fff; }
        .ws-btn--print:hover { transform: translateY(-1px); box-shadow: 0 4px 12px rgba(5,150,105,0.3); }
        .ws-btn--staff { background: linear-gradient(135deg, #7c3aed, #6d28d9); color: #fff; }
        .ws-btn--staff:hover { transform: translateY(-1px); box-shadow: 0 4px 12px rgba(124,58,237,0.3); }

        .ws-saving-indicator { display: flex; align-items: center; gap: 6px; font-size: 0.82rem; color: #6b7280; }
        .ws-saving-indicator i { color: #1a56db; animation: spin 1s linear infinite; }
        @keyframes spin { 100% { transform: rotate(360deg); } }

        /* Table */
        .ws-table-wrap { overflow-x: auto; margin: 0 16px; border-radius: 16px; box-shadow: 0 4px 24px rgba(0,0,0,0.08); }
        .ws-table { width: 100%; border-collapse: separate; border-spacing: 0; background: #fff; border-radius: 16px; table-layout: fixed; }
        .ws-table thead th {
          background: #1a56db; color: #fff; font-weight: 700; text-align: center;
          padding: 11px 10px; font-size: 0.88rem; border-right: 1px solid rgba(255,255,255,0.15); white-space: nowrap;
        }
        .ws-table thead th:first-child { text-align: left; padding-left: 18px; width: 16%; }
        .ws-table thead th:not(:first-child) { width: 12%; }
        .ws-table thead .ws-date-row th {
          background: #dce6f1; color: #1e293b; font-weight: 600; font-size: 0.78rem;
          padding: 6px 10px; border-bottom: 2px solid #c3d4ed;
        }
        .ws-dept-row td {
          background: linear-gradient(90deg, #e8f0fe, #f0f4ff); font-weight: 800;
          font-size: 0.88rem; color: #1a56db; padding: 9px 18px; letter-spacing: 0.03em;
          border-top: 2px solid #c3d4ed; border-bottom: 1px solid #c3d4ed; text-transform: uppercase;
        }
        .ws-table tbody tr.ws-staff-row { transition: background .15s; }
        .ws-table tbody tr.ws-staff-row:hover { background: #f8faff; }
        .ws-staff-name-cell {
          padding: 0 6px 0 18px; font-weight: 600; font-size: 0.88rem; color: #1e293b;
          vertical-align: middle; border-right: 2px solid #e5e7eb; border-bottom: 1px solid #f1f5f9;
          white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
        }
        .ws-day-cell {
          padding: 2px; vertical-align: top; border-right: 1px solid #f1f5f9;
          border-bottom: 1px solid #f1f5f9; position: relative;
        }

        /* Cell editor */
        .ws-cell-wrapper { position: relative; }
        .ws-cell {
          min-height: 52px; padding: 7px 10px; cursor: pointer; border-radius: 6px;
          transition: background .15s, box-shadow .15s; white-space: pre-wrap;
          word-break: break-word; font-size: 0.82rem; line-height: 1.4;
        }
        .ws-cell:hover { background: #eff6ff; box-shadow: inset 0 0 0 1.5px #93c5fd; }
        .ws-cell--active { background: #dbeafe !important; box-shadow: inset 0 0 0 2px #1a56db !important; }
        .ws-cell--empty .ws-cell-placeholder { color: #cbd5e1; font-size: 1.1rem; }
        .ws-cell-text { display: block; color: #1e293b; }
        .ws-cell-note { display: block; color: #6b7280; font-size: 0.75rem; font-style: italic; margin-top: 2px; }

        /* Popup editor – d\xf9ng position:fixed để tho\xe1t khỏi mọi overflow clip */
        .ws-popup {
          position: fixed; z-index: 99999;
          background: #fff; border-radius: 14px;
          box-shadow: 0 8px 40px rgba(0,0,0,0.22), 0 0 0 1px rgba(26,86,219,0.15);
          width: 360px; animation: popIn .15s ease; overflow: hidden;
        }
        @keyframes popIn { from { opacity: 0; transform: translateY(-6px) scale(.98); } to { opacity: 1; transform: translateY(0) scale(1); } }
        @keyframes popUp { from { opacity: 0; transform: translateY(6px) scale(.98); } to { opacity: 1; transform: translateY(0) scale(1); } }
        .ws-popup-header {
          display: flex; align-items: center; justify-content: space-between;
          padding: 10px 14px; background: linear-gradient(135deg, #1a56db, #1e40af);
          color: #fff; font-size: 0.85rem; font-weight: 700;
        }
        .ws-popup-close {
          background: none; border: none; color: #fff; font-size: 1rem; cursor: pointer;
          width: 26px; height: 26px; border-radius: 50%;
          display: flex; align-items: center; justify-content: center; transition: background .15s;
        }
        .ws-popup-close:hover { background: rgba(255,255,255,0.2); }

        .ws-popup-tabs { display: flex; border-bottom: 2px solid #e5e7eb; }
        .ws-tab-btn {
          flex: 1; padding: 8px 10px; border: none; background: #f8faff;
          color: #6b7280; font-size: 0.8rem; font-weight: 600; cursor: pointer;
          transition: all .15s; display: flex; align-items: center; justify-content: center; gap: 5px;
        }
        .ws-tab-btn.active { background: #fff; color: #1a56db; border-bottom: 2px solid #1a56db; margin-bottom: -2px; }
        .ws-tab-btn:hover:not(.active) { background: #eff6ff; }

        .ws-popup-body { padding: 12px 14px; }
        .ws-quick-btns { display: flex; flex-wrap: wrap; gap: 5px; margin-bottom: 10px; }
        .ws-quick-btn {
          padding: 4px 10px; border-radius: 20px; border: 1.5px solid #1a56db;
          background: #fff; color: #1a56db; font-size: 0.78rem; font-weight: 600;
          cursor: pointer; transition: all .15s; display: inline-flex; align-items: center;
        }
        .ws-quick-btn:hover { background: #1a56db; color: #fff; }
        .ws-quick-btn--custom { border-color: #6366f1; color: #6366f1; }
        .ws-quick-btn--custom:hover { background: #6366f1; color: #fff; }
        .ws-quick-remove { margin-left: 6px; font-size: 0.7rem; opacity: 0.6; transition: opacity .15s; }
        .ws-quick-remove:hover { opacity: 1; color: #f87171; }
        .ws-quick-btn:hover .ws-quick-remove { opacity: 0.9; }
        .ws-quick-btn:hover .ws-quick-remove:hover { color: #fca5a5; }
        .ws-quick-btn--add { border-style: dashed; color: #64748b; border-color: #cbd5e1; }
        .ws-quick-btn--add:hover { background: #f8fafc; color: #334155; border-color: #94a3b8; }

        .ws-textarea {
          width: 100%; border: 2px solid #e5e7eb; border-radius: 8px;
          padding: 8px 10px; font-size: 0.85rem; font-family: inherit;
          resize: vertical; outline: none; color: #1e293b; transition: border .2s;
          display: block; margin-bottom: 8px;
        }
        .ws-textarea:focus { border-color: #1a56db; }
        .ws-textarea--note { font-size: 0.8rem; color: #6b7280; }

        .ws-pick-list { max-height: 240px; overflow-y: auto; padding: 8px 14px; }
        .ws-pick-empty { text-align: center; color: #9ca3af; padding: 20px; font-size: 0.85rem; }
        .ws-pick-item {
          padding: 9px 11px; border-radius: 8px; border: 1.5px solid #e5e7eb;
          margin-bottom: 6px; cursor: pointer; transition: all .15s;
        }
        .ws-pick-item:hover { border-color: #1a56db; background: #eff6ff; }
        .ws-pick-title { font-size: 0.82rem; color: #1e293b; font-weight: 600; }
        .ws-pick-meta { font-size: 0.76rem; color: #6b7280; margin-top: 2px; }
        .ws-pick-date { font-size: 0.72rem; color: #9ca3af; margin-top: 2px; }

        .ws-popup-footer {
          display: flex; justify-content: flex-end; gap: 8px;
          padding: 10px 14px; border-top: 1px solid #f1f5f9; background: #f8faff;
        }
        .ws-btn--clear {
          background: #fff; color: #ef4444; border: 1.5px solid #fca5a5;
          padding: 6px 14px; border-radius: 7px; font-size: 0.82rem; font-weight: 600;
          cursor: pointer; transition: all .15s;
        }
        .ws-btn--clear:hover { background: #fef2f2; }
        .ws-btn--save {
          background: #1a56db; color: #fff; border: none;
          padding: 6px 18px; border-radius: 7px; font-size: 0.82rem; font-weight: 700;
          cursor: pointer; transition: all .15s;
        }
        .ws-btn--save:hover { background: #1e40af; }

        /* Staff selector modal */
        .ws-modal-overlay {
          position: fixed; inset: 0; z-index: 2000; background: rgba(0,0,0,0.45);
          display: flex; align-items: center; justify-content: center;
          animation: fadeIn .2s ease;
        }
        @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
        .ws-modal {
          background: #fff; border-radius: 18px; width: 620px; max-width: 95vw;
          max-height: 85vh; display: flex; flex-direction: column;
          box-shadow: 0 20px 60px rgba(0,0,0,0.25); animation: popIn .2s ease;
        }
        .ws-modal-header {
          display: flex; align-items: center; justify-content: space-between;
          padding: 16px 20px; background: linear-gradient(135deg, #7c3aed, #6d28d9);
          color: #fff; border-radius: 18px 18px 0 0;
        }
        .ws-modal-header h3 { margin: 0; font-size: 1.1rem; font-weight: 700; display: flex; align-items: center; gap: 8px; }
        .ws-modal-toolbar {
          display: flex; align-items: center; gap: 10px; padding: 12px 20px;
          border-bottom: 1px solid #e5e7eb; flex-wrap: wrap;
        }
        .ws-modal-search {
          flex: 1; min-width: 150px; border: 2px solid #e5e7eb; border-radius: 8px;
          padding: 7px 12px; font-size: 0.88rem; outline: none; transition: border .2s;
        }
        .ws-modal-search:focus { border-color: #7c3aed; }
        .ws-modal-action-btn {
          padding: 6px 14px; border-radius: 6px; border: 1.5px solid #7c3aed;
          background: #fff; color: #7c3aed; font-size: 0.78rem; font-weight: 600;
          cursor: pointer; transition: all .15s;
        }
        .ws-modal-action-btn:hover { background: #7c3aed; color: #fff; }
        .ws-modal-action-btn--danger { border-color: #ef4444; color: #ef4444; }
        .ws-modal-action-btn--danger:hover { background: #ef4444; color: #fff; }

        .ws-modal-body { flex: 1; overflow-y: auto; padding: 16px 20px; }
        .ws-modal-dept-group { margin-bottom: 16px; }
        .ws-modal-dept-title {
          font-weight: 700; font-size: 0.85rem; color: #7c3aed;
          text-transform: uppercase; padding: 6px 0; border-bottom: 1.5px solid #e5e7eb;
          margin-bottom: 8px; letter-spacing: 0.03em;
        }
        .ws-modal-staff-list { display: flex; flex-wrap: wrap; gap: 6px; }
        .ws-modal-staff-item {
          display: flex; align-items: center; gap: 6px;
          padding: 7px 14px; border-radius: 8px; border: 1.5px solid #e5e7eb;
          cursor: pointer; transition: all .15s; font-size: 0.85rem;
        }
        .ws-modal-staff-item:hover { border-color: #7c3aed; background: #f5f3ff; }
        .ws-modal-staff-item.checked { border-color: #7c3aed; background: #ede9fe; }
        .ws-modal-staff-item input[type=checkbox] { accent-color: #7c3aed; }
        .ws-modal-staff-name { font-weight: 500; color: #1e293b; }

        .ws-modal-footer {
          display: flex; align-items: center; justify-content: space-between;
          padding: 12px 20px; border-top: 1px solid #e5e7eb; background: #f8faff;
          border-radius: 0 0 18px 18px;
        }
        .ws-modal-count { font-size: 0.85rem; color: #6b7280; font-weight: 600; }

        /* Access denied */
        .ws-access-denied {
          display: flex; flex-direction: column; align-items: center; justify-content: center;
          min-height: 60vh; gap: 16px; text-align: center;
        }
        .ws-denied-icon { font-size: 4rem; color: #d1d5db; }
        .ws-access-denied h3 { font-size: 1.4rem; color: #374151; }
        .ws-access-denied p { color: #6b7280; }

        .ws-empty { text-align: center; padding: 60px 20px; color: #9ca3af; }
        .ws-empty i { font-size: 3rem; margin-bottom: 12px; display: block; color: #d1d5db; }

        @media (max-width: 768px) {
          .ws-header { padding: 16px; }
          .ws-toolbar { margin: 0 8px 16px; padding: 12px; }
          .ws-table-wrap { margin: 0 8px; }
          .ws-popup { width: 300px; }
          .ws-week-label { min-width: 160px; font-size: 0.92rem; }
          .ws-modal { width: 95vw; }
        }
      `}),(0,r.jsxs)("div",{className:"ws-page",children:[r.jsx("div",{className:"ws-header",children:(0,r.jsxs)("div",{className:"ws-header-top",children:[(0,r.jsxs)("div",{children:[(0,r.jsxs)("h1",{children:[r.jsx("i",{className:"fas fa-calendar-week"})," Lịch L\xe0m Việc Tuần"]}),r.jsx("div",{className:"ws-header-sub",children:"Sắp xếp lịch c\xf4ng việc cho nh\xe2n vi\xean từng ng\xe0y trong tuần"})]}),(0,r.jsxs)("div",{className:"ws-header-actions",children:[(0,r.jsxs)("button",{className:"ws-btn ws-btn--staff",onClick:()=>H(!0),children:[r.jsx("i",{className:"fas fa-user-cog"})," Chọn nh\xe2n vi\xean (",D.size,")"]}),(0,r.jsxs)("button",{className:"ws-btn ws-btn--print",onClick:()=>{let e=R>0?R.toString():"",t=`/api/weekly-schedule/export?weekStart=${ex}${e?`&departmentIds=${e}`:""}`;window.open(t,"_blank")},children:[r.jsx("i",{className:"fas fa-print"})," In Lịch"]})]})]})}),(0,r.jsxs)("div",{className:"ws-toolbar",children:[(0,r.jsxs)("div",{className:"ws-week-nav",children:[r.jsx("button",{className:"ws-btn-nav",onClick:()=>N(e=>(0,p.Z)(e,1)),title:"Tuần trước",children:r.jsx("i",{className:"fas fa-chevron-left"})}),(0,r.jsxs)("div",{className:"ws-week-label",children:[b(S)," – ",b(eh)]}),r.jsx("button",{className:"ws-btn-nav",onClick:()=>N(e=>(0,f.Z)(e,1)),title:"Tuần sau",children:r.jsx("i",{className:"fas fa-chevron-right"})})]}),r.jsx("button",{className:"ws-btn ws-btn--outline",onClick:()=>N(m(new Date)),style:{fontSize:"0.82rem",padding:"6px 12px"},children:"Tuần hiện tại"}),r.jsx("div",{className:"ws-toolbar-sep"}),(0,r.jsxs)("select",{className:"ws-select",value:R,onChange:e=>I(Number(e.target.value)),children:[r.jsx("option",{value:0,children:"Tất cả bộ phận"}),C.map(e=>r.jsx("option",{value:e.id,children:e.name},e.id))]}),r.jsx("div",{className:"ws-toolbar-sep"}),j&&(0,r.jsxs)("span",{className:"ws-saving-indicator",children:[r.jsx("i",{className:"fas fa-circle-notch"})," Đang lưu..."]}),!j&&!s&&(0,r.jsxs)("span",{style:{fontSize:"0.8rem",color:"#10b981",display:"flex",alignItems:"center",gap:5},children:[r.jsx("i",{className:"fas fa-check-circle"})," Đ\xe3 lưu"]})]}),s?r.jsx("div",{style:{display:"flex",justifyContent:"center",padding:"60px"},children:r.jsx(x.default,{})}):0===T.length?(0,r.jsxs)("div",{className:"ws-empty",style:{margin:"0 16px",background:"#fff",borderRadius:16},children:[r.jsx("i",{className:"fas fa-users"}),0===D.size?(0,r.jsxs)(r.Fragment,{children:[r.jsx("p",{style:{fontWeight:600,marginBottom:8,color:"#374151"},children:"Chưa chọn nh\xe2n vi\xean n\xe0o"}),(0,r.jsxs)("p",{children:["Nhấn n\xfat ",r.jsx("strong",{children:'"Chọn nh\xe2n vi\xean"'})," ở tr\xean để th\xeam nh\xe2n vi\xean v\xe0o lịch tuần."]})]}):r.jsx("p",{children:"Kh\xf4ng c\xf3 nh\xe2n vi\xean n\xe0o trong bộ phận đ\xe3 chọn"})]}):r.jsx("div",{className:"ws-table-wrap",children:(0,r.jsxs)("table",{className:"ws-table",children:[(0,r.jsxs)("thead",{children:[(0,r.jsxs)("tr",{children:[r.jsx("th",{children:"Họ v\xe0 t\xean"}),ev.map((e,t)=>r.jsx("th",{children:e.label},t))]}),(0,r.jsxs)("tr",{className:"ws-date-row",children:[r.jsx("th",{}),ev.map((e,t)=>r.jsx("th",{style:{background:"#dce6f1",color:"#1e293b",fontWeight:600,fontSize:"0.78rem"},children:e.date},t))]})]}),r.jsx("tbody",{children:T.map(e=>(0,r.jsxs)(r.Fragment,{children:[r.jsx("tr",{className:"ws-dept-row",children:(0,r.jsxs)("td",{colSpan:8,children:[r.jsx("i",{className:"fas fa-users",style:{marginRight:8}}),e.departmentName.toUpperCase()]})},`dept-${e.departmentId}`),e.staff.map(e=>(0,r.jsxs)("tr",{className:"ws-staff-row",children:[r.jsx("td",{className:"ws-staff-name-cell",children:e.staffName}),Array.from({length:7},(t,a)=>{let n=a+1,s=_[`${e.staffId}:${n}`]||{content:"",note:""};return r.jsx("td",{className:"ws-day-cell",children:r.jsx(w,{staffId:e.staffId,staffName:e.staffName,dayIndex:n,cell:s,pendingTasks:P[e.staffId]||[],onSave:ej})},n)})]},e.staffId))]}))})]})}),!s&&T.length>0&&(0,r.jsxs)("div",{style:{margin:"16px 16px 0",background:"#fff",borderRadius:12,padding:"16px",boxShadow:"0 2px 8px rgba(0,0,0,0.05)"},children:[(0,r.jsxs)("h4",{style:{margin:"0 0 10px 0",fontSize:"0.9rem",color:"#1a56db",display:"flex",alignItems:"center",gap:6},children:[r.jsx("i",{className:"fas fa-sticky-note"})," Ghi ch\xfa tuần (hiển thị phần Lưu \xfd khi in)"]}),r.jsx("textarea",{value:E,onChange:e=>{let t=e.target.value;F(t),em(t)},placeholder:"Nhập ghi ch\xfa chung cho tuần n\xe0y...",style:{width:"100%",minHeight:"60px",border:"2px solid #e5e7eb",borderRadius:"8px",padding:"10px 12px",fontSize:"0.85rem",outline:"none",resize:"vertical",color:"#1e293b"},onFocus:e=>e.target.style.borderColor="#1a56db",onBlur:e=>e.target.style.borderColor="#e5e7eb"})]}),!s&&(0,r.jsxs)("div",{style:{margin:"16px 16px 0",background:"#fff",borderRadius:12,padding:"16px 20px",boxShadow:"0 2px 8px rgba(0,0,0,0.05)"},children:[(0,r.jsxs)("div",{style:{display:"flex",alignItems:"center",justifyContent:"space-between",flexWrap:"wrap",gap:12,marginBottom:U?12:0},children:[(0,r.jsxs)("h4",{style:{margin:0,fontSize:"0.95rem",color:"#1e293b",display:"flex",alignItems:"center",gap:8},children:[r.jsx("i",{className:"fas fa-file-signature",style:{color:"#10b981",fontSize:"1.1rem"}}),"Ảnh Lịch Đ\xe3 Duyệt Ch\xednh Thức",U?(0,r.jsxs)("span",{style:{fontSize:"0.75rem",padding:"3px 10px",borderRadius:12,background:"#d1fae5",color:"#047857",fontWeight:600},children:[r.jsx("i",{className:"fas fa-check-circle",style:{marginRight:4}})," Đ\xe3 c\xf3 bản duyệt"]}):r.jsx("span",{style:{fontSize:"0.75rem",padding:"3px 10px",borderRadius:12,background:"#f3f4f6",color:"#6b7280"},children:"Chưa c\xf3 ảnh duyệt"})]}),(0,r.jsxs)("div",{style:{display:"flex",alignItems:"center",gap:8},children:[(0,r.jsxs)("label",{style:{cursor:ei?"not-allowed":"pointer",display:"inline-flex",alignItems:"center",gap:6,padding:"7px 14px",borderRadius:8,fontSize:"0.82rem",fontWeight:600,background:"#1a56db",color:"#fff",border:"none",opacity:ei?.7:1,transition:"all 0.2s"},children:[r.jsx("i",{className:ei?"fas fa-spinner fa-spin":"fas fa-upload"}),ei?"Đang xử l\xfd...":U?"Thay ảnh kh\xe1c":"Tải ảnh lịch đ\xe3 duyệt",r.jsx("input",{type:"file",accept:"image/*",onChange:eb,disabled:ei,style:{display:"none"}})]}),U&&(0,r.jsxs)("button",{onClick:ew,disabled:ei,style:{padding:"7px 12px",borderRadius:8,fontSize:"0.82rem",fontWeight:600,background:"#fef2f2",color:"#dc2626",border:"1px solid #fecaca",cursor:"pointer",display:"inline-flex",alignItems:"center",gap:4},children:[r.jsx("i",{className:"fas fa-trash-alt"})," X\xf3a"]})]})]}),U&&(0,r.jsxs)("div",{style:{background:"#f8fafc",borderRadius:10,padding:12,border:"1px solid #e2e8f0",display:"flex",alignItems:"center",gap:16,flexWrap:"wrap"},children:[(0,r.jsxs)("div",{onClick:()=>ed(!0),style:{position:"relative",width:120,height:80,borderRadius:8,overflow:"hidden",border:"2px solid #cbd5e1",cursor:"pointer",flexShrink:0,boxShadow:"0 2px 4px rgba(0,0,0,0.1)"},children:[r.jsx("img",{src:U,alt:"Ảnh lịch đ\xe3 duyệt",style:{width:"100%",height:"100%",objectFit:"cover"}}),r.jsx("div",{style:{position:"absolute",inset:0,background:"rgba(0,0,0,0.3)",display:"flex",alignItems:"center",justifyContent:"center",color:"#fff",fontSize:"1rem",opacity:0,transition:"opacity 0.2s"},onMouseEnter:e=>e.currentTarget.style.opacity="1",onMouseLeave:e=>e.currentTarget.style.opacity="0",children:r.jsx("i",{className:"fas fa-search-plus"})})]}),(0,r.jsxs)("div",{style:{flex:1,minWidth:200},children:[r.jsx("p",{style:{margin:"0 0 4px 0",fontWeight:600,fontSize:"0.875rem",color:"#1e293b"},children:"Bản chụp/scan lịch tuần ch\xednh thức"}),(0,r.jsxs)("div",{style:{fontSize:"0.78rem",color:"#64748b",display:"flex",gap:16,flexWrap:"wrap"},children:[K&&(0,r.jsxs)("span",{children:[r.jsx("i",{className:"far fa-clock",style:{marginRight:4}}),"Thời gian: ",(0,d.Z)(new Date(K),"HH:mm dd/MM/yyyy")]}),X&&(0,r.jsxs)("span",{children:[r.jsx("i",{className:"far fa-user",style:{marginRight:4}}),"Người cập nhật: ",X]})]})]}),(0,r.jsxs)("div",{style:{display:"flex",gap:8},children:[(0,r.jsxs)("button",{onClick:()=>ed(!0),style:{padding:"6px 14px",borderRadius:6,fontSize:"0.8rem",fontWeight:600,background:"#eff6ff",color:"#1a56db",border:"1px solid #bfdbfe",cursor:"pointer",display:"inline-flex",alignItems:"center",gap:6},children:[r.jsx("i",{className:"fas fa-expand"})," Xem ảnh lớn"]}),(0,r.jsxs)("a",{href:U,target:"_blank",rel:"noopener noreferrer",download:!0,style:{padding:"6px 14px",borderRadius:6,fontSize:"0.8rem",fontWeight:600,background:"#f1f5f9",color:"#334155",border:"1px solid #cbd5e1",textDecoration:"none",display:"inline-flex",alignItems:"center",gap:6},children:[r.jsx("i",{className:"fas fa-download"})," Tải về"]})]})]})]}),!s&&(0,r.jsxs)("div",{style:{margin:"16px 16px 0",background:"#fff",borderRadius:12,padding:"16px 20px",boxShadow:"0 2px 8px rgba(0,0,0,0.05)"},children:[(0,r.jsxs)("div",{style:{display:"flex",alignItems:"center",justifyContent:"space-between",flexWrap:"wrap",gap:12},children:[(0,r.jsxs)("h4",{style:{margin:0,fontSize:"0.95rem",color:"#1e293b",display:"flex",alignItems:"center",gap:8},children:[r.jsx("i",{className:"fas fa-signature",style:{color:"#8b5cf6",fontSize:"1.1rem"}}),"Chữ K\xfd Người Lập (Vị tr\xed Người Lập khi in lịch)",J?(0,r.jsxs)("span",{style:{fontSize:"0.75rem",padding:"3px 10px",borderRadius:12,background:"#f3e8ff",color:"#7e22ce",fontWeight:600},children:[r.jsx("i",{className:"fas fa-check-circle",style:{marginRight:4}})," Đ\xe3 k\xfd"]}):r.jsx("span",{style:{fontSize:"0.75rem",padding:"3px 10px",borderRadius:12,background:"#f3f4f6",color:"#6b7280"},children:"Chưa k\xfd"})]}),(0,r.jsxs)("div",{style:{display:"flex",alignItems:"center",gap:8},children:[(0,r.jsxs)("button",{onClick:()=>es(!0),style:{padding:"7px 14px",borderRadius:8,fontSize:"0.82rem",fontWeight:600,background:"#8b5cf6",color:"#fff",border:"none",cursor:"pointer",display:"inline-flex",alignItems:"center",gap:6,transition:"all 0.2s"},children:[r.jsx("i",{className:"fas fa-pen-nib"}),J?"Thay đổi chữ k\xfd":"Th\xeam / K\xfd t\xean người lập"]}),J&&(0,r.jsxs)("button",{onClick:ey,style:{padding:"7px 12px",borderRadius:8,fontSize:"0.82rem",fontWeight:600,background:"#fef2f2",color:"#dc2626",border:"1px solid #fecaca",cursor:"pointer",display:"inline-flex",alignItems:"center",gap:4},children:[r.jsx("i",{className:"fas fa-trash-alt"})," X\xf3a chữ k\xfd"]})]})]}),J&&(0,r.jsxs)("div",{style:{marginTop:12,background:"#fcfaff",borderRadius:10,padding:12,border:"1px solid #f3e8ff",display:"flex",alignItems:"center",gap:16,flexWrap:"wrap"},children:[r.jsx("div",{style:{position:"relative",height:60,minWidth:120,padding:"4px 12px",borderRadius:8,background:"#fff",border:"1px solid #e9d5ff",display:"flex",alignItems:"center",justifyContent:"center"},children:r.jsx("img",{src:J,alt:"Chữ k\xfd người lập",style:{maxHeight:50,maxWidth:140,objectFit:"contain"}})}),(0,r.jsxs)("div",{style:{flex:1,minWidth:200},children:[(0,r.jsxs)("p",{style:{margin:"0 0 4px 0",fontWeight:600,fontSize:"0.875rem",color:"#1e293b"},children:["Người lập: ",r.jsx("span",{style:{color:"#7e22ce"},children:ee||"Chưa đặt t\xean"})]}),ea&&(0,r.jsxs)("div",{style:{fontSize:"0.78rem",color:"#64748b"},children:[r.jsx("i",{className:"far fa-clock",style:{marginRight:4}}),"Thời gian k\xfd: ",(0,d.Z)(new Date(ea),"HH:mm dd/MM/yyyy")]})]})]})]}),!s&&T.length>0&&(0,r.jsxs)("div",{style:{margin:"16px 16px 0",padding:"12px 18px",background:"#fff",borderRadius:12,boxShadow:"0 2px 8px rgba(0,0,0,0.05)",display:"flex",alignItems:"center",gap:20,flexWrap:"wrap",fontSize:"0.8rem",color:"#6b7280"},children:[r.jsx("span",{children:r.jsx("strong",{children:"Hướng dẫn:"})}),(0,r.jsxs)("span",{children:[r.jsx("i",{className:"fas fa-mouse-pointer",style:{color:"#1a56db",marginRight:4}}),"Click v\xe0o \xf4 để nhập nội dung"]}),(0,r.jsxs)("span",{children:[r.jsx("i",{className:"fas fa-list-check",style:{color:"#1a56db",marginRight:4}}),'Tab "Chọn từ danh s\xe1ch" để th\xeam việc tồn đọng']}),(0,r.jsxs)("span",{children:[r.jsx("i",{className:"fas fa-save",style:{color:"#10b981",marginRight:4}}),"Tự động lưu sau khi nhập"]}),(0,r.jsxs)("span",{children:[r.jsx("i",{className:"fas fa-print",style:{color:"#059669",marginRight:4}}),'N\xfat "In Lịch" để in tất cả tr\xean c\xf9ng 1 trang']})]})]}),el&&U&&r.jsx(u,{children:r.jsx("div",{style:{position:"fixed",inset:0,background:"rgba(0,0,0,0.85)",zIndex:999999,display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",padding:20},onClick:()=>ed(!1),children:(0,r.jsxs)("div",{style:{position:"relative",maxWidth:"95vw",maxHeight:"90vh",display:"flex",flexDirection:"column",alignItems:"center"},onClick:e=>e.stopPropagation(),children:[r.jsx("button",{onClick:()=>ed(!1),style:{position:"absolute",top:-40,right:0,background:"transparent",border:"none",color:"#fff",fontSize:"1.8rem",cursor:"pointer"},title:"Đ\xf3ng",children:r.jsx("i",{className:"fas fa-times"})}),r.jsx("img",{src:U,alt:"Ảnh lịch tuần đ\xe3 duyệt",style:{maxWidth:"100%",maxHeight:"85vh",objectFit:"contain",borderRadius:8,boxShadow:"0 8px 32px rgba(0,0,0,0.5)"}}),(0,r.jsxs)("div",{style:{color:"#fff",marginTop:12,fontSize:"0.85rem",display:"flex",gap:16},children:[(0,r.jsxs)("span",{children:["Lịch tuần từ ",b(S)," đến ",b(eh)]}),r.jsx("a",{href:U,target:"_blank",rel:"noopener noreferrer",style:{color:"#60a5fa",textDecoration:"underline"},children:"Mở trong tab mới"})]})]})})}),r.jsx(y,{open:$,onClose:()=>H(!1),allStaff:q,selectedIds:D,departments:C,onSave:ek,saving:G}),r.jsx(k,{open:en,onClose:()=>es(!1),weekStart:ex,currentSignatureUrl:J,currentCreatorName:ee,defaultUserName:e?.fullName||e?.userName||e?.email||"",onSaved:(e,t)=>{Q(e),et(t),er(new Date().toISOString())}})]})}function k({open:e,onClose:t,weekStart:a,currentSignatureUrl:s,currentCreatorName:i,defaultUserName:d,onSaved:c}){let[p,f]=(0,n.useState)("draw"),[x,h]=(0,n.useState)(""),[g,m]=(0,n.useState)("#0f172a"),[b,w]=(0,n.useState)(!1),[y,j]=(0,n.useState)(!1),[k,v]=(0,n.useState)(null),[S,N]=(0,n.useState)(null),[C,z]=(0,n.useState)(!1),R=(0,n.useRef)(null);if(!e)return null;let I=e=>{let t=R.current;if(!t)return{x:0,y:0};let a=t.getBoundingClientRect();if("touches"in e&&e.touches.length>0){let t=e.touches[0];return{x:t.clientX-a.left,y:t.clientY-a.top}}return{x:e.clientX-a.left,y:e.clientY-a.top}},T=e=>{let t=R.current;if(!t)return;let a=t.getContext("2d");if(!a)return;let r=I(e);a.beginPath(),a.moveTo(r.x,r.y),w(!0),j(!0)},W=e=>{if(!b)return;let t=R.current;if(!t)return;let a=t.getContext("2d");if(!a)return;let r=I(e);a.lineTo(r.x,r.y),a.stroke()},P=()=>{w(!1)},M=async()=>{if(!x.trim()){l.Am.error("Vui l\xf2ng nhập t\xean người lập");return}z(!0);try{let e=s;if("draw"===p){let t=R.current;if(t&&y){let a=await new Promise(e=>t.toBlob(e,"image/png"));if(a){let r=new FormData;r.append("file",new File([a],`signature_${Date.now()}.png`,{type:"image/png"}));let n=await o.Z.post("/files/upload",r,{headers:{"Content-Type":"multipart/form-data"}});e=n.data.url||n.data.path||t.toDataURL("image/png")}else e=t.toDataURL("image/png")}else if(!s){l.Am.error("Vui l\xf2ng vẽ chữ k\xfd hoặc tải ảnh chữ k\xfd l\xean"),z(!1);return}}else if("upload"===p){if(k){let t=new FormData;t.append("file",k);let a=await o.Z.post("/files/upload",t,{headers:{"Content-Type":"multipart/form-data"}});e=a.data.url||a.data.path}else if(!s){l.Am.error("Vui l\xf2ng chọn file ảnh chữ k\xfd"),z(!1);return}}await o.Z.put("/weekly-schedule",{weekStart:a,creatorSignatureUrl:e,creatorName:x.trim()}),l.Am.success("Đ\xe3 lưu chữ k\xfd người lập!"),c(e,x.trim()),t()}catch(e){l.Am.error(e.response?.data?.error||e.message||"Lỗi khi lưu chữ k\xfd")}finally{z(!1)}};return r.jsx(u,{children:r.jsx("div",{style:{position:"fixed",inset:0,background:"rgba(0,0,0,0.6)",zIndex:999999,display:"flex",alignItems:"center",justifyContent:"center",padding:16},onClick:t,children:(0,r.jsxs)("div",{style:{background:"#fff",borderRadius:16,width:"100%",maxWidth:480,padding:24,boxShadow:"0 20px 25px -5px rgba(0,0,0,0.1), 0 10px 10px -5px rgba(0,0,0,0.04)",display:"flex",flexDirection:"column",gap:16},onClick:e=>e.stopPropagation(),children:[(0,r.jsxs)("div",{style:{display:"flex",alignItems:"center",justifyContent:"space-between"},children:[(0,r.jsxs)("h3",{style:{margin:0,fontSize:"1.1rem",fontWeight:700,color:"#1e293b",display:"flex",alignItems:"center",gap:8},children:[r.jsx("i",{className:"fas fa-signature",style:{color:"#8b5cf6"}}),"Chữ K\xfd Người Lập Lịch Tuần"]}),r.jsx("button",{onClick:t,style:{background:"none",border:"none",fontSize:"1.2rem",color:"#64748b",cursor:"pointer"},children:"✕"})]}),(0,r.jsxs)("div",{children:[(0,r.jsxs)("label",{style:{display:"block",fontSize:"0.85rem",fontWeight:600,color:"#374151",marginBottom:6},children:["Họ v\xe0 t\xean Người lập: ",r.jsx("span",{style:{color:"#ef4444"},children:"*"})]}),r.jsx("input",{type:"text",value:x,onChange:e=>h(e.target.value),placeholder:"Nhập họ v\xe0 t\xean...",style:{width:"100%",padding:"9px 12px",border:"2px solid #e5e7eb",borderRadius:8,fontSize:"0.9rem",outline:"none"},onFocus:e=>e.target.style.borderColor="#8b5cf6",onBlur:e=>e.target.style.borderColor="#e5e7eb"})]}),(0,r.jsxs)("div",{style:{display:"flex",background:"#f1f5f9",padding:4,borderRadius:10,gap:4},children:[(0,r.jsxs)("button",{type:"button",style:{flex:1,padding:"7px 0",border:"none",borderRadius:8,fontSize:"0.85rem",fontWeight:600,cursor:"pointer",background:"draw"===p?"#fff":"transparent",color:"draw"===p?"#8b5cf6":"#64748b",boxShadow:"draw"===p?"0 1px 3px rgba(0,0,0,0.1)":"none",transition:"all 0.2s"},onClick:()=>f("draw"),children:[r.jsx("i",{className:"fas fa-pen-nib",style:{marginRight:6}})," Vẽ trực tiếp"]}),(0,r.jsxs)("button",{type:"button",style:{flex:1,padding:"7px 0",border:"none",borderRadius:8,fontSize:"0.85rem",fontWeight:600,cursor:"pointer",background:"upload"===p?"#fff":"transparent",color:"upload"===p?"#8b5cf6":"#64748b",boxShadow:"upload"===p?"0 1px 3px rgba(0,0,0,0.1)":"none",transition:"all 0.2s"},onClick:()=>f("upload"),children:[r.jsx("i",{className:"fas fa-file-image",style:{marginRight:6}})," Tải ảnh chữ k\xfd"]})]}),"draw"===p&&(0,r.jsxs)("div",{children:[(0,r.jsxs)("div",{style:{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:6},children:[r.jsx("span",{style:{fontSize:"0.8rem",color:"#64748b"},children:"D\xf9ng chuột hoặc cảm ứng để vẽ chữ k\xfd:"}),(0,r.jsxs)("div",{style:{display:"flex",alignItems:"center",gap:10},children:[r.jsx("span",{style:{fontSize:"0.78rem",color:"#64748b"},children:"M\xe0u b\xfat:"}),["#0f172a","#1e3a8a","#047857"].map(e=>r.jsx("button",{type:"button",onClick:()=>m(e),style:{width:18,height:18,borderRadius:"50%",background:e,border:g===e?"2px solid #8b5cf6":"1px solid #ccc",cursor:"pointer",transform:g===e?"scale(1.2)":"none"}},e)),(0,r.jsxs)("button",{type:"button",onClick:()=>{let e=R.current;if(!e)return;let t=e.getContext("2d");if(!t)return;let a=e.getBoundingClientRect(),r=window.devicePixelRatio||1;t.setTransform(1,0,0,1,0,0),t.scale(r,r),t.fillStyle="#ffffff",t.fillRect(0,0,a.width,a.height),t.strokeStyle=g,t.lineWidth=2.5,t.lineCap="round",t.lineJoin="round",j(!1)},style:{padding:"3px 8px",fontSize:"0.75rem",borderRadius:6,background:"#fef2f2",color:"#ef4444",border:"1px solid #fecaca",cursor:"pointer"},children:[r.jsx("i",{className:"fas fa-eraser",style:{marginRight:4}})," X\xf3a"]})]})]}),r.jsx("div",{style:{border:"2px dashed #cbd5e1",borderRadius:10,overflow:"hidden",background:"#fff",touchAction:"none"},children:r.jsx("canvas",{ref:R,style:{width:"100%",height:160,display:"block",cursor:"crosshair"},onMouseDown:T,onMouseMove:W,onMouseUp:P,onMouseLeave:P,onTouchStart:T,onTouchMove:W,onTouchEnd:P})})]}),"upload"===p&&(0,r.jsxs)("div",{style:{display:"flex",flexDirection:"column",gap:12},children:[(0,r.jsxs)("label",{style:{border:"2px dashed #cbd5e1",borderRadius:10,padding:24,textAlign:"center",cursor:"pointer",background:"#fafafa",transition:"all 0.2s"},children:[r.jsx("i",{className:"fas fa-cloud-upload-alt",style:{fontSize:"2rem",color:"#8b5cf6",marginBottom:8}}),r.jsx("p",{style:{margin:"0 0 4px 0",fontSize:"0.88rem",fontWeight:600,color:"#334155"},children:"Nhấp v\xe0o đ\xe2y để chọn ảnh chữ k\xfd"}),r.jsx("p",{style:{margin:0,fontSize:"0.75rem",color:"#94a3b8"},children:"PNG, JPG hoặc JPEG (khuy\xean d\xf9ng nền trong suốt)"}),r.jsx("input",{type:"file",accept:"image/*",onChange:e=>{let t=e.target.files?.[0];if(t){if(!t.type.startsWith("image/")){l.Am.error("Vui l\xf2ng chọn file h\xecnh ảnh (PNG, JPG...)");return}v(t),N(URL.createObjectURL(t))}},style:{display:"none"}})]}),S&&(0,r.jsxs)("div",{style:{display:"flex",alignItems:"center",gap:12,background:"#f8fafc",padding:10,borderRadius:8,border:"1px solid #e2e8f0"},children:[r.jsx("img",{src:S,alt:"Xem trước chữ k\xfd",style:{maxHeight:60,maxWidth:120,objectFit:"contain"}}),r.jsx("span",{style:{fontSize:"0.8rem",color:"#059669",fontWeight:600},children:"Đ\xe3 chọn ảnh th\xe0nh c\xf4ng"})]})]}),s&&!y&&!S&&(0,r.jsxs)("div",{style:{fontSize:"0.78rem",color:"#64748b",background:"#f8fafc",padding:"8px 12px",borderRadius:8,border:"1px solid #e2e8f0",display:"flex",alignItems:"center",justifyContent:"space-between"},children:[r.jsx("span",{children:"Chữ k\xfd hiện tại:"}),r.jsx("img",{src:s,alt:"Chữ k\xfd hiện tại",style:{maxHeight:40,maxWidth:100,objectFit:"contain"}})]}),(0,r.jsxs)("div",{style:{display:"flex",gap:10,justifyContent:"flex-end",marginTop:4},children:[r.jsx("button",{type:"button",onClick:t,disabled:C,style:{padding:"9px 18px",borderRadius:8,fontSize:"0.85rem",fontWeight:600,background:"#f1f5f9",color:"#475569",border:"none",cursor:"pointer"},children:"Hủy"}),(0,r.jsxs)("button",{type:"button",onClick:M,disabled:C,style:{padding:"9px 20px",borderRadius:8,fontSize:"0.85rem",fontWeight:600,background:"#8b5cf6",color:"#fff",border:"none",cursor:C?"not-allowed":"pointer",opacity:C?.7:1,display:"inline-flex",alignItems:"center",gap:6},children:[C?r.jsx("i",{className:"fas fa-spinner fa-spin"}):r.jsx("i",{className:"fas fa-save"}),C?"Đang lưu...":"Lưu chữ k\xfd"]})]})]})})})}},34644:(e,t,a)=>{"use strict";a.r(t),a.d(t,{default:()=>s,dynamic:()=>n});var r=a(68570);let n=(0,r.createProxy)(String.raw`E:\Web Project\Nextjs\HoaGiangManager\app\(dashboard)\dashboard\weekly-schedule\page.tsx#dynamic`),s=(0,r.createProxy)(String.raw`E:\Web Project\Nextjs\HoaGiangManager\app\(dashboard)\dashboard\weekly-schedule\page.tsx#default`)}};var t=require("../../../../webpack-runtime.js");t.C(e);var a=e=>t(t.s=e),r=t.X(0,[8948,6996,4468,434,5881,8490,6363],()=>a(52214));module.exports=r})();