"use strict";exports.id=583,exports.ids=[583],exports.modules={73840:(e,t,a)=>{a.d(t,{RA:()=>i,WX:()=>o});var r=a(41482),n=a.n(r);let s=process.env.JWT_SECRET||"your-secret-key-change-this-in-production",d=process.env.JWT_EXPIRES_IN||"24h",i=e=>{if(!s)throw Error("JWT_SECRET is not configured");return n().sign(e,s,{expiresIn:d})},o=e=>{try{return n().verify(e,s)}catch(e){throw Error("Invalid token")}}},96899:(e,t,a)=>{a.a(e,async(e,r)=>{try{a.d(t,{Y:()=>i}),a(87070);var n=a(73840),s=a(97395),d=e([s]);async function i(e){try{let t=e.headers.get("authorization");if(!t||!t.startsWith("Bearer "))return{user:null,error:"No token provided"};let a=t.substring(7),r=(0,n.WX)(a),d=await s.Z.query(`SELECT u."Id", u."Email", u."NormalizedEmail"
       FROM "AspNetUsers" u
       WHERE u."Id" = $1`,[r.userId]);if(0===d.rows.length)return{user:null,error:"User not found"};let i=(await s.Z.query(`SELECT r."Name"
       FROM "AspNetRoles" r
       INNER JOIN "AspNetUserRoles" ur ON r."Id" = ur."RoleId"
       WHERE ur."UserId" = $1`,[r.userId])).rows.map(e=>e.Name);return{user:{userId:r.userId,email:r.email,roles:i},error:null}}catch(e){return console.error("Authentication error:",e.message||e),{user:null,error:e.message||"Invalid token"}}}s=(d.then?(await d)():d)[0],r()}catch(e){r(e)}})},97395:(e,t,a)=>{a.a(e,async(e,r)=>{try{a.d(t,{I:()=>c,Z:()=>u});var n=a(8678),s=a(16636),d=a.n(s),i=e([n]);n=(i.then?(await i)():i)[0],d().config(),d().config({path:".env.local",override:!0}),n.types.setTypeParser(1082,e=>e);let o=process.env.DATABASE_URL?.includes("localhost")||process.env.DATABASE_URL?.includes("127.0.0.1"),l=new n.Pool({connectionString:process.env.DATABASE_URL,ssl:!o&&{rejectUnauthorized:!1}});l.on("connect",e=>{e.query("SET TIME ZONE 'Asia/Ho_Chi_Minh'")});let u=l,c=async(e,t)=>{Date.now();try{let a=await l.query(e,t);return Date.now(),a}catch(t){throw console.error("Database query error",{text:e,error:t}),t}};r()}catch(e){r(e)}})},79089:(e,t,a)=>{a.d(t,{z:()=>i});var r=a(810),n=a.n(r);let s="BOs8iawbH0xpwPaFUnjPE5FqE65j8MEUrNXc5cKP7yWZEVWdL2K-c5irBdmXLe-shiUnh962nEHjJZWiqebocCY",d=process.env.VAPID_PRIVATE_KEY;async function i(e,t){try{let a=JSON.stringify(t);return await n().sendNotification(e,a),{success:!0}}catch(e){if(console.error("Error sending push notification:",e),404===e.statusCode||410===e.statusCode||"ENOTFOUND"===e.code&&"permanently-removed.invalid"===e.hostname)return{success:!1,expired:!0};return{success:!1,error:e.message}}}s&&d&&n().setVapidDetails("mailto:hoang@hoagiang.com",s,d)},97128:(e,t,a)=>{a.a(e,async(e,r)=>{try{a.d(t,{P:()=>l});var n=a(97395),s=a(58718),d=a(94255),i=a(1013),o=e([n,s]);[n,s]=o.then?(await o)():o;class l{async ensureEventSequence(e){let t=e||n.Z,a=await t.query('SELECT COALESCE(MAX("ID"), 0) AS max_id FROM "Event"'),r=await t.query('SELECT last_value, is_called FROM "Event_ID_seq"'),s=Number(a.rows[0]?.max_id||0),d=Number(r.rows[0]?.last_value||0);r.rows[0]?.is_called||(d-=1),s>d&&await t.query("SELECT setval(pg_get_serial_sequence('\"Event\"', 'ID'), $1, true)",[s])}async getEventByType(e=0){let t=`
      SELECT 
        e."ID" as id,
        e."Title" as title,
        e."DeviceID" as "deviceId",
        d."Name" as "deviceName",
        e."EventTypeID" as "eventTypeId",
        et."Name" as "eventTypeName",
        et."Code" as "eventTypeCode",
        et."Description" as "eventTypeDescription",
        et."Category" as "eventTypeCategory",
        e."Description" as description,
        e."Notes" as notes,
        e."Status" as status,
        e."EventDate" as "eventDate",
        e."StartDate" as "startDate",
        e."EndDate" as "endDate",
        e."StaffID" as "staffId",
        s."Name" as "staffName",
        e."RelatedReportID" as "relatedReportId",
        dr."DamageContent" as "relatedReportSummary",
        dr."DamageLocation" as "relatedReportLocation",
        e."Metadata" as metadata,
        e."CreatedBy" as "createdBy",
        e."CreatedAt" as "createdAt",
        e."UpdatedBy" as "updatedBy",
        e."UpdatedAt" as "updatedAt"
      FROM "Event" e
      LEFT JOIN "EventType" et ON e."EventTypeID" = et."ID"
      LEFT JOIN "Device" d ON e."DeviceID" = d."ID"
      LEFT JOIN "Staff" s ON e."StaffID" = s."ID"
      LEFT JOIN "DamageReport" dr ON e."RelatedReportID" = dr."ID"
    `,a=[];return e>0&&(t+=' WHERE e."EventTypeID" = $1',a.push(e)),t+=' ORDER BY COALESCE(e."EventDate", e."StartDate", e."EndDate", e."CreatedAt") DESC NULLS LAST, e."ID" DESC',(await n.Z.query(t,a)).rows.map(e=>{let t=null;if(e.metadata){if("string"==typeof e.metadata)try{t=JSON.parse(e.metadata)}catch(e){t=null}else t=e.metadata}let a=e.status?String(e.status).toLowerCase():d.N3.Completed;return{id:e.id,title:e.title,deviceId:e.deviceId,deviceName:e.deviceName,eventTypeId:e.eventTypeId,eventTypeName:e.eventTypeName,eventTypeCode:e.eventTypeCode,description:e.description,notes:e.notes,status:a,eventDate:e.eventDate,startDate:e.startDate,endDate:e.endDate,staffId:e.staffId,staffName:e.staffName,relatedReportId:e.relatedReportId,relatedReportSummary:e.relatedReportSummary||e.relatedReportLocation||null,metadata:t,createdBy:e.createdBy,createdAt:e.createdAt,updatedBy:e.updatedBy,updatedAt:e.updatedAt}})}async getById(e){let t=await n.Z.query(`SELECT 
        "ID" as id,
        "Title" as title,
        "DeviceID" as "deviceId",
        "EventTypeID" as "eventTypeId",
        "Description" as description,
        "Notes" as notes,
        "Status" as status,
        "EventDate" as "eventDate",
        "StartDate" as "startDate",
        "EndDate" as "endDate",
        "StaffID" as "staffId",
        "RelatedReportID" as "relatedReportId",
        "Metadata" as metadata,
        "CreatedBy" as "createdBy",
        "CreatedAt" as "createdAt",
        "UpdatedBy" as "updatedBy",
        "UpdatedAt" as "updatedAt"
      FROM "Event" WHERE "ID" = $1`,[e]);if(0===t.rows.length)return null;let a=t.rows[0],r=null;if(a.metadata){if("string"==typeof a.metadata)try{r=JSON.parse(a.metadata)}catch(e){r=null}else r=a.metadata}return{id:a.id,title:a.title,deviceId:a.deviceId,eventTypeId:a.eventTypeId,description:a.description,notes:a.notes,status:a.status?String(a.status).toLowerCase():d.N3.Completed,eventDate:a.eventDate,startDate:a.startDate,endDate:a.endDate,staffId:a.staffId,relatedReportId:a.relatedReportId,metadata:r,createdBy:a.createdBy,createdAt:a.createdAt,updatedBy:a.updatedBy,updatedAt:a.updatedAt}}async getByRelatedReportId(e){let t=await n.Z.query(`SELECT 
        "ID" as id,
        "Title" as title,
        "DeviceID" as "deviceId",
        "EventTypeID" as "eventTypeId",
        "Description" as description,
        "Notes" as notes,
        "Status" as status,
        "EventDate" as "eventDate",
        "StartDate" as "startDate",
        "EndDate" as "endDate",
        "StaffID" as "staffId",
        "RelatedReportID" as "relatedReportId",
        "Metadata" as metadata,
        "CreatedBy" as "createdBy",
        "CreatedAt" as "createdAt",
        "UpdatedBy" as "updatedBy",
        "UpdatedAt" as "updatedAt"
      FROM "Event" 
      WHERE "RelatedReportID" = $1 
      ORDER BY "ID" DESC LIMIT 1`,[e]);if(0===t.rows.length)return null;let a=t.rows[0],r=null;if(a.metadata){if("string"==typeof a.metadata)try{r=JSON.parse(a.metadata)}catch(e){r=null}else r=a.metadata}return{id:a.id,title:a.title,deviceId:a.deviceId,eventTypeId:a.eventTypeId,description:a.description,notes:a.notes,status:a.status?String(a.status).toLowerCase():d.N3.Completed,eventDate:a.eventDate,startDate:a.startDate,endDate:a.endDate,staffId:a.staffId,relatedReportId:a.relatedReportId,metadata:r,createdBy:a.createdBy,createdAt:a.createdAt,updatedBy:a.updatedBy,updatedAt:a.updatedAt}}async create(e){await this.ensureEventSequence();let t=(0,i.ud)();return(await n.Z.query(`INSERT INTO "Event" (
        "Title", "DeviceID", "EventTypeID", "Description", "Notes",
        "Status", "EventDate", "StartDate", "EndDate", "StaffID",
        "RelatedReportID", "Metadata", "CreatedBy", "CreatedAt",
        "UpdatedBy", "UpdatedAt"
      )
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16)
      RETURNING "ID"`,[e.title||null,e.deviceId||null,e.eventTypeId,null!=e.description?e.description:"",null!=e.notes?e.notes:"",e.status||d.N3.Completed,e.eventDate||null,e.startDate||null,e.endDate||null,e.staffId||null,e.relatedReportId||null,e.metadata?JSON.stringify(e.metadata):null,e.createdBy||null,e.createdAt||t,e.updatedBy||e.createdBy||null,e.updatedAt||t])).rows[0].ID}async update(e){await this.ensureEventSequence();let t=await n.Z.query('SELECT "Status" FROM "Event" WHERE "ID" = $1',[e.id]),a=t.rows[0]?.Status;if(await n.Z.query(`UPDATE "Event" SET
        "Title" = $1,
        "DeviceID" = $2,
        "EventTypeID" = $3,
        "Description" = $4,
        "Notes" = $5,
        "Status" = $6,
        "EventDate" = $7,
        "StartDate" = $8,
        "EndDate" = $9,
        "StaffID" = $10,
        "RelatedReportID" = $11,
        "Metadata" = $12,
        "UpdatedBy" = $13,
        "UpdatedAt" = CURRENT_TIMESTAMP
      WHERE "ID" = $14`,[e.title||null,e.deviceId||null,e.eventTypeId,null!=e.description?e.description:"",null!=e.notes?e.notes:"",e.status||"completed",e.eventDate||null,e.startDate||null,e.endDate||null,e.staffId||null,e.relatedReportId||null,e.metadata?JSON.stringify(e.metadata):null,e.updatedBy||null,e.id]),a!==e.status&&"completed"===e.status)try{let t=await n.Z.query('SELECT "Name" FROM "Staff" WHERE "ID" = $1',[e.staffId]),a=t.rows[0]?.Name||"Nh\xe2n vi\xean",r=new s.gq;await r.createNotification({title:"Sự kiện ho\xe0n th\xe0nh ✅",content:`${a} đ\xe3 ho\xe0n th\xe0nh: ${e.title||"Một sự kiện"}`,type:s.k$.System,category:s.mN.Completed,targetUrl:"/dashboard/events",createdBy:e.updatedBy||void 0,excludeUserId:e.updatedBy||void 0})}catch(e){console.error("Error sending event completion notification:",e)}return e.id}async delete(e){return await n.Z.query('DELETE FROM "Event" WHERE "ID" = $1',[e]),!0}}r()}catch(e){r(e)}})},58718:(e,t,a)=>{a.a(e,async(e,r)=>{try{a.d(t,{gq:()=>l,k$:()=>n,mN:()=>s});var n,s,d=a(97395),i=a(79089),o=e([d]);d=(o.then?(await o)():o)[0],function(e){e.Report="report",e.Maintenance="maintenance",e.System="system"}(n||(n={})),function(e){e.New="new",e.InProgress="in_progress",e.Completed="completed",e.Upcoming="upcoming",e.Reminder="reminder"}(s||(s={}));class l{async createNotification(e){try{let t=(await d.Z.query(`INSERT INTO "Notification" ("Title", "Content", "Type", "Category", "TargetUrl", "StaffId", "CreatedBy")
         VALUES ($1, $2, $3, $4, $5, $6, $7)
         RETURNING "ID"`,[e.title,e.content||null,e.type,e.category,e.targetUrl||null,e.staffId||null,e.createdBy||null])).rows[0].ID;return await this.sendPushToRelevantUsers(e),t}catch(e){console.error("Error creating notification:",e)}}async sendPushToRelevantUsers(e){try{let t="",a=[];e.staffId?(t=`
          SELECT ps."Endpoint", ps."P256dh", ps."Auth" 
          FROM "PushSubscription" ps
          JOIN "Staff" s ON ps."UserId" = s."UserId"
          WHERE s."ID" = $1
        `,a.push(e.staffId),console.log(`[Push] Targeting staff ID: ${e.staffId}`)):(t=`
          SELECT ps."Endpoint", ps."P256dh", ps."Auth" 
          FROM "PushSubscription" ps
          JOIN "AspNetUserRoles" ur ON ps."UserId" = ur."UserId"
          JOIN "AspNetRoles" r ON ur."RoleId" = r."Id"
          WHERE r."Name" = 'Admin'
        `,e.excludeUserId&&(t+=' AND ps."UserId" != $1',a.push(e.excludeUserId)),console.log(`[Push] Broadcasting to all Admins${e.excludeUserId?` (excluding user ${e.excludeUserId})`:""}`));let r=await d.Z.query(t,a),n={title:e.title,body:e.content||"",icon:"/icons/icon.svg",badge:"/icons/icon.svg",data:{url:e.targetUrl||"/dashboard"},vibrate:[100,50,100]};for(let e of(console.log(`[Push] Sending to ${r.rows.length} subscribers`),r.rows)){let t={endpoint:e.Endpoint,keys:{p256dh:e.P256dh,auth:e.Auth}};(0,i.z)(t,n).then(async t=>{if(!t.success&&t.expired)try{await d.Z.query('DELETE FROM "PushSubscription" WHERE "Endpoint" = $1',[e.Endpoint]),console.log(`[Push] Removed expired subscription: ${e.Endpoint}`)}catch(e){console.error("[Push] Failed to remove expired subscription:",e)}}).catch(e=>{console.error("[Push] Single send failed:",e)})}}catch(e){console.error("Error sending push notifications:",e)}}}r()}catch(e){r(e)}})},1013:(e,t,a)=>{a.d(t,{J0:()=>d,My:()=>n,_Q:()=>i,rp:()=>s,ud:()=>r});let r=()=>{try{let e=new Date;return new Date(e.toLocaleString("en-US",{timeZone:"Asia/Ho_Chi_Minh"}))}catch{return new Date}},n=()=>{let e=r(),t=e.getFullYear(),a=String(e.getMonth()+1).padStart(2,"0"),n=String(e.getDate()).padStart(2,"0");return`${t}-${a}-${n}`},s=e=>{if(!e)return"";try{let t="string"==typeof e?new Date(e):e;if(Number.isNaN(t.getTime()))return"";return new Intl.DateTimeFormat("en-GB",{timeZone:"Asia/Ho_Chi_Minh",day:"2-digit",month:"2-digit",year:"numeric"}).format(t)}catch(e){return""}},d=e=>{if(!e)return"";try{let t="string"==typeof e?new Date(e):e;if(Number.isNaN(t.getTime()))return"";let a=new Intl.DateTimeFormat("en-GB",{timeZone:"Asia/Ho_Chi_Minh",day:"2-digit",month:"2-digit",year:"numeric"}).formatToParts(t),r=a.find(e=>"year"===e.type)?.value||"",n=a.find(e=>"month"===e.type)?.value||"",s=a.find(e=>"day"===e.type)?.value||"";return`${s}-${n}-${r}`}catch(e){return""}},i=(e,t)=>{if(!e&&!t)return"tất cả thời gian";let a=s(e)||"...",r=s(t)||"...";return`${a} đến ${r}`}},94255:(e,t,a)=>{var r,n,s,d,i;a.d(t,{Ly:()=>r,N3:()=>n,OD:()=>s,sd:()=>d,x6:()=>i}),function(e){e[e.DangSuDung=1]="DangSuDung",e[e.DangSuaChua=2]="DangSuaChua",e[e.HuHong=3]="HuHong",e[e.DaThanhLy=4]="DaThanhLy",e[e.CoHuHong=5]="CoHuHong"}(r||(r={})),function(e){e.Planned="planned",e.InProgress="in_progress",e.Completed="completed",e.Cancelled="cancelled",e.Missed="missed"}(n||(n={})),function(e){e[e.Pending=1]="Pending",e[e.Assigned=2]="Assigned",e[e.InProgress=3]="InProgress",e[e.Completed=4]="Completed",e[e.Cancelled=5]="Cancelled",e[e.Rejected=6]="Rejected"}(s||(s={})),function(e){e[e.Low=1]="Low",e[e.Normal=2]="Normal",e[e.High=3]="High",e[e.Urgent=4]="Urgent"}(d||(d={})),function(e){e.In="IN",e.Out="OUT"}(i||(i={}))}};