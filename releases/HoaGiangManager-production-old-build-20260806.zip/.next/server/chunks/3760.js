"use strict";exports.id=3760,exports.ids=[3760],exports.modules={63760:(e,t,a)=>{a.a(e,async(e,r)=>{try{a.d(t,{k:()=>l});var n=a(97395),d=a(94255),o=a(97128),s=a(58718),i=a(1013),D=e([n,o,s]);[n,o,s]=D.then?(await D)():D;class l{async ensureHistorySequence(e){let t=e||n.Z,a=await t.query('SELECT COALESCE(MAX("ID"), 0) AS max_id FROM "DamageReportHistory"'),r=await t.query('SELECT last_value, is_called FROM "DamageReportHistory_ID_seq"'),d=Number(a.rows[0]?.max_id||0),o=Number(r.rows[0]?.last_value||0);r.rows[0]?.is_called||(o-=1),d>o&&await t.query("SELECT setval(pg_get_serial_sequence('\"DamageReportHistory\"', 'ID'), $1, true)",[d])}getStatusName(e){return({[d.OD.Pending]:"Chờ xử l\xfd",[d.OD.Assigned]:"Đ\xe3 ph\xe2n c\xf4ng",[d.OD.InProgress]:"Đang xử l\xfd",[d.OD.Completed]:"Ho\xe0n th\xe0nh",[d.OD.Cancelled]:"Đ\xe3 hủy",[d.OD.Rejected]:"Từ chối"})[e]||"Kh\xf4ng x\xe1c định"}getPriorityName(e){return({[d.sd.Low]:"Thấp",[d.sd.Normal]:"B\xecnh thường",[d.sd.High]:"Cao",[d.sd.Urgent]:"Khẩn cấp"})[e]||"Kh\xf4ng x\xe1c định"}async getAll(e){let t=`
      SELECT 
        dr."ID" as id,
        dr."DeviceID" as "deviceId",
        dr."DamageLocation" as "damageLocation",
        dr."ReporterID" as "reporterId",
        dr."ReportingDepartmentID" as "reportingDepartmentId",
        dr."HandlerID" as "handlerId",
        dr."CoHandlerIDs" as "coHandlerIds",
        (
          SELECT json_agg(json_build_object('id', s."ID", 'name', s."Name"))
          FROM "Staff" s
          WHERE s."ID" = ANY(dr."CoHandlerIDs")
        ) as "coHandlers",
        dr."AssignedDate" as "assignedDate",
        dr."ReportDate" as "reportDate",
        dr."HandlingDate" as "handlingDate",
        dr."CompletedDate" as "completedDate",
        dr."EstimatedCompletionDate" as "estimatedCompletionDate",
        dr."DamageContent" as "damageContent",
        dr."Images" as images,
        dr."AfterImages" as "afterImages",
        CAST(dr."Status"::text AS INTEGER) as status,
        CAST(dr."Priority"::text AS INTEGER) as priority,
        dr."Notes" as notes,
        dr."HandlerNotes" as "handlerNotes",
        dr."RejectionReason" as "rejectionReason",
        dr."MaintenanceBatchId" as "maintenanceBatchId",
        dr."CreatedBy" as "createdBy",
        dr."UpdatedBy" as "updatedBy",
        dr."CreatedAt" as "createdAt",
        dr."UpdatedAt" as "updatedAt",
        dr."IsDeleted" as "isDeleted",
        d."Name" as "deviceName",
        d."Serial" as "deviceSerial",
        CAST(d."Status"::text AS INTEGER) as "deviceStatus",
        reporter."Name" as "reporterName",
        reporter_dept."Name" as "reporterDepartmentName",
        handler."Name" as "handlerName",
        handler_dept."Name" as "handlerDepartmentName",
        loc."Name" as "deviceLocationName",
        updated_user."FullName" as "updatedByName",
        source_plan."ID" as "sourcePlanId",
        source_plan."PlanDate" as "sourcePlanDate",
        (SELECT drp."Title" 
         FROM "DeviceReminderPlan" drp 
         WHERE drp."Metadata" IS NOT NULL
           AND (
             drp."Metadata"::text LIKE '%"maintenanceBatchId":"' || dr."MaintenanceBatchId" || '"%'
             OR (drp."Metadata"::jsonb ? 'maintenanceBatchId' 
                 AND (drp."Metadata"->>'maintenanceBatchId') = dr."MaintenanceBatchId")
           )
         LIMIT 1
        ) as "maintenanceBatchTitle"
      FROM "DamageReport" dr
      LEFT JOIN "Device" d ON dr."DeviceID" = d."ID"
      LEFT JOIN "Staff" reporter ON dr."ReporterID" = reporter."ID"
      LEFT JOIN "Department" reporter_dept ON dr."ReportingDepartmentID" = reporter_dept."ID"
      LEFT JOIN "Staff" handler ON dr."HandlerID" = handler."ID"
      LEFT JOIN "Department" handler_dept ON handler."DepartmentID" = handler_dept."ID"
      LEFT JOIN "Location" loc ON d."LocationID" = loc."ID"
      LEFT JOIN "AspNetUsers" updated_user ON dr."UpdatedBy" = updated_user."Id"
      LEFT JOIN LATERAL (
        SELECT wpi."ID", wpi."PlanDate"
        FROM "WorkPlanItem" wpi
        WHERE wpi."DamageReportID" = dr."ID"
        ORDER BY wpi."ID" DESC
        LIMIT 1
      ) source_plan ON TRUE
      WHERE 1=1
    `,a=[],r=1;if(e&&void 0!==e.isDeleted?(t+=` AND (dr."IsDeleted" = $${r})`,a.push(e.isDeleted),r++):t+=' AND (dr."IsDeleted" = false OR dr."IsDeleted" IS NULL)',e&&!e.isAdmin&&e.currentUserId&&(t+=` AND (
        dr."HandlerID" IN (SELECT "ID" FROM "Staff" WHERE "UserId" = $${r}) OR
        (SELECT "ID" FROM "Staff" WHERE "UserId" = $${r}) = ANY(dr."CoHandlerIDs") OR
        dr."ReporterID" IN (SELECT "ID" FROM "Staff" WHERE "UserId" = $${r})
      )`,a.push(e.currentUserId),r++),e){if(e.status){let n=e.status.toString();if(n.includes(",")){let e=n.split(",").map(e=>e.trim());t+=` AND dr."Status"::text = ANY($${r}::text[])`,a.push(e)}else t+=` AND dr."Status" = $${r}`,a.push(n);r++}e.priority&&(t+=` AND dr."Priority" = $${r}`,a.push(e.priority.toString()),r++),e.deviceId&&(t+=` AND dr."DeviceID" = $${r}`,a.push(e.deviceId),r++),e.reporterId&&(t+=` AND dr."ReporterID" = $${r}`,a.push(e.reporterId),r++),e.handlerId&&(t+=` AND (dr."HandlerID" = $${r} OR $${r} = ANY(dr."CoHandlerIDs"))`,a.push(e.handlerId),r++),e.departmentId&&(t+=` AND handler."DepartmentID" = $${r}`,a.push(e.departmentId),r++),e.reportingDepartmentId&&(t+=` AND dr."ReportingDepartmentID" = $${r}`,a.push(e.reportingDepartmentId),r++),e.fromDate&&(t+=` AND DATE(dr."ReportDate") >= $${r}`,a.push(e.fromDate),r++),e.toDate&&(t+=` AND DATE(dr."ReportDate") <= $${r}`,a.push(e.toDate),r++),e.locationId&&(t+=` AND d."LocationID" IN (
          WITH RECURSIVE sub_locations AS (
            SELECT "ID" FROM "Location" WHERE "ID" = $${r}
            UNION ALL
            SELECT l."ID" FROM "Location" l
            INNER JOIN sub_locations sl ON l."ParentID" = sl."ID"
          )
          SELECT "ID" FROM sub_locations
        )`,a.push(e.locationId),r++),e.search&&(t+=` AND (
          dr."DamageContent" ILIKE $${r} OR
          dr."DamageLocation" ILIKE $${r} OR
          d."Name" ILIKE $${r} OR
          reporter."Name" ILIKE $${r} OR
          handler."Name" ILIKE $${r}
        )`,a.push(`%${e.search}%`),r++),e.maintenanceBatchId&&("only-maintenance"===e.maintenanceBatchId?t+=' AND dr."MaintenanceBatchId" IS NOT NULL':"none-maintenance"===e.maintenanceBatchId?t+=' AND dr."MaintenanceBatchId" IS NULL':(t+=` AND dr."MaintenanceBatchId" = $${r}`,a.push(e.maintenanceBatchId),r++))}return t+=' ORDER BY dr."ReportDate" DESC, dr."ID" DESC',(await n.Z.query(t,a)).rows.map(e=>this.mapRowToVM(e))}async getPaginated(e){let{page:t=1,limit:a=10,status:r,priority:d,deviceId:o,reporterId:s,handlerId:i,departmentId:D,reportingDepartmentId:l,locationId:I,search:c,maintenanceBatchId:p,isDeleted:m,sortField:N="reportDate",sortOrder:g="desc",isAdmin:h=!1,currentUserId:E,fromDate:u,toDate:R}=e,S=[],y="WHERE 1=1";if(void 0!==m?(S.push(m),y+=` AND (dr."IsDeleted" = $${S.length})`):y+=' AND (dr."IsDeleted" = false OR dr."IsDeleted" IS NULL)',!h&&E&&(S.push(E),y+=` AND (
        dr."HandlerID" IN (SELECT "ID" FROM "Staff" WHERE "UserId" = $${S.length}) OR
        (SELECT "ID" FROM "Staff" WHERE "UserId" = $${S.length}) = ANY(dr."CoHandlerIDs") OR
        dr."ReporterID" IN (SELECT "ID" FROM "Staff" WHERE "UserId" = $${S.length})
      )`),r){let e=r.toString();if(e.includes(",")){let t=e.split(",").map(e=>e.trim());S.push(t),y+=` AND dr."Status"::text = ANY($${S.length}::text[])`}else S.push(e),y+=` AND dr."Status" = $${S.length}`}if(d&&(S.push(d.toString()),y+=` AND dr."Priority" = $${S.length}`),o&&(S.push(o),y+=` AND dr."DeviceID" = $${S.length}`),s&&(S.push(s),y+=` AND dr."ReporterID" = $${S.length}`),i&&(S.push(i),y+=` AND (dr."HandlerID" = $${S.length} OR $${S.length} = ANY(dr."CoHandlerIDs"))`),D&&(S.push(D),y+=` AND handler."DepartmentID" = $${S.length}`),l&&(S.push(l),y+=` AND dr."ReportingDepartmentID" = $${S.length}`),u&&(S.push(u),y+=` AND DATE(dr."ReportDate") >= $${S.length}`),R&&(S.push(R),y+=` AND DATE(dr."ReportDate") <= $${S.length}`),I&&(S.push(I),y+=` AND (d."LocationID" IN (
        WITH RECURSIVE sub_locations AS (
          SELECT "ID" FROM "Location" WHERE "ID" = $${S.length}
          UNION ALL
          SELECT l."ID" FROM "Location" l
          INNER JOIN sub_locations sl ON l."ParentID" = sl."ID"
        )
        SELECT "ID" FROM sub_locations
      ) OR dr."DamageLocation" ILIKE (SELECT "Name" FROM "Location" WHERE "ID" = $${S.length}))`),c&&c.trim()){S.push(`%${c.trim().toLowerCase()}%`);let e=S.length;y+=` AND (
        dr."DamageContent" ILIKE $${e} OR
        dr."DamageLocation" ILIKE $${e} OR
        d."Name" ILIKE $${e} OR
        reporter."Name" ILIKE $${e} OR
        handler."Name" ILIKE $${e}
      )`}p&&("only-maintenance"===p?y+=' AND dr."MaintenanceBatchId" IS NOT NULL':"none-maintenance"===p?y+=' AND dr."MaintenanceBatchId" IS NULL':(S.push(p),y+=` AND dr."MaintenanceBatchId" = $${S.length}`));try{let e=`
        SELECT COUNT(*) 
        FROM "DamageReport" dr
        LEFT JOIN "Device" d ON dr."DeviceID" = d."ID"
        LEFT JOIN "Staff" reporter ON dr."ReporterID" = reporter."ID"
        LEFT JOIN "Staff" handler ON dr."HandlerID" = handler."ID"
        ${y}
      `,r=await n.Z.query(e,S),d=parseInt(r.rows[0].count),o=`
        SELECT 
          dr."ID" as id,
          dr."DeviceID" as "deviceId",
          dr."DamageLocation" as "damageLocation",
          dr."ReporterID" as "reporterId",
          dr."ReportingDepartmentID" as "reportingDepartmentId",
          dr."HandlerID" as "handlerId",
          dr."CoHandlerIDs" as "coHandlerIds",
          (
            SELECT json_agg(json_build_object('id', s."ID", 'name', s."Name"))
            FROM "Staff" s
            WHERE s."ID" = ANY(dr."CoHandlerIDs")
          ) as "coHandlers",
          dr."AssignedDate" as "assignedDate",
          dr."ReportDate" as "reportDate",
          dr."HandlingDate" as "handlingDate",
          dr."CompletedDate" as "completedDate",
          dr."EstimatedCompletionDate" as "estimatedCompletionDate",
          dr."DamageContent" as "damageContent",
          dr."Images" as images,
          dr."AfterImages" as "afterImages",
          CAST(dr."Status"::text AS INTEGER) as status,
          CAST(dr."Priority"::text AS INTEGER) as priority,
          dr."Notes" as notes,
          dr."HandlerNotes" as "handlerNotes",
          dr."RejectionReason" as "rejectionReason",
          dr."MaintenanceBatchId" as "maintenanceBatchId",
          dr."CreatedBy" as "createdBy",
          dr."UpdatedBy" as "updatedBy",
          dr."CreatedAt" as "createdAt",
          dr."UpdatedAt" as "updatedAt",
          dr."IsDeleted" as "isDeleted",
          d."Name" as "deviceName",
          d."Serial" as "deviceSerial",
          CAST(d."Status"::text AS INTEGER) as "deviceStatus",
          reporter."Name" as "reporterName",
          reporter_dept."Name" as "reporterDepartmentName",
          handler."Name" as "handlerName",
          handler_dept."Name" as "handlerDepartmentName",
          loc."Name" as "deviceLocationName",
          updated_user."FullName" as "updatedByName",
          source_plan."ID" as "sourcePlanId",
          source_plan."PlanDate" as "sourcePlanDate"
        FROM "DamageReport" dr
        LEFT JOIN "Device" d ON dr."DeviceID" = d."ID"
        LEFT JOIN "Staff" reporter ON dr."ReporterID" = reporter."ID"
        LEFT JOIN "Department" reporter_dept ON dr."ReportingDepartmentID" = reporter_dept."ID"
        LEFT JOIN "Staff" handler ON dr."HandlerID" = handler."ID"
        LEFT JOIN "Department" handler_dept ON handler."DepartmentID" = handler_dept."ID"
        LEFT JOIN "Location" loc ON d."LocationID" = loc."ID"
        LEFT JOIN "AspNetUsers" updated_user ON dr."UpdatedBy" = updated_user."Id"
        LEFT JOIN LATERAL (
          SELECT wpi."ID", wpi."PlanDate"
          FROM "WorkPlanItem" wpi
          WHERE wpi."DamageReportID" = dr."ID"
          ORDER BY wpi."ID" DESC
          LIMIT 1
        ) source_plan ON TRUE
        ${y}
        ORDER BY ${{reportDate:'dr."ReportDate"',status:'dr."Status"',priority:'dr."Priority"',deviceName:'d."Name"',id:'dr."ID"',completedDate:'dr."CompletedDate"',estimatedCompletionDate:'dr."EstimatedCompletionDate"'}[N]||'dr."ReportDate"'} ${"desc"===g?"DESC":"ASC"}, dr."ID" DESC
        LIMIT $${S.length+1} OFFSET $${S.length+2}
      `,s=[...S,a,(t-1)*a];return{reports:(await n.Z.query(o,s)).rows.map(e=>this.mapRowToVM(e)),total:d}}catch(e){throw console.error("DamageReportService.getPaginated error:",e),e}}mapRowToVM(e){let t=e.reportDate?new Date(e.reportDate):(0,i.ud)(),a=(0,i.ud)();a.setHours(0,0,0,0);let r=new Date(t);r.setHours(0,0,0,0);let n=Math.floor((a.getTime()-r.getTime())/864e5),o=0;if(e.handlingDate){let t=new Date(e.handlingDate);t.setHours(0,0,0,0),o=Math.floor((a.getTime()-t.getTime())/864e5)}let s=!1;if(e.estimatedCompletionDate&&e.status!==d.OD.Completed&&e.status!==d.OD.Cancelled&&e.status!==d.OD.Rejected){let t=new Date(e.estimatedCompletionDate);t.setHours(0,0,0,0),s=a>t}let D=parseInt(e.status),l=parseInt(e.priority);return{...e,status:D,priority:l,deviceStatus:e.deviceStatus?parseInt(e.deviceStatus):void 0,images:e.images?Array.isArray(e.images)?e.images:JSON.parse(e.images):[],afterImages:e.afterImages?Array.isArray(e.afterImages)?e.afterImages:JSON.parse(e.afterImages):[],statusName:this.getStatusName(D),priorityName:this.getPriorityName(l),daysSinceReport:n,daysInProgress:o,isOverdue:s,isDeleted:!!e.isDeleted,displayLocation:e.deviceName||e.maintenanceBatchTitle||e.damageLocation||"Kh\xf4ng x\xe1c định",deviceLocationName:e.deviceLocationName||null,sourcePlanId:e.sourcePlanId?Number(e.sourcePlanId):null,sourcePlanDate:e.sourcePlanDate||null,isFromWorkPlan:!!e.sourcePlanId}}async getById(e){let t=await n.Z.query(`SELECT 
        dr."ID" as id,
        dr."DeviceID" as "deviceId",
        dr."DamageLocation" as "damageLocation",
        dr."ReporterID" as "reporterId",
        dr."ReportingDepartmentID" as "reportingDepartmentId",
        dr."HandlerID" as "handlerId",
        dr."CoHandlerIDs" as "coHandlerIds",
        (
          SELECT json_agg(json_build_object('id', s."ID", 'name', s."Name"))
          FROM "Staff" s
          WHERE s."ID" = ANY(dr."CoHandlerIDs")
        ) as "coHandlers",
        dr."AssignedDate" as "assignedDate",
        dr."ReportDate" as "reportDate",
        dr."HandlingDate" as "handlingDate",
        dr."CompletedDate" as "completedDate",
        dr."EstimatedCompletionDate" as "estimatedCompletionDate",
        dr."DamageContent" as "damageContent",
        dr."Images" as images,
        dr."AfterImages" as "afterImages",
        CAST(dr."Status"::text AS INTEGER) as status,
        CAST(dr."Priority"::text AS INTEGER) as priority,
        dr."Notes" as notes,
        dr."HandlerNotes" as "handlerNotes",
        dr."RejectionReason" as "rejectionReason",
        dr."MaintenanceBatchId" as "maintenanceBatchId",
        dr."CreatedBy" as "createdBy",
        dr."UpdatedBy" as "updatedBy",
        dr."CreatedAt" as "createdAt",
        dr."UpdatedAt" as "updatedAt",
        dr."IsDeleted" as "isDeleted",
        d."Name" as "deviceName",
        d."Serial" as "deviceSerial",
        CAST(d."Status"::text AS INTEGER) as "deviceStatus",
        reporter."Name" as "reporterName",
        reporter_dept."Name" as "reporterDepartmentName",
        handler."Name" as "handlerName",
        handler_dept."Name" as "handlerDepartmentName",
        loc."Name" as "deviceLocationName",
        updated_user."FullName" as "updatedByName",
        source_plan."ID" as "sourcePlanId",
        source_plan."PlanDate" as "sourcePlanDate",
        (SELECT drp."Title" 
         FROM "DeviceReminderPlan" drp 
         WHERE drp."Metadata" IS NOT NULL
           AND (
             drp."Metadata"::text LIKE '%"maintenanceBatchId":"' || dr."MaintenanceBatchId" || '"%'
             OR (drp."Metadata"::jsonb ? 'maintenanceBatchId' 
                 AND (drp."Metadata"->>'maintenanceBatchId') = dr."MaintenanceBatchId")
           )
         LIMIT 1
        ) as "maintenanceBatchTitle"
      FROM "DamageReport" dr
      LEFT JOIN "Device" d ON dr."DeviceID" = d."ID"
      LEFT JOIN "Staff" reporter ON dr."ReporterID" = reporter."ID"
      LEFT JOIN "Department" reporter_dept ON dr."ReportingDepartmentID" = reporter_dept."ID"
      LEFT JOIN "Staff" handler ON dr."HandlerID" = handler."ID"
      LEFT JOIN "Department" handler_dept ON handler."DepartmentID" = handler_dept."ID"
      LEFT JOIN "Location" loc ON d."LocationID" = loc."ID"
      LEFT JOIN "AspNetUsers" updated_user ON dr."UpdatedBy" = updated_user."Id"
      LEFT JOIN LATERAL (
        SELECT wpi."ID", wpi."PlanDate"
        FROM "WorkPlanItem" wpi
        WHERE wpi."DamageReportID" = dr."ID"
        ORDER BY wpi."ID" DESC
        LIMIT 1
      ) source_plan ON TRUE
      WHERE dr."ID" = $1`,[e]);if(0===t.rows.length)return null;let a=t.rows[0],r=parseInt(a.status),o=parseInt(a.priority),s=a.reportDate?new Date(a.reportDate):(0,i.ud)(),D=(0,i.ud)();D.setHours(0,0,0,0);let l=new Date(s);l.setHours(0,0,0,0);let I=Math.floor((D.getTime()-l.getTime())/864e5),c=0;if(a.handlingDate){let e=new Date(a.handlingDate);e.setHours(0,0,0,0),c=Math.floor((D.getTime()-e.getTime())/864e5)}let p=!1;if(a.estimatedCompletionDate&&r!==d.OD.Completed&&r!==d.OD.Cancelled&&r!==d.OD.Rejected){let e=new Date(a.estimatedCompletionDate);e.setHours(0,0,0,0),p=D>e}return{...a,status:r,priority:o,deviceStatus:a.deviceStatus?parseInt(a.deviceStatus):void 0,images:a.images?Array.isArray(a.images)?a.images:JSON.parse(a.images):[],statusName:this.getStatusName(r),priorityName:this.getPriorityName(o),daysSinceReport:I,daysInProgress:c,isOverdue:p,isDeleted:!!a.isDeleted,displayLocation:a.deviceName||a.maintenanceBatchTitle||a.damageLocation||"Kh\xf4ng x\xe1c định",sourcePlanId:a.sourcePlanId?Number(a.sourcePlanId):null,sourcePlanDate:a.sourcePlanDate||null,isFromWorkPlan:!!a.sourcePlanId}}async create(e){if(!e.damageContent||""===e.damageContent.trim())throw Error("Vui l\xf2ng nhập nội dung c\xf4ng việc");let t=(await n.Z.query(`INSERT INTO "DamageReport" (
        "DeviceID", "DamageLocation", "ReporterID", "ReportingDepartmentID",
        "HandlerID", "CoHandlerIDs", "AssignedDate", "ReportDate", "HandlingDate", "CompletedDate",
        "EstimatedCompletionDate", "DamageContent", "Images", "AfterImages", "Status", "Priority",
        "Notes", "HandlerNotes", "RejectionReason", "MaintenanceBatchId", "CreatedBy", "UpdatedBy"
      )
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17, $18, $19, $20, $21, $22)
      RETURNING "ID"`,[e.deviceId||null,e.damageLocation||null,e.reporterId,e.reportingDepartmentId,e.handlerId||null,e.coHandlerIds||[],e.assignedDate||null,e.reportDate||(0,i.ud)(),e.handlingDate||null,e.completedDate||null,e.estimatedCompletionDate||null,e.damageContent,e.images?JSON.stringify(e.images):null,e.afterImages?JSON.stringify(e.afterImages):null,e.status.toString(),e.priority.toString(),e.notes||null,e.handlerNotes||null,e.rejectionReason||null,e.maintenanceBatchId||null,e.createdBy||null,e.updatedBy||null])).rows[0].ID;if(e.maintenanceBatchId)try{await this.syncMaintenanceBatchEvents(t,e.status,e.createdBy||"",{handlerId:e.handlerId,handlingDate:e.handlingDate,handlerNotes:e.handlerNotes||e.notes,damageContent:e.damageContent})}catch(e){console.error("Failed to sync maintenance events on create:",e)}e.deviceId&&await this.syncDeviceStatus(e.deviceId);try{await this.notifyNewReport(t,e.damageContent,e.reporterId,e.createdBy),e.handlerId&&await this.notifyHandlerAssigned(t,e.handlerId,e.damageContent,e.createdBy)}catch(e){console.error("Failed to send push notifications:",e)}return t}async notifyHandlerAssigned(e,t,a,r){try{let e=new s.gq;await e.createNotification({title:"C\xf4ng việc mới được giao \uD83D\uDCCB",content:`Bạn được giao xử l\xfd b\xe1o c\xe1o: ${a.substring(0,100)}${a.length>100?"...":""}`,type:s.k$.Report,category:s.mN.New,targetUrl:"/dashboard/damage-reports",staffId:t,createdBy:r,excludeUserId:r})}catch(e){console.error("Error in notifyHandlerAssigned:",e)}}async notifyNewReport(e,t,a,r){try{let e=new s.gq,d=await n.Z.query('SELECT "Name" FROM "Staff" WHERE "ID" = $1',[a]),o=d.rows[0]?.Name||"Một nh\xe2n vi\xean";await e.createNotification({title:"B\xe1o c\xe1o sự cố mới ⚠️",content:`${o}: ${t.substring(0,100)}${t.length>100?"...":""}`,type:s.k$.Report,category:s.mN.New,targetUrl:"/dashboard/damage-reports",createdBy:r,excludeUserId:r})}catch(e){console.error("Error in notifyNewReport:",e)}}async update(e){if(!e.damageContent||""===e.damageContent.trim())throw Error("Vui l\xf2ng nhập nội dung c\xf4ng việc");let t=await n.Z.query('SELECT "Status", "Priority", "DeviceID", "HandlerID", "DamageContent", "HandlerNotes" FROM "DamageReport" WHERE "ID" = $1',[e.id]),a=t.rows[0]?.Status,r=t.rows[0]?.Priority,o=t.rows[0]?.HandlerID,s=t.rows[0]?.DamageContent,D=t.rows[0]?.HandlerNotes,l=t.rows[0]?.DeviceID,I=e.handlerNotes;if((!I||"string"==typeof I&&""===I.trim())&&D)I=D;else if(I&&"string"==typeof I&&!I.startsWith("[")&&D&&"string"==typeof D&&D.startsWith("["))try{let e=JSON.parse(D);Array.isArray(e)&&e.length>0&&(I=D)}catch(e){}let c=e.handlingDate,p=e.completedDate,m=(0,i.ud)();if(a&&a!==e.status.toString()){let t=e.status;t===d.OD.Pending?(c=null,p=null):t===d.OD.Completed?p||(p=m):(p=null,t!==d.OD.InProgress||c||(c=m))}if(c&&e.reportDate){let t=new Date(c),a=new Date(e.reportDate);if(t<a)throw Error("Ng\xe0y bắt đầu xử l\xfd kh\xf4ng thể nhỏ hơn ng\xe0y b\xe1o c\xe1o.");if(t>m)throw Error("Ng\xe0y bắt đầu xử l\xfd kh\xf4ng thể vượt qu\xe1 thời gian hiện tại.")}if(p){let t=new Date(p);if(t>m)throw Error("Ng\xe0y ho\xe0n th\xe0nh kh\xf4ng thể vượt qu\xe1 thời gian hiện tại.");if(e.reportDate){let a=new Date(e.reportDate);if(t<a)throw Error("Ng\xe0y ho\xe0n th\xe0nh kh\xf4ng thể nhỏ hơn ng\xe0y b\xe1o c\xe1o.")}if(c){let e=new Date(c);if(t<e)throw Error("Ng\xe0y ho\xe0n th\xe0nh kh\xf4ng thể nhỏ hơn ng\xe0y bắt đầu xử l\xfd.")}}if(await n.Z.query(`UPDATE "DamageReport" SET
        "DeviceID" = $1,
        "DamageLocation" = $2,
        "ReporterID" = $3,
        "ReportingDepartmentID" = $4,
        "HandlerID" = $5,
        "CoHandlerIDs" = $6,
        "AssignedDate" = $7,
        "ReportDate" = $8,
        "HandlingDate" = $9,
        "CompletedDate" = $10,
        "EstimatedCompletionDate" = $11,
        "DamageContent" = $12,
        "Images" = $13,
        "AfterImages" = $14,
        "Status" = $15,
        "Priority" = $16,
        "Notes" = $17,
        "HandlerNotes" = $18,
        "RejectionReason" = $19,
        "MaintenanceBatchId" = $20,
        "UpdatedBy" = $21,
        "UpdatedAt" = CURRENT_TIMESTAMP
      WHERE "ID" = $22`,[e.deviceId||null,e.damageLocation||null,e.reporterId,e.reportingDepartmentId,e.handlerId||null,e.coHandlerIds||[],e.assignedDate||null,e.reportDate,c||null,p||null,e.estimatedCompletionDate||null,e.damageContent,e.images?JSON.stringify(e.images):null,e.afterImages?JSON.stringify(e.afterImages):null,e.status.toString(),e.priority.toString(),e.notes||null,I||null,e.rejectionReason||null,e.maintenanceBatchId||null,e.updatedBy||null,e.id]),a&&a!==e.status.toString()&&e.updatedBy&&await n.Z.query(`INSERT INTO "DamageReportHistory" ("DamageReportID", "FieldName", "OldValue", "NewValue", "ChangedBy")
         VALUES ($1, 'Status', $2, $3, $4)`,[e.id,a,e.status.toString(),e.updatedBy]),r&&r!==e.priority.toString()&&e.updatedBy&&await n.Z.query(`INSERT INTO "DamageReportHistory" ("DamageReportID", "FieldName", "OldValue", "NewValue", "ChangedBy")
         VALUES ($1, 'Priority', $2, $3, $4)`,[e.id,r,e.priority.toString(),e.updatedBy]),e.deviceId&&(e.status===d.OD.Cancelled||(e.status,d.OD.Rejected),await this.syncDeviceStatus(e.deviceId)),l&&l!==e.deviceId&&await this.syncDeviceStatus(l),e.maintenanceBatchId)try{await this.syncMaintenanceBatchEvents(e.id,e.status,e.updatedBy||"",{handlerId:e.handlerId,handlingDate:e.handlingDate,handlerNotes:e.handlerNotes||e.notes,damageContent:e.damageContent})}catch(e){console.error("Failed to sync maintenance events on update:",e)}if(e.handlerId&&e.handlerId!==o)try{await this.notifyHandlerAssigned(e.id,e.handlerId,e.damageContent||s,e.updatedBy)}catch(e){console.error("Failed to notify new handler:",e)}return e.id}async updateStatus(e,t,a,r){let o=await n.Z.connect();try{await o.query("BEGIN");let n=await o.query(`SELECT dr."Status" as status, dr."DeviceID" as device_id, dr."HandlerID" as handler_id, 
                dr."DamageContent" as damage_content, s."Name" as handler_name,
                dr."ReportDate" as report_date, dr."HandlingDate" as handling_date
         FROM "DamageReport" dr
         LEFT JOIN "Staff" s ON dr."HandlerID" = s."ID"
         WHERE dr."ID" = $1`,[e]);if(0===n.rows.length)throw Error("B\xe1o c\xe1o kh\xf4ng tồn tại");let D=n.rows[0],l=String(D.status||""),I=D.device_id,c=D.damage_content||"",p=D.handler_name||"Nh\xe2n vi\xean",m=D.report_date?new Date(D.report_date):null,N=D.handling_date?new Date(D.handling_date):null,g='UPDATE "DamageReport" SET "Status" = $1, "UpdatedBy" = $2, "UpdatedAt" = CURRENT_TIMESTAMP',h=[t.toString(),a,e],E=(0,i.ud)();if(t===d.OD.Pending)g+=', "HandlingDate" = NULL, "CompletedDate" = NULL';else if(t===d.OD.Completed){if(N&&E<N)throw Error("Ng\xe0y ho\xe0n th\xe0nh kh\xf4ng thể nhỏ hơn ng\xe0y bắt đầu xử l\xfd. Vui l\xf2ng kiểm tra lại thời gian tr\xean hệ thống.");if(m&&E<m)throw Error("Ng\xe0y ho\xe0n th\xe0nh kh\xf4ng thể nhỏ hơn ng\xe0y b\xe1o c\xe1o. Vui l\xf2ng kiểm tra lại thời gian b\xe1o c\xe1o.");g+=', "CompletedDate" = $4',h.push(E)}else if(g+=', "CompletedDate" = NULL',t===d.OD.InProgress&&!N){if(m&&E<m)throw Error("Ng\xe0y bắt đầu xử l\xfd kh\xf4ng thể nhỏ hơn ng\xe0y b\xe1o c\xe1o. Vui l\xf2ng kiểm tra lại thời gian b\xe1o c\xe1o.");g+=`, "HandlingDate" = $${h.length+1}`,h.push(E)}g+=' WHERE "ID" = $3',await o.query(g,h),l!==t.toString()&&(await this.ensureHistorySequence(),await o.query(`INSERT INTO "DamageReportHistory" ("DamageReportID", "FieldName", "OldValue", "NewValue", "ChangedBy")
           VALUES ($1, 'Status', $2, $3, $4)`,[e,l,t.toString(),a])),I&&(r&&await o.query('UPDATE "Device" SET "Status" = $1 WHERE "ID" = $2',[r.toString(),I]),await this.syncDeviceStatus(I,o)),await o.query("COMMIT");try{await this.syncMaintenanceBatchEvents(e,t,a,{handlerId:D.handler_id,handlingDate:N,damageContent:c})}catch(e){console.error("Failed to sync maintenance events on updateStatus:",e)}if(l!==t.toString()){let e=new s.gq;t===d.OD.Assigned&&D.handler_id?await e.createNotification({title:"C\xf4ng việc mới được giao \uD83D\uDCCB",content:`Bạn được giao xử l\xfd b\xe1o c\xe1o: ${c.substring(0,50)}...`,type:s.k$.Report,category:s.mN.New,targetUrl:"/dashboard/damage-reports",staffId:D.handler_id,createdBy:a}):t===d.OD.InProgress?await e.createNotification({title:"B\xe1o c\xe1o đang được xử l\xfd \uD83D\uDEE0️",content:`${p} đang xử l\xfd b\xe1o c\xe1o: ${c.substring(0,50)}...`,type:s.k$.Report,category:s.mN.InProgress,targetUrl:"/dashboard/damage-reports",staffId:D.handler_id,createdBy:a}):t===d.OD.Completed&&await e.createNotification({title:"B\xe1o c\xe1o đ\xe3 ho\xe0n th\xe0nh ✅",content:`B\xe1o c\xe1o: ${c.substring(0,50)}... đ\xe3 được ho\xe0n th\xe0nh.`,type:s.k$.Report,category:s.mN.Completed,targetUrl:"/dashboard/damage-reports",staffId:D.handler_id,createdBy:a})}return e}catch(e){throw await o.query("ROLLBACK"),e}finally{o.release()}}async updateHandlingDate(e,t,a){let r=await n.Z.query('SELECT "HandlingDate" FROM "DamageReport" WHERE "ID" = $1',[e]);if(0===r.rows.length)throw Error("B\xe1o c\xe1o kh\xf4ng tồn tại");await n.Z.query('UPDATE "DamageReport" SET "HandlingDate" = $1, "UpdatedBy" = $2, "UpdatedAt" = CURRENT_TIMESTAMP WHERE "ID" = $3',[t||null,a,e])}async updateCompletionDate(e,t,a){let r=await n.Z.query('SELECT "CompletedDate" FROM "DamageReport" WHERE "ID" = $1',[e]);if(0===r.rows.length)throw Error("B\xe1o c\xe1o kh\xf4ng tồn tại");let d=r.rows[0].CompletedDate?new Date(r.rows[0].CompletedDate):null;await n.Z.query('UPDATE "DamageReport" SET "CompletedDate" = $1, "UpdatedBy" = $2, "UpdatedAt" = CURRENT_TIMESTAMP WHERE "ID" = $3',[t||null,a,e]);let o=d?d.toISOString():"",s=t?t.toISOString():"";o!==s&&(await this.ensureHistorySequence(),await n.Z.query(`INSERT INTO "DamageReportHistory" ("DamageReportID", "FieldName", "OldValue", "NewValue", "ChangedBy")
         VALUES ($1, 'CompletedDate', $2, $3, $4)`,[e,o,s,a]))}async updatePriority(e,t,a){let r=await n.Z.query('SELECT "Priority" FROM "DamageReport" WHERE "ID" = $1',[e]);if(0===r.rows.length)throw Error("B\xe1o c\xe1o kh\xf4ng tồn tại");let d=r.rows[0].Priority;return await n.Z.query('UPDATE "DamageReport" SET "Priority" = $1, "UpdatedBy" = $2, "UpdatedAt" = CURRENT_TIMESTAMP WHERE "ID" = $3',[t.toString(),a,e]),d!==t.toString()&&await n.Z.query(`INSERT INTO "DamageReportHistory" ("DamageReportID", "FieldName", "OldValue", "NewValue", "ChangedBy")
         VALUES ($1, 'Priority', $2, $3, $4)`,[e,d,t.toString(),a]),e}parseTimelineNotes(e){if(!e)return[];try{let t=JSON.parse(e);if(Array.isArray(t)&&t.length>0&&t[0].hasOwnProperty("timestamp"))return t}catch(e){}return[{id:Math.random().toString(36).substring(2,9),timestamp:new Date().toISOString(),author:"Hệ thống",content:e,type:"legacy"}]}async appendTimelineNote(e,t,a,r,d){let o=await n.Z.query('SELECT "HandlerNotes" FROM "DamageReport" WHERE "ID" = $1',[e]);if(0===o.rows.length)throw Error("B\xe1o c\xe1o kh\xf4ng tồn tại");let s=o.rows[0].HandlerNotes,i=this.parseTimelineNotes(s),D={id:Math.random().toString(36).substring(2,9)+Date.now().toString(36),timestamp:new Date().toISOString(),author:r,content:t,type:a};i.push(D);let l=JSON.stringify(i);return await n.Z.query('UPDATE "DamageReport" SET "HandlerNotes" = $1, "UpdatedBy" = $2, "UpdatedAt" = CURRENT_TIMESTAMP WHERE "ID" = $3',[l,d,e]),await n.Z.query(`INSERT INTO "DamageReportHistory" ("DamageReportID", "FieldName", "OldValue", "NewValue", "ChangedBy")
       VALUES ($1, 'HandlerNotes', $2, $3, $4)`,[e,s||"",l,d]),l}async upsertDailyCheckinNote(e,t,a,r){let d=await n.Z.query('SELECT "HandlerNotes" FROM "DamageReport" WHERE "ID" = $1',[e]);if(0===d.rows.length)throw Error("B\xe1o c\xe1o kh\xf4ng tồn tại");let o=d.rows[0].HandlerNotes,s=this.parseTimelineNotes(o),i=new Date().toISOString().split("T")[0],D=-1;for(let e=s.length-1;e>=0;e--)if("auto"===s[e].type&&s[e].timestamp.startsWith(i)){D=e;break}if(-1!==D)s[D].content=t,s[D].timestamp=new Date().toISOString();else{let e={id:Math.random().toString(36).substring(2,9)+Date.now().toString(36),timestamp:new Date().toISOString(),author:a,content:t,type:"auto"};s.push(e)}let l=JSON.stringify(s);return await n.Z.query('UPDATE "DamageReport" SET "HandlerNotes" = $1, "UpdatedBy" = $2, "UpdatedAt" = CURRENT_TIMESTAMP WHERE "ID" = $3',[l,r,e]),await n.Z.query(`INSERT INTO "DamageReportHistory" ("DamageReportID", "FieldName", "OldValue", "NewValue", "ChangedBy")
       VALUES ($1, 'HandlerNotes', $2, $3, $4)`,[e,o||"",l,r]),l}async updateHandlerNotes(e,t,a){let r=(t||"").trim();if(""===r||"[]"===r)return await n.Z.query('UPDATE "DamageReport" SET "HandlerNotes" = NULL, "UpdatedBy" = $1, "UpdatedAt" = CURRENT_TIMESTAMP WHERE "ID" = $2',[a,e]),await n.Z.query(`INSERT INTO "DamageReportHistory" ("DamageReportID", "FieldName", "OldValue", "NewValue", "ChangedBy")
         VALUES ($1, 'HandlerNotes_Clear', 'Cleared', '', $2)`,[e,a]),"";let d=!1;try{if(r.startsWith("[")){let e=JSON.parse(r);Array.isArray(e)&&e.length>0&&(e[0].hasOwnProperty("timestamp")||e[0].hasOwnProperty("content"))&&(d=!0)}}catch(e){}if(d)return await n.Z.query('UPDATE "DamageReport" SET "HandlerNotes" = $1, "UpdatedBy" = $2, "UpdatedAt" = CURRENT_TIMESTAMP WHERE "ID" = $3',[t,a,e]),await n.Z.query(`INSERT INTO "DamageReportHistory" ("DamageReportID", "FieldName", "OldValue", "NewValue", "ChangedBy")
         VALUES ($1, 'HandlerNotes_Update', 'Timeline Update', $2, $3)`,[e,t,a]),t;let o="Người xử l\xfd";try{let e=await n.Z.query('SELECT "Name" FROM "Staff" WHERE "UserId" = $1',[a]);e.rows.length>0&&(o=e.rows[0].Name)}catch(e){}return this.appendTimelineNote(e,t,"manual",o,a)}async updateImages(e,t,a){let r=await n.Z.query('SELECT "Images" FROM "DamageReport" WHERE "ID" = $1',[e]);if(0===r.rows.length)throw Error("B\xe1o c\xe1o kh\xf4ng tồn tại");let d=r.rows[0].Images;await n.Z.query('UPDATE "DamageReport" SET "Images" = $1, "UpdatedBy" = $2, "UpdatedAt" = CURRENT_TIMESTAMP WHERE "ID" = $3',[t?JSON.stringify(t):null,a,e]);let o=d?"string"==typeof d?d:JSON.stringify(d):"[]",s=t?JSON.stringify(t):"[]";return o!==s&&await n.Z.query(`INSERT INTO "DamageReportHistory" ("DamageReportID", "FieldName", "OldValue", "NewValue", "ChangedBy")
         VALUES ($1, 'Images', $2, $3, $4)`,[e,o,s,a]),e}async updateAfterImages(e,t,a){let r=await n.Z.query('SELECT "AfterImages" FROM "DamageReport" WHERE "ID" = $1',[e]);if(0===r.rows.length)throw Error("B\xe1o c\xe1o kh\xf4ng tồn tại");let d=r.rows[0].AfterImages;await n.Z.query('UPDATE "DamageReport" SET "AfterImages" = $1, "UpdatedBy" = $2, "UpdatedAt" = CURRENT_TIMESTAMP WHERE "ID" = $3',[t?JSON.stringify(t):null,a,e]);let o=d?"string"==typeof d?d:JSON.stringify(d):"[]",s=t?JSON.stringify(t):"[]";return o!==s&&await n.Z.query(`INSERT INTO "DamageReportHistory" ("DamageReportID", "FieldName", "OldValue", "NewValue", "ChangedBy")
         VALUES ($1, 'AfterImages', $2, $3, $4)`,[e,o,s,a]),e}async delete(e){return await n.Z.query('DELETE FROM "DamageReport" WHERE "ID" = $1',[e]),!0}async softDelete(e,t){return await n.Z.query('UPDATE "DamageReport" SET "IsDeleted" = true, "UpdatedBy" = $2, "UpdatedAt" = NOW() WHERE "ID" = $1',[e,t]),!0}async syncMaintenanceBatchEvents(e,t,r,i){let D=(await n.Z.query(`SELECT "MaintenanceBatchId", "DamageContent", "HandlerID", "HandlingDate", "HandlerNotes" 
       FROM "DamageReport" WHERE "ID" = $1`,[e])).rows[0];if(!D||!D.MaintenanceBatchId)return;let l=D.MaintenanceBatchId,I=new o.P,c=d.N3.Planned,p=Number(t);p===d.OD.InProgress?c=d.N3.InProgress:p===d.OD.Completed?c=d.N3.Completed:(p===d.OD.Cancelled||p===d.OD.Rejected)&&(c=d.N3.Cancelled);let m=new Date,N=[d.OD.InProgress,d.OD.Completed].includes(p)?', "StartDate" = COALESCE("StartDate", CURRENT_TIMESTAMP)':"",g=[d.OD.Completed,d.OD.Cancelled,d.OD.Rejected].includes(p)?', "EndDate" = COALESCE("EndDate", CURRENT_TIMESTAMP)':', "EndDate" = NULL',h=`%"maintenanceBatchId":"${l}"%`,E="",u=-1,R=[c,e];i?.handlerNotes!==void 0&&(R.push(i.handlerNotes),u=R.length,E=`, "Notes" = $${u}`),await n.Z.query(`UPDATE "Event" 
       SET "Status" = $1, "UpdatedAt" = CURRENT_TIMESTAMP ${N} ${g} ${E}
       WHERE "RelatedReportID" = $2`,R),(await n.Z.query('SELECT "DeviceID" FROM "Event" WHERE "RelatedReportID" = $1',[e])).rows.map(e=>e.DeviceID);let S=[c,e,h,l],y="";i?.handlerNotes!==void 0&&(S.push(i.handlerNotes),y=`, "Notes" = $${S.length}`),await n.Z.query(`UPDATE "Event" 
       SET "Status" = $1, "UpdatedAt" = CURRENT_TIMESTAMP ${N} ${g} ${y},
           "RelatedReportID" = $2
       WHERE ("Metadata"::text LIKE $3 OR ("Metadata"->>'maintenanceBatchId') = $4)
         AND "RelatedReportID" IS NULL`,S);let O=(await n.Z.query(`
      SELECT 
        drp."ID" as id,
        drp."DeviceID" as "deviceId",
        drp."Title" as title,
        drp."EventTypeID" as "eventTypeId",
        drp."IntervalValue" as "intervalValue",
        drp."IntervalUnit" as "intervalUnit",
        drp."NextDueDate" as "nextDueDate",
        drp."Metadata" as metadata,
        d."Name" as "deviceName"
      FROM "DeviceReminderPlan" drp
      LEFT JOIN "Device" d ON drp."DeviceID" = d."ID"
      WHERE drp."Metadata" IS NOT NULL
        AND (
          drp."Metadata"::text LIKE $1
          OR (drp."Metadata"->>'maintenanceBatchId') = $2
        )
        AND drp."IsActive" = true
      `,[h,l])).rows||[],T=await n.Z.query('SELECT "DeviceID" FROM "Event" WHERE "RelatedReportID" = $1',[e]),$=new Set(T.rows.map(e=>e.DeviceID)),C=O.filter(e=>!$.has(e.deviceId)),L=Array.from(new Map(C.map(e=>[e.deviceId,e])).values());if(L.length>0){let t={source:"damage-report-sync",damageReportId:e,maintenanceBatchId:l,syncAt:m.toISOString()},a=L.map(a=>{let n=i?.handlerNotes||D.HandlerNotes||"",o="";if(n)try{if("string"==typeof n&&n.trim().startsWith("[")){let e=JSON.parse(n);if(Array.isArray(e)&&e.length>0){let t=e.filter(e=>"auto"!==e.type),a=t.length>0?t[t.length-1]:e[e.length-1];o=a?.content||""}}else o=n}catch{o=n}return o=o.substring(0,200),I.create({title:i?.eventTitle||(a.deviceName?`Bảo tr\xec định kỳ - ${a.deviceName}`:`Bảo tr\xec định kỳ - ${a.title||i?.damageContent||D.DamageContent||"Bảo tr\xec"}`),deviceId:a.deviceId,eventTypeId:i?.eventTypeId||a.eventTypeId||1,description:i?.eventDescription||i?.damageContent||D.DamageContent||a.title||"",notes:o,status:c,eventDate:m,startDate:i?.handlingDate?new Date(i?.handlingDate):p===d.OD.InProgress||p===d.OD.Completed?m:null,endDate:p===d.OD.Completed||p===d.OD.Cancelled||p===d.OD.Rejected?m:null,staffId:i?.handlerId||D.HandlerID||null,relatedReportId:e,metadata:t,createdBy:r,createdAt:m,updatedBy:r||null,updatedAt:m})});await Promise.all(a)}if(p===d.OD.Completed){try{let{calculateNextDueDate:e}=a(69202),t=new Date;t.setHours(0,0,0,0);let r=O.map(e=>e.id);if(r.length>0)for(let a of(await n.Z.query(`SELECT "ID", "StartFrom", "NextDueDate", "IntervalValue", "IntervalUnit", "Metadata"
             FROM "DeviceReminderPlan"
             WHERE "ID" = ANY($1::int[]) AND "IsActive" = true`,[r])).rows){let r=a.NextDueDate?new Date(a.NextDueDate):null;if(!r)continue;if(r.setHours(0,0,0,0),r>t){console.log(`Plan ${a.ID}: NextDueDate đ\xe3 được bump (${r.toISOString().split("T")[0]}), bỏ qua`);continue}if(!a.IntervalValue||!a.IntervalUnit)continue;let d={};try{d="string"==typeof a.Metadata?JSON.parse(a.Metadata):a.Metadata||{}}catch(e){}let o=a.StartFrom?new Date(a.StartFrom):null,s=e(t,a.IntervalValue,a.IntervalUnit,d?.scheduleConfig||null,!1,o);await n.Z.query(`UPDATE "DeviceReminderPlan"
               SET "NextDueDate" = $1, "LastTriggeredAt" = $2, "UpdatedAt" = CURRENT_TIMESTAMP
               WHERE "ID" = $3`,[s,t,a.ID]),console.log(`Plan ${a.ID}: Đ\xe3 bump NextDueDate từ ${r.toISOString().split("T")[0]} → ${s.toISOString().split("T")[0]}`)}}catch(e){console.error("Error bumping NextDueDate on completion:",e)}try{let e=await n.Z.query('SELECT "Name" FROM "Staff" WHERE "ID" = $1',[D.HandlerID]),t=e.rows[0]?.Name||"Nh\xe2n vi\xean",a=O[0]?.title||"Đợt bảo tr\xec",d=new s.gq;await d.createNotification({title:"Bảo tr\xec đ\xe3 thực hiện \uD83D\uDD27",content:`${t} đ\xe3 ho\xe0n th\xe0nh bảo tr\xec: ${a}`,type:s.k$.Maintenance,category:s.mN.Completed,targetUrl:"/dashboard/maintenance",createdBy:r||void 0})}catch(e){console.error("Error sending maintenance completion notification:",e)}}}async syncDeviceStatus(e,t){if(!e)return;let a=parseInt(e.toString());if(isNaN(a))return;let r=t||n.Z;try{let e=(await r.query(`SELECT CAST("Status"::text AS INTEGER) as status
         FROM "DamageReport" 
         WHERE "DeviceID" = $1 AND "Status"::text IN ('1', '2', '3')`,[a])).rows.map(e=>e.status),t=d.Ly.DangSuDung;e.includes(d.OD.InProgress)?t=d.Ly.DangSuaChua:e.length>0&&(t=d.Ly.CoHuHong),await r.query('UPDATE "Device" SET "Status" = $1 WHERE "ID" = $2',[t.toString(),a]),console.log(`Sync success: Device ${a} status updated to ${t}`)}catch(e){console.error("syncDeviceStatus failed:",e)}}async getDailyReportData(e,t){let[a,r,d]=e.split("-").map(Number),o=new Date(a,r-1,d,0,0,0,0),s=new Date(a,r-1,d,23,59,59,999),i=' AND (dr."IsDeleted" = false OR dr."IsDeleted" IS NULL)',D=[],l=1;t?.departmentId&&t.departmentId>0&&(i+=` AND handler."DepartmentID" = $${l++}`,D.push(t.departmentId)),t?.handlerId&&t.handlerId>0&&(i+=` AND dr."HandlerID" = $${l++}`,D.push(t.handlerId)),t?.maintenanceBatchId&&("only-maintenance"===t.maintenanceBatchId?i+=' AND dr."MaintenanceBatchId" IS NOT NULL':"none-maintenance"===t.maintenanceBatchId?i+=' AND dr."MaintenanceBatchId" IS NULL':(i+=` AND dr."MaintenanceBatchId" = $${l++}`,D.push(t.maintenanceBatchId))),t?.search&&(i+=` AND (
        dr."DamageContent" ILIKE $${l} OR
        dr."DamageLocation" ILIKE $${l} OR
        d."Name" ILIKE $${l} OR
        reporter."Name" ILIKE $${l} OR
        handler."Name" ILIKE $${l}
      )`,D.push(`%${t.search}%`),l++);let I=await n.Z.query(`SELECT 
         dr."ID" as id, dr."DeviceID" as "deviceId", dr."DamageLocation" as "damageLocation",
         dr."ReporterID" as "reporterId", dr."ReportingDepartmentID" as "reportingDepartmentId",
         dr."HandlerID" as "handlerId", dr."ReportDate" as "reportDate",
         dr."HandlingDate" as "handlingDate", dr."CompletedDate" as "completedDate",
         dr."DamageContent" as "damageContent",
         dr."MaintenanceBatchId" as "maintenanceBatchId",
         CAST(dr."Status"::text AS INTEGER) as status,
         CAST(dr."Priority"::text AS INTEGER) as priority,
         dr."Notes" as notes, dr."HandlerNotes" as "handlerNotes",
         d."Name" as "deviceName",
         reporter."Name" as "reporterName",
         handler."Name" as "handlerName",
         handler_dept."Name" as "handlerDepartmentName",
         loc."Name" as "deviceLocationName",
         cat."Name" as "deviceCategoryName",
         dr."CoHandlerIDs" as "coHandlerIds",
         (
           SELECT json_agg(json_build_object('id', ch_s."ID", 'name', ch_s."Name", 'departmentName', ch_d."Name"))
           FROM unnest(dr."CoHandlerIDs") AS ch(id)
           JOIN "Staff" ch_s ON ch_s."ID" = ch.id
           LEFT JOIN "Department" ch_d ON ch_s."DepartmentID" = ch_d."ID"
         ) as "coHandlers"
       FROM "DamageReport" dr
       LEFT JOIN "Device" d ON dr."DeviceID" = d."ID"
       LEFT JOIN "Staff" reporter ON dr."ReporterID" = reporter."ID"
       LEFT JOIN "Staff" handler ON dr."HandlerID" = handler."ID"
       LEFT JOIN "Department" handler_dept ON handler."DepartmentID" = handler_dept."ID"
       LEFT JOIN "Location" loc ON d."LocationID" = loc."ID"
       LEFT JOIN "DeviceCategory" cat ON d."DeviceCategoryID" = cat."ID"
       WHERE dr."ReportDate" >= $${l} AND dr."ReportDate" <= $${l+1}
         AND dr."ID" NOT IN (
           -- Exclude reports handled today (Status 3 + activity)
           SELECT dr2."ID" 
           FROM "DamageReport" dr2
           LEFT JOIN "DailyWorkLog" dwl ON dwl."DamageReportID" = dr2."ID" AND dwl."WorkDate" = $${l+2}::date
           WHERE CAST(dr2."Status"::text AS INTEGER) = 3
             AND (dwl."DamageReportID" IS NOT NULL OR dr2."HandlerNotes" LIKE '%' || $${l+2} || '%')
         )
         AND dr."ID" NOT IN (
           -- Exclude reports completed today
           SELECT dr3."ID" 
           FROM "DamageReport" dr3
           WHERE CAST(dr3."Status"::text AS INTEGER) = 4
             AND dr3."CompletedDate" >= $${l} AND dr3."CompletedDate" <= $${l+1}
         )
       ${i}
       ORDER BY dr."ReportDate" DESC`,[...D,o,s,e]),c=i,p=[...D,e],m=p.length;t?.handlerId&&t.handlerId>0&&(c=c.replace('dr."HandlerID" =','COALESCE(dwl."StaffID", dr."HandlerID") =')),t?.departmentId&&t.departmentId>0&&(c=c.replace('handler."DepartmentID" =','COALESCE(s."DepartmentID", handler."DepartmentID") ='));let N=await n.Z.query(`SELECT 
         dr."ID" as id, dr."DeviceID" as "deviceId", dr."DamageLocation" as "damageLocation",
         dr."ReporterID" as "reporterId", dr."ReportingDepartmentID" as "reportingDepartmentId",
         dr."HandlerID" as "handlerId", dr."ReportDate" as "reportDate",
         dr."HandlingDate" as "handlingDate", dr."CompletedDate" as "completedDate",
         dr."DamageContent" as "damageContent",
         dr."MaintenanceBatchId" as "maintenanceBatchId",
         CAST(dr."Status"::text AS INTEGER) as status,
         CAST(dr."Priority"::text AS INTEGER) as priority,
         dr."Notes" as notes, dr."HandlerNotes" as "handlerNotes",
         d."Name" as "deviceName",
         reporter."Name" as "reporterName",
         handler."Name" as "handlerName",
         handler_dept."Name" as "handlerDepartmentName",
         loc."Name" as "deviceLocationName",
         cat."Name" as "deviceCategoryName",
         dwl."Notes" as "workNotes",
         s."Name" as "checkinStaffName",
         dr."CoHandlerIDs" as "coHandlerIds",
         (
           SELECT json_agg(json_build_object('id', ch_s."ID", 'name', ch_s."Name", 'departmentName', ch_d."Name"))
           FROM unnest(dr."CoHandlerIDs") AS ch(id)
           JOIN "Staff" ch_s ON ch_s."ID" = ch.id
           LEFT JOIN "Department" ch_d ON ch_s."DepartmentID" = ch_d."ID"
         ) as "coHandlers"
       FROM "DamageReport" dr
       LEFT JOIN "DailyWorkLog" dwl ON dwl."DamageReportID" = dr."ID" AND dwl."WorkDate" = $${m}::date
       LEFT JOIN "Staff" s ON dwl."StaffID" = s."ID"
       LEFT JOIN "Device" d ON dr."DeviceID" = d."ID"
       LEFT JOIN "Staff" reporter ON dr."ReporterID" = reporter."ID"
       LEFT JOIN "Staff" handler ON dr."HandlerID" = handler."ID"
       LEFT JOIN "Department" handler_dept ON handler."DepartmentID" = handler_dept."ID"
       LEFT JOIN "Location" loc ON d."LocationID" = loc."ID"
       LEFT JOIN "DeviceCategory" cat ON d."DeviceCategoryID" = cat."ID"
       WHERE CAST(dr."Status"::text AS INTEGER) = 3
         AND (
           dwl."DamageReportID" IS NOT NULL 
           OR (dr."HandlerNotes" IS NOT NULL AND dr."HandlerNotes" LIKE '%' || $${m} || '%')
         )
       ${c}
       ORDER BY dr."ReportDate" ASC`,p),g=await n.Z.query(`SELECT 
         dr."ID" as id, dr."DeviceID" as "deviceId", dr."DamageLocation" as "damageLocation",
         dr."ReporterID" as "reporterId", dr."ReportingDepartmentID" as "reportingDepartmentId",
         dr."HandlerID" as "handlerId", dr."ReportDate" as "reportDate",
         dr."HandlingDate" as "handlingDate", dr."CompletedDate" as "completedDate",
         dr."DamageContent" as "damageContent",
         dr."MaintenanceBatchId" as "maintenanceBatchId",
         CAST(dr."Status"::text AS INTEGER) as status,
         CAST(dr."Priority"::text AS INTEGER) as priority,
         dr."Notes" as notes, dr."HandlerNotes" as "handlerNotes",
         d."Name" as "deviceName",
         reporter."Name" as "reporterName",
         handler."Name" as "handlerName",
         handler_dept."Name" as "handlerDepartmentName",
         loc."Name" as "deviceLocationName",
         cat."Name" as "deviceCategoryName",
         dr."CoHandlerIDs" as "coHandlerIds",
         (
           SELECT json_agg(json_build_object('id', ch_s."ID", 'name', ch_s."Name", 'departmentName', ch_d."Name"))
           FROM unnest(dr."CoHandlerIDs") AS ch(id)
           JOIN "Staff" ch_s ON ch_s."ID" = ch.id
           LEFT JOIN "Department" ch_d ON ch_s."DepartmentID" = ch_d."ID"
         ) as "coHandlers"
       FROM "DamageReport" dr
       LEFT JOIN "Device" d ON dr."DeviceID" = d."ID"
       LEFT JOIN "Staff" reporter ON dr."ReporterID" = reporter."ID"
       LEFT JOIN "Staff" handler ON dr."HandlerID" = handler."ID"
       LEFT JOIN "Department" handler_dept ON handler."DepartmentID" = handler_dept."ID"
       LEFT JOIN "Location" loc ON d."LocationID" = loc."ID"
       LEFT JOIN "DeviceCategory" cat ON d."DeviceCategoryID" = cat."ID"
       WHERE CAST(dr."Status"::text AS INTEGER) = 4
         AND dr."CompletedDate" >= $${l} AND dr."CompletedDate" <= $${l+1}
         ${i}
       ORDER BY dr."CompletedDate" DESC`,[...D,o,s]),h=await n.Z.query(`SELECT 
         dr."ID" as id, dr."DeviceID" as "deviceId", dr."DamageLocation" as "damageLocation",
         dr."ReporterID" as "reporterId", dr."ReportingDepartmentID" as "reportingDepartmentId",
         dr."HandlerID" as "handlerId", dr."ReportDate" as "reportDate",
         dr."HandlingDate" as "handlingDate", dr."CompletedDate" as "completedDate",
         dr."DamageContent" as "damageContent",
         dr."MaintenanceBatchId" as "maintenanceBatchId",
         CAST(dr."Status"::text AS INTEGER) as status,
         CAST(dr."Priority"::text AS INTEGER) as priority,
         dr."Notes" as notes, dr."HandlerNotes" as "handlerNotes",
         d."Name" as "deviceName",
         reporter."Name" as "reporterName",
         handler."Name" as "handlerName",
         handler_dept."Name" as "handlerDepartmentName",
         loc."Name" as "deviceLocationName",
         cat."Name" as "deviceCategoryName",
         dr."CoHandlerIDs" as "coHandlerIds",
         (
           SELECT json_agg(json_build_object('id', ch_s."ID", 'name', ch_s."Name", 'departmentName', ch_d."Name"))
           FROM unnest(dr."CoHandlerIDs") AS ch(id)
           JOIN "Staff" ch_s ON ch_s."ID" = ch.id
           LEFT JOIN "Department" ch_d ON ch_s."DepartmentID" = ch_d."ID"
         ) as "coHandlers"
       FROM "DamageReport" dr
       LEFT JOIN "Device" d ON dr."DeviceID" = d."ID"
       LEFT JOIN "Staff" reporter ON dr."ReporterID" = reporter."ID"
       LEFT JOIN "Staff" handler ON dr."HandlerID" = handler."ID"
       LEFT JOIN "Department" handler_dept ON handler."DepartmentID" = handler_dept."ID"
       LEFT JOIN "Location" loc ON d."LocationID" = loc."ID"
       LEFT JOIN "DeviceCategory" cat ON d."DeviceCategoryID" = cat."ID"
       WHERE dr."ReportDate" <= $${l}
       AND (
         (dr."HandlingDate" IS NULL AND CAST(dr."Status"::text AS INTEGER) IN (1, 2))
         OR dr."HandlingDate" > $${l}
       )
       AND (
         (dr."CompletedDate" IS NULL AND CAST(dr."Status"::text AS INTEGER) NOT IN (4, 5, 6))
         OR dr."CompletedDate" > $${l}
       )
       ${i}
       ORDER BY dr."ReportDate" DESC`,[...D,s]),E=await n.Z.query(`SELECT 
         dr."ID" as id, dr."DeviceID" as "deviceId", dr."DamageLocation" as "damageLocation",
         dr."ReporterID" as "reporterId", dr."ReportingDepartmentID" as "reportingDepartmentId",
         dr."HandlerID" as "handlerId", dr."ReportDate" as "reportDate",
         dr."HandlingDate" as "handlingDate", dr."CompletedDate" as "completedDate",
         dr."DamageContent" as "damageContent",
         dr."MaintenanceBatchId" as "maintenanceBatchId",
         CAST(dr."Status"::text AS INTEGER) as status,
         CAST(dr."Priority"::text AS INTEGER) as priority,
         dr."Notes" as notes, dr."HandlerNotes" as "handlerNotes",
         d."Name" as "deviceName",
         reporter."Name" as "reporterName",
         handler."Name" as "handlerName",
         handler_dept."Name" as "handlerDepartmentName",
         loc."Name" as "deviceLocationName",
         cat."Name" as "deviceCategoryName",
         dr."CoHandlerIDs" as "coHandlerIds",
         (
           SELECT json_agg(json_build_object('id', ch_s."ID", 'name', ch_s."Name", 'departmentName', ch_d."Name"))
           FROM unnest(dr."CoHandlerIDs") AS ch(id)
           JOIN "Staff" ch_s ON ch_s."ID" = ch.id
           LEFT JOIN "Department" ch_d ON ch_s."DepartmentID" = ch_d."ID"
         ) as "coHandlers"
       FROM "DamageReport" dr
       LEFT JOIN "Device" d ON dr."DeviceID" = d."ID"
       LEFT JOIN "Staff" reporter ON dr."ReporterID" = reporter."ID"
       LEFT JOIN "Staff" handler ON dr."HandlerID" = handler."ID"
       LEFT JOIN "Department" handler_dept ON handler."DepartmentID" = handler_dept."ID"
       LEFT JOIN "Location" loc ON d."LocationID" = loc."ID"
       LEFT JOIN "DeviceCategory" cat ON d."DeviceCategoryID" = cat."ID"
       WHERE dr."ReportDate" <= $${l}
       AND (
         (dr."HandlingDate" IS NOT NULL AND dr."HandlingDate" <= $${l})
         OR (dr."HandlingDate" IS NULL AND CAST(dr."Status"::text AS INTEGER) = 3)
       )
       AND (
         (dr."CompletedDate" IS NULL AND CAST(dr."Status"::text AS INTEGER) NOT IN (4, 5, 6))
         OR dr."CompletedDate" > $${l}
       )
       ${i}
       ORDER BY dr."ReportDate" DESC`,[...D,s]),u=e=>({id:e.id,deviceId:e.deviceId,damageLocation:e.damageLocation,reporterId:e.reporterId,reportingDepartmentId:e.reportingDepartmentId,handlerId:e.handlerId,reportDate:e.reportDate,handlingDate:e.handlingDate,completedDate:e.completedDate,damageContent:e.damageContent,status:e.status,priority:e.priority,notes:e.notes,handlerNotes:e.handlerNotes,maintenanceBatchId:e.maintenanceBatchId,deviceName:e.deviceName,reporterName:e.reporterName,handlerName:e.handlerName,handlerDepartmentName:e.handlerDepartmentName,deviceLocationName:e.deviceLocationName,deviceCategoryName:e.deviceCategoryName,coHandlerIds:e.coHandlerIds||[],coHandlers:e.coHandlers||[],workNotes:e.workNotes,checkinStaffName:e.checkinStaffName,statusName:this.getStatusName(e.status),priorityName:this.getPriorityName(e.priority)});return{newReports:I.rows.map(u),activeReports:N.rows.map(u),completedReports:g.rows.map(u),pendingReports:h.rows.map(u),pendingActiveReports:E.rows.map(u),summary:{totalNew:I.rows.length,totalActive:N.rows.length,totalCompleted:g.rows.length,totalPending:h.rows.length,totalPendingActive:E.rows.length}}}}r()}catch(e){r(e)}})},69202:(e,t,a)=>{a.r(t),a.d(t,{calculateNextDueDate:()=>D});var r=a(66615),n=a(69689),d=a(61494);function o(e,t){(0,d.Z)(2,arguments);var a=(0,n.Z)(e),o=(0,r.Z)(t);return isNaN(o)?new Date(NaN):(o&&a.setDate(a.getDate()+o),a)}function s(e,t){(0,d.Z)(2,arguments);var a=(0,n.Z)(e),o=(0,r.Z)(t);if(isNaN(o))return new Date(NaN);if(!o)return a;var s=a.getDate(),i=new Date(a.getTime());return(i.setMonth(a.getMonth()+o+1,0),s>=i.getDate())?i:(a.setFullYear(i.getFullYear(),i.getMonth(),s),a)}function i(e,t){return(0,d.Z)(2,arguments),s(e,12*(0,r.Z)(t))}let D=(e,t,a,D,l=!1,I)=>{let c=new Date(e);if(c.setHours(0,0,0,0),D?.scheduleType==="specific_dates"&&l){let e=new Date;e.setHours(0,0,0,0),c<e&&(c=e)}if(!D||"specific_dates"!==D.scheduleType){if(l)return new Date(c);if(I){let e=new Date(I);e.setHours(0,0,0,0);let r=new Date(e),n=0;for(;r<=c&&n<1e4;){switch(a){case"day":r.setDate(r.getDate()+t);break;case"week":r.setDate(r.getDate()+7*t);break;case"month":r.setMonth(r.getMonth()+t);break;case"year":r.setFullYear(r.getFullYear()+t)}n++}return r}let e=new Date(c);switch(a){case"day":e.setDate(e.getDate()+t);break;case"week":e.setDate(e.getDate()+7*t);break;case"month":e.setMonth(e.getMonth()+t);break;case"year":e.setFullYear(e.getFullYear()+t)}return e}if("week"===a){let e=D.specificDaysOfWeek;if(!e||0===e.length)return o(c,7);let a=c.getDay(),r=[...e].sort((e,t)=>e-t),n=(e,t)=>{let a=-e.getDay(),r=o(e,a);return o(r,t)};if(l){for(let e of r)if(e>=a)return n(c,e);let e=r[0];return n(o(c,7*t),e)}{for(let e of r)if(e>a)return n(c,e);let e=r[0];return n(o(c,7*t),e)}}if("month"===a||"year"===a){let e=D.specificDays;if(!e||0===e.length)return"month"===a?s(c,t):i(c,t);let o=c.getDate(),I=[...e].sort((e,t)=>e-t),p=(e,t)=>{let a=new Date(e.getFullYear(),e.getMonth()+1,0).getDate();return function(e,t){(0,d.Z)(2,arguments);var a=(0,n.Z)(e),o=(0,r.Z)(t);return a.setDate(o),a}(e,Math.min(t,a))};if(l){for(let e of I)if(e>=o)return p(c,e);return p("month"===a?s(c,t):i(c,t),I[0])}for(let e of I)if(e>o)return p(c,e);return p("month"===a?s(c,t):i(c,t),I[0])}return l?c:o(c,t)}}};