"use strict";exports.id=9051,exports.ids=[9051],exports.modules={49051:(e,t,a)=>{a.a(e,async(e,r)=>{try{a.d(t,{U:()=>d});var s=a(94255),n=a(97395),o=e([n]);n=(o.then?(await o)():o)[0];class d{async getDeviceByCategory(e=0){try{let t=`
        SELECT 
          d."ID" as id,
          d."Name" as name,
          d."Serial" as serial,
          d."Description" as description,
          d."Img" as img,
          d."WarrantyDate" as "warrantyDate",
          d."UseDate" as "useDate",
          d."EndDate" as "endDate",
          d."DepartmentID" as "departmentId",
          dep."Name" as "departmentName",
          d."LocationID" as "locationId",
          loc."Name" as "locationName",
          d."DeviceCategoryID" as "deviceCategoryId",
          dc."Name" as "deviceCategoryName",
          CAST(d."Status"::text AS INTEGER) as status,
          lr."lastReportStatus",
          lr."lastReportContent",
          lr."lastReportId",
          d."SupplierID" as "supplierId",
          sup."Name" as "supplierName"
        FROM "Device" d
        INNER JOIN "DeviceCategory" dc ON d."DeviceCategoryID" = dc."ID"
        INNER JOIN "Department" dep ON d."DepartmentID" = dep."ID"
        LEFT JOIN "Location" loc ON d."LocationID" = loc."ID"
        LEFT JOIN "Supplier" sup ON d."SupplierID" = sup."ID"
        LEFT JOIN LATERAL (
          SELECT 
            CAST(dr."Status"::text AS INTEGER) as "lastReportStatus",
            dr."DamageContent" as "lastReportContent",
            dr."ID" as "lastReportId"
          FROM "DamageReport" dr
          WHERE dr."DeviceID" = d."ID"
          ORDER BY dr."ReportDate" DESC, dr."ID" DESC
          LIMIT 1
        ) lr ON TRUE
      `,a=[];e>0&&(t+=' WHERE d."DeviceCategoryID" = $1',a.push(e)),t+=' ORDER BY d."Name"';let r=await n.Z.query(t,a);if(!r.rows||0===r.rows.length)return[];return r.rows.map(e=>{let{img:t,images:a}=this.parseDeviceImg(e.img);return{...e,img:t,images:a,status:e.status?parseInt(e.status):s.Ly.DangSuDung,statusName:this.getStatusName(e.status?parseInt(e.status):s.Ly.DangSuDung)}})}catch(e){throw console.error("DeviceService.getDeviceByCategory error:",e),e}}async getPaginated(e){let{page:t=1,limit:a=10,categoryId:r=0,departmentId:o=0,locationId:d=0,status:D=0,search:i="",sortField:l="Name",sortOrder:u="asc"}=e,p=[],I="WHERE 1=1";r>0&&(p.push(r),I+=` AND d."DeviceCategoryID" = $${p.length}`),o>0&&(p.push(o),I+=` AND d."DepartmentID" = $${p.length}`),d>0&&(p.push(d),I+=` AND d."LocationID" IN (
        WITH RECURSIVE sub_locations AS (
          SELECT "ID" FROM "Location" WHERE "ID" = $${p.length}
          UNION ALL
          SELECT l."ID" FROM "Location" l
          INNER JOIN sub_locations sl ON l."ParentID" = sl."ID"
        )
        SELECT "ID" FROM sub_locations
      )`),D>0&&(p.push(D.toString()),I+=` AND d."Status"::text = $${p.length}`),i&&i.trim()&&(p.push(`%${i.trim().toLowerCase()}%`),I+=` AND (LOWER(d."Name") LIKE $${p.length} OR LOWER(d."Serial") LIKE $${p.length} OR LOWER(d."Description") LIKE $${p.length} OR LOWER(loc."Name") LIKE $${p.length})`);try{let e=`
        SELECT COUNT(*) 
        FROM "Device" d
        LEFT JOIN "DeviceCategory" dc ON d."DeviceCategoryID" = dc."ID"
        LEFT JOIN "Department" dep ON d."DepartmentID" = dep."ID"
        LEFT JOIN "Location" loc ON d."LocationID" = loc."ID"
        ${I}
      `,r=await n.Z.query(e,p),o=parseInt(r.rows[0].count),d=`
        SELECT 
          d."ID" as id,
          d."Name" as name,
          d."Serial" as serial,
          d."Description" as description,
          d."Img" as img,
          d."WarrantyDate" as "warrantyDate",
          d."UseDate" as "useDate",
          d."EndDate" as "endDate",
          d."DepartmentID" as "departmentId",
          dep."Name" as "departmentName",
          d."LocationID" as "locationId",
          loc."Name" as "locationName",
          parent_loc."Name" as "parentLocationName",
          d."DeviceCategoryID" as "deviceCategoryId",
          dc."Name" as "deviceCategoryName",
          CAST(d."Status"::text AS INTEGER) as status,
          lr."lastReportStatus",
          lr."lastReportContent",
          lr."lastReportId",
          d."SupplierID" as "supplierId",
          sup."Name" as "supplierName"
        FROM "Device" d
        INNER JOIN "DeviceCategory" dc ON d."DeviceCategoryID" = dc."ID"
        INNER JOIN "Department" dep ON d."DepartmentID" = dep."ID"
        LEFT JOIN "Location" loc ON d."LocationID" = loc."ID"
        LEFT JOIN "Location" parent_loc ON loc."ParentID" = parent_loc."ID"
        LEFT JOIN "Supplier" sup ON d."SupplierID" = sup."ID"
        LEFT JOIN LATERAL (
          SELECT 
            CAST(dr."Status"::text AS INTEGER) as "lastReportStatus",
            dr."DamageContent" as "lastReportContent",
            dr."ID" as "lastReportId"
          FROM "DamageReport" dr
          WHERE dr."DeviceID" = d."ID"
          ORDER BY dr."ReportDate" DESC, dr."ID" DESC
          LIMIT 1
        ) lr ON TRUE
        ${I}
        ORDER BY ${{name:'d."Name"',serial:'d."Serial"',warrantyDate:'d."WarrantyDate"',useDate:'d."UseDate"',category:'dc."Name"',department:'dep."Name"',status:'d."Status"'}[l]||'d."Name"'} ${"desc"===u?"DESC":"ASC"}
        LIMIT $${p.length+1} OFFSET $${p.length+2}
      `,D=[...p,a,(t-1)*a];return{devices:(await n.Z.query(d,D)).rows.map(e=>{let{img:t,images:a}=this.parseDeviceImg(e.img);return{...e,img:t,images:a,statusName:this.getStatusName(e.status?parseInt(e.status):s.Ly.DangSuDung)}}),total:o}}catch(e){throw console.error("DeviceService.getPaginated error:",e),e}}async getDevicesByIds(e){try{if(!e||0===e.length)return[];let t=e.map((e,t)=>`$${t+1}`).join(","),a=`
        SELECT 
          d."ID" as id,
          d."Name" as name,
          d."Serial" as serial,
          d."Description" as description,
          d."Img" as img,
          d."WarrantyDate" as "warrantyDate",
          d."UseDate" as "useDate",
          d."EndDate" as "endDate",
          d."DepartmentID" as "departmentId",
          dep."Name" as "departmentName",
          d."LocationID" as "locationId",
          loc."Name" as "locationName",
          d."DeviceCategoryID" as "deviceCategoryId",
          dc."Name" as "deviceCategoryName",
          CAST(d."Status"::text AS INTEGER) as status,
          lr."lastReportStatus",
          lr."lastReportContent",
          lr."lastReportId",
          d."SupplierID" as "supplierId",
          sup."Name" as "supplierName"
        FROM "Device" d
        INNER JOIN "DeviceCategory" dc ON d."DeviceCategoryID" = dc."ID"
        INNER JOIN "Department" dep ON d."DepartmentID" = dep."ID"
        LEFT JOIN "Location" loc ON d."LocationID" = loc."ID"
        LEFT JOIN "Supplier" sup ON d."SupplierID" = sup."ID"
        LEFT JOIN LATERAL (
          SELECT 
            CAST(dr."Status"::text AS INTEGER) as "lastReportStatus",
            dr."DamageContent" as "lastReportContent",
            dr."ID" as "lastReportId"
          FROM "DamageReport" dr
          WHERE dr."DeviceID" = d."ID"
          ORDER BY dr."ReportDate" DESC, dr."ID" DESC
          LIMIT 1
        ) lr ON TRUE
        WHERE d."ID" IN (${t})
        ORDER BY d."Name"
      `,r=await n.Z.query(a,e);if(!r.rows||0===r.rows.length)return[];return r.rows.map(e=>{let{img:t,images:a}=this.parseDeviceImg(e.img);return{...e,img:t,images:a,status:e.status?parseInt(e.status):s.Ly.DangSuDung,statusName:this.getStatusName(e.status?parseInt(e.status):s.Ly.DangSuDung)}})}catch(e){throw console.error("DeviceService.getDevicesByIds error:",e),e}}async getDevicesByDepartment(e){try{if(!e||e<=0)return[];let t=`
        SELECT 
          d."ID" as id,
          d."Name" as name,
          d."Serial" as serial,
          d."Description" as description,
          d."Img" as img,
          d."WarrantyDate" as "warrantyDate",
          d."UseDate" as "useDate",
          d."EndDate" as "endDate",
          d."DepartmentID" as "departmentId",
          dep."Name" as "departmentName",
          d."LocationID" as "locationId",
          loc."Name" as "locationName",
          d."DeviceCategoryID" as "deviceCategoryId",
          dc."Name" as "deviceCategoryName",
          CAST(d."Status"::text AS INTEGER) as status,
          lr."lastReportStatus",
          lr."lastReportContent",
          lr."lastReportId",
          d."SupplierID" as "supplierId",
          sup."Name" as "supplierName"
        FROM "Device" d
        INNER JOIN "DeviceCategory" dc ON d."DeviceCategoryID" = dc."ID"
        INNER JOIN "Department" dep ON d."DepartmentID" = dep."ID"
        LEFT JOIN "Location" loc ON d."LocationID" = loc."ID"
        LEFT JOIN "Supplier" sup ON d."SupplierID" = sup."ID"
        LEFT JOIN LATERAL (
          SELECT 
            CAST(dr."Status"::text AS INTEGER) as "lastReportStatus",
            dr."DamageContent" as "lastReportContent",
            dr."ID" as "lastReportId"
          FROM "DamageReport" dr
          WHERE dr."DeviceID" = d."ID"
          ORDER BY dr."ReportDate" DESC, dr."ID" DESC
          LIMIT 1
        ) lr ON TRUE
        WHERE d."DepartmentID" = $1
        ORDER BY d."Name"
      `,a=await n.Z.query(t,[e]);if(!a.rows||0===a.rows.length)return[];return a.rows.map(e=>{let{img:t,images:a}=this.parseDeviceImg(e.img);return{...e,img:t,images:a,status:e.status?parseInt(e.status):s.Ly.DangSuDung,statusName:this.getStatusName(e.status?parseInt(e.status):s.Ly.DangSuDung)}})}catch(e){throw console.error("DeviceService.getDevicesByDepartment error:",e),e}}async getById(e){let t=await n.Z.query('SELECT * FROM "Device" WHERE "ID" = $1',[e]);if(0===t.rows.length)return null;let a=t.rows[0],{img:r,images:o}=this.parseDeviceImg(a.Img);return{id:a.ID,name:a.Name,serial:a.Serial,description:a.Description,img:r,images:o,warrantyDate:a.WarrantyDate,useDate:a.UseDate,endDate:a.EndDate,departmentId:a.DepartmentID,locationId:a.LocationID??void 0,deviceCategoryId:a.DeviceCategoryID,status:a.Status?"string"==typeof a.Status?parseInt(a.Status):a.Status:s.Ly.DangSuDung,supplierId:a.SupplierID??void 0}}async ensureDeviceSequence(e){let t=e||n.Z,a=await t.query('SELECT COALESCE(MAX("ID"), 0) AS max_id FROM "Device"'),r=await t.query('SELECT last_value, is_called FROM "Device_ID_seq"'),s=Number(a.rows[0]?.max_id||0),o=Number(r.rows[0]?.last_value||0);r.rows[0]?.is_called||(o-=1),s>o&&await t.query("SELECT setval(pg_get_serial_sequence('\"Device\"', 'ID'), $1, true)",[s])}async create(e){await this.ensureDeviceSequence();let t=e.locationId&&Number(e.locationId)>0?Number(e.locationId):null;return(await n.Z.query(`INSERT INTO "Device" (
        "Name", "Serial", "Description", "Img", "WarrantyDate", 
        "UseDate", "EndDate", "DepartmentID", "LocationID", "DeviceCategoryID", "Status", "SupplierID"
      )
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)
      RETURNING "ID"`,[e.name,e.serial||null,e.description||null,this.serializeDeviceImages(e),e.warrantyDate||null,e.useDate||null,e.endDate||null,e.departmentId,t,e.deviceCategoryId,(e.status??s.Ly.DangSuDung).toString(),e.supplierId&&e.supplierId>0?e.supplierId:null])).rows[0].ID}async update(e){await this.ensureDeviceSequence();let t=e.locationId&&Number(e.locationId)>0?Number(e.locationId):null;return await n.Z.query(`UPDATE "Device" SET
        "Name" = $1,
        "Serial" = $2,
        "Description" = $3,
        "Img" = $4,
        "WarrantyDate" = $5,
        "UseDate" = $6,
        "EndDate" = $7,
        "DepartmentID" = $8,
        "LocationID" = $9,
        "DeviceCategoryID" = $10,
        "Status" = $11,
        "SupplierID" = $12
      WHERE "ID" = $13`,[e.name,e.serial||null,e.description||null,this.serializeDeviceImages(e),e.warrantyDate||null,e.useDate||null,e.endDate||null,e.departmentId,t,e.deviceCategoryId,(e.status??s.Ly.DangSuDung).toString(),e.supplierId&&e.supplierId>0?e.supplierId:null,e.id]),e.id}async delete(e){return!((await n.Z.query('SELECT "ID" FROM "Event" WHERE "DeviceID" = $1 LIMIT 1',[e])).rows.length>0)&&(await n.Z.query('DELETE FROM "Device" WHERE "ID" = $1',[e]),!0)}async getDamageHistory(e){let t=await n.Z.connect();try{let a=(await t.query('SELECT "Name", "Serial" FROM "Device" WHERE "ID" = $1',[e])).rows[0]||null,r=await t.query(`
        SELECT
          dr."ID" as "id",
          dr."ReportDate" as "reportDate",
          dr."CompletedDate" as "completedDate",
          dr."Status" as "status",
          dr."DamageContent" as "damageContent",
          dr."CreatedAt" as "createdAt"
        FROM "DamageReport" dr
        WHERE dr."DeviceID" = $1
        ORDER BY dr."ReportDate" DESC, dr."ID" DESC
        `,[e]),n=new Map;for(let e of r.rows){let t=e.id??e.ID;if(!t)continue;let a=e.status??e.Status??"",r=parseInt(String(a),10),o=Number.isNaN(r)?s.OD.Pending:r,d=this.toIsoString(e.createdAt??e.reportDate??e.ReportDate??null),D=this.toIsoString(e.completedDate??e.CompletedDate??null);n.set(t,{reportId:t,reportDate:d,completedDate:D,status:o,statusName:this.getDamageReportStatusName(o),eventTypeName:null,eventTypeCode:null,damageContent:e.damageContent??e.DamageContent??null})}let o=await t.query(`
        SELECT
          e."ID" as "id",
          e."Title" as "title",
          e."EventTypeID" as "eventTypeId",
          et."Name" as "eventTypeName",
          et."Code" as "eventTypeCode",
          et."Category" as "eventTypeCategory",
          e."Status" as "status",
          e."EventDate" as "eventDate",
          e."EndDate" as "endDate",
          e."CreatedAt" as "eventCreatedAt",
          e."Description" as "description",
          e."RelatedReportID" as "relatedReportId",
          dr."ReportDate" as "reportDate",
          dr."CompletedDate" as "reportCompletedDate",
          dr."Status" as "reportStatus",
          dr."DamageContent" as "reportDamageContent",
          dr."CreatedAt" as "reportCreatedAt"
        FROM "Event" e
        LEFT JOIN "EventType" et ON e."EventTypeID" = et."ID"
        LEFT JOIN "DamageReport" dr ON e."RelatedReportID" = dr."ID"
        WHERE e."DeviceID" = $1
        ORDER BY COALESCE(dr."ReportDate", e."EventDate", e."CreatedAt") DESC NULLS LAST, e."ID" DESC
        `,[e]),d=[];for(let e of o.rows){let t=this.normalizeEventStatus(e.status??e.Status??s.N3.Completed),a=this.toIsoString(e.eventDate??e.EventDate??null),r=this.toIsoString(e.reportCreatedAt??e.reportDate??e.ReportDate??null)||this.toIsoString(e.eventCreatedAt)||a,o=this.toIsoString(e.reportCompletedDate??e.reportcompleteddate??null)||this.toIsoString(e.endDate??e.EndDate??null)||a,D=null,i=e.reportStatus??e.ReportStatus??null;if(null!=i){let e=parseInt(String(i),10);Number.isNaN(e)||(D=e)}let l={id:e.id??e.ID,title:e.title??e.Title??null,eventTypeName:e.eventTypeName??e.EventTypeName??null,eventTypeCode:e.eventTypeCode??e.EventTypeCode??null,eventTypeCategory:e.eventTypeCategory??e.EventTypeCategory??null,status:t,statusLabel:this.getEventStatusLabel(t),eventDate:a,reportedAt:r,completedAt:o,relatedReportId:e.relatedReportId??e.RelatedReportID??null,reportStatus:D,reportStatusName:null!==D?this.getDamageReportStatusName(D):null,description:e.description??e.Description??null};if(d.push(l),l.relatedReportId){let t=n.get(l.relatedReportId);t&&(l.eventTypeName&&(t.eventTypeName=l.eventTypeName,t.eventTypeCode=l.eventTypeCode??null),!t.completedDate&&o&&(t.completedDate=o),null!==l.reportStatus&&void 0!==l.reportStatus&&(t.status=l.reportStatus,t.statusName=this.getDamageReportStatusName(l.reportStatus)),!t.damageContent&&e.reportDamageContent&&(t.damageContent=e.reportDamageContent))}}let D=[],i=new Set;for(let e of d){if(e.relatedReportId){if(i.has(e.relatedReportId))continue;i.add(e.relatedReportId)}D.push(e)}let l=Array.from(n.values()).filter(e=>!i.has(e.reportId));return{deviceId:e,deviceName:a?.Name||a?.name||null,deviceSerial:a?.Serial||a?.serial||null,totalReports:n.size,totalEvents:D.length,reports:l,events:D}}catch(e){throw console.error("DeviceService.getDamageHistory error:",e),e}finally{t.release()}}getStatusName(e){switch(e){case s.Ly.DangSuDung:return"Đang sử dụng";case s.Ly.DangSuaChua:return"Đang xử l\xfd";case s.Ly.HuHong:return"Lỗi/Ngưng hoạt động";case s.Ly.DaThanhLy:return"Đ\xe3 thanh l\xfd";case s.Ly.CoHuHong:return"Chờ xử l\xfd";default:return"Kh\xf4ng x\xe1c định"}}getDamageReportStatusName(e){switch(e){case s.OD.Pending:return"Chờ xử l\xfd";case s.OD.Assigned:return"Đ\xe3 ph\xe2n c\xf4ng";case s.OD.InProgress:return"Đang xử l\xfd";case s.OD.Completed:return"Ho\xe0n th\xe0nh";case s.OD.Cancelled:return"Đ\xe3 hủy";case s.OD.Rejected:return"Từ chối";default:return"Kh\xf4ng x\xe1c định"}}normalizeEventStatus(e){switch(String(e||"").toLowerCase()){case s.N3.Planned:return s.N3.Planned;case s.N3.InProgress:case"inprogress":case"in-progress":return s.N3.InProgress;case s.N3.Cancelled:return s.N3.Cancelled;case s.N3.Missed:return s.N3.Missed;case s.N3.Completed:default:return s.N3.Completed}}getEventStatusLabel(e){switch(e){case s.N3.Planned:return"Đ\xe3 l\xean kế hoạch";case s.N3.InProgress:return"Đang thực hiện";case s.N3.Cancelled:return"Đ\xe3 hủy";case s.N3.Missed:return"Bỏ lỡ";case s.N3.Completed:default:return"Ho\xe0n th\xe0nh"}}toIsoString(e){if(!e)return null;let t=new Date(e);return Number.isNaN(t.getTime())?null:t.toISOString()}parseDeviceImg(e){if(!e)return{img:"",images:[]};let t=e.trim();if(t.startsWith("["))try{let e=JSON.parse(t);if(Array.isArray(e)&&e.length>0)return{img:e[0],images:e}}catch(e){}return{img:t,images:[t]}}serializeDeviceImages(e){return e.images&&e.images.length>0?JSON.stringify(e.images):e.img||null}}r()}catch(e){r(e)}})}};