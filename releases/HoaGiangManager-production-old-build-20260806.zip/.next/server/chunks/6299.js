exports.id=6299,exports.ids=[6299],exports.modules={97395:(e,t,a)=>{"use strict";a.a(e,async(e,r)=>{try{a.d(t,{I:()=>p,Z:()=>f});var n=a(8678),o=a(16636),s=a.n(o),l=e([n]);n=(l.then?(await l)():l)[0],s().config(),s().config({path:".env.local",override:!0}),n.types.setTypeParser(1082,e=>e);let d=process.env.DATABASE_URL?.includes("localhost")||process.env.DATABASE_URL?.includes("127.0.0.1"),i=new n.Pool({connectionString:process.env.DATABASE_URL,ssl:!d&&{rejectUnauthorized:!1}});i.on("connect",e=>{e.query("SET TIME ZONE 'Asia/Ho_Chi_Minh'")});let f=i,p=async(e,t)=>{Date.now();try{let a=await i.query(e,t);return Date.now(),a}catch(t){throw console.error("Database query error",{text:e,error:t}),t}};r()}catch(e){r(e)}})},36299:(e,t,a)=>{"use strict";a.a(e,async(e,r)=>{try{a.d(t,{Y:()=>l});var n=a(97395),o=e([n]);n=(o.then?(await o)():o)[0];let s=!1;class l{async ensureSchema(){if(s)return;let e=await n.Z.connect();try{await e.query("BEGIN"),await e.query("SELECT pg_advisory_xact_lock(hashtext('weekly_schedule_schema_v2'))"),await e.query(`
        CREATE TABLE IF NOT EXISTS "WeeklySchedule" (
          "ID"            SERIAL PRIMARY KEY,
          "WeekStartDate" DATE NOT NULL,
          "StaffID"       INTEGER NOT NULL,
          "DayOfWeek"     SMALLINT NOT NULL CHECK ("DayOfWeek" BETWEEN 1 AND 7),
          "Content"       TEXT NOT NULL DEFAULT '',
          "Note"          TEXT,
          "CreatedBy"     TEXT,
          "CreatedAt"     TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
          "UpdatedAt"     TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
          CONSTRAINT "uq_weekly_schedule_staff_day"
            UNIQUE ("WeekStartDate", "StaffID", "DayOfWeek")
        )
      `),await e.query(`
        CREATE INDEX IF NOT EXISTS "idx_weekly_schedule_week"
          ON "WeeklySchedule"("WeekStartDate", "StaffID")
      `),await e.query(`
        CREATE TABLE IF NOT EXISTS "WeeklyScheduleStaff" (
          "StaffID"   INTEGER NOT NULL PRIMARY KEY,
          "SortOrder" INTEGER NOT NULL DEFAULT 0,
          "AddedAt"   TIMESTAMP WITH TIME ZONE DEFAULT NOW()
        )
      `),await e.query(`
        CREATE TABLE IF NOT EXISTS "WeeklyScheduleNote" (
          "WeekStartDate"        DATE NOT NULL PRIMARY KEY,
          "Note"                 TEXT,
          "ApprovedImageUrl"     TEXT,
          "ApprovedAt"           TIMESTAMP WITH TIME ZONE,
          "ApprovedBy"           TEXT,
          "CreatorSignatureUrl"  TEXT,
          "CreatorName"          TEXT,
          "CreatorSignedAt"      TIMESTAMP WITH TIME ZONE,
          "UpdatedAt"            TIMESTAMP WITH TIME ZONE DEFAULT NOW()
        )
      `),await e.query(`
        ALTER TABLE "WeeklyScheduleNote" 
          ADD COLUMN IF NOT EXISTS "ApprovedImageUrl" TEXT,
          ADD COLUMN IF NOT EXISTS "ApprovedAt" TIMESTAMP WITH TIME ZONE,
          ADD COLUMN IF NOT EXISTS "ApprovedBy" TEXT,
          ADD COLUMN IF NOT EXISTS "CreatorSignatureUrl" TEXT,
          ADD COLUMN IF NOT EXISTS "CreatorName" TEXT,
          ADD COLUMN IF NOT EXISTS "CreatorSignedAt" TIMESTAMP WITH TIME ZONE
      `),await e.query("COMMIT"),s=!0}catch(t){throw await e.query("ROLLBACK"),t}finally{e.release()}}static getMondayOf(e){let t=new Date("string"!=typeof e||e.includes("T")?e:e+"T00:00:00Z"),a=t.getUTCDay();return t.setUTCDate(t.getUTCDate()+(0===a?-6:1-a)),t.toISOString().slice(0,10)}async getSelectedStaff(){return await this.ensureSchema(),(await n.Z.query(`SELECT
         s."ID"            AS "staffId",
         s."Name"          AS "staffName",
         COALESCE(s."DepartmentID", 0) AS "departmentId",
         COALESCE(d."Name", 'Kh\xf4ng x\xe1c định') AS "departmentName"
       FROM "WeeklyScheduleStaff" wss
       INNER JOIN "Staff" s ON wss."StaffID" = s."ID"
       LEFT JOIN "Department" d ON s."DepartmentID" = d."ID"
       ORDER BY wss."SortOrder", d."Name", s."Name"`)).rows}async getSelectedStaffIds(){return await this.ensureSchema(),(await n.Z.query('SELECT "StaffID" FROM "WeeklyScheduleStaff"')).rows.map(e=>e.StaffID)}async setSelectedStaff(e){await this.ensureSchema();let t=await n.Z.connect();try{await t.query("BEGIN"),await t.query('DELETE FROM "WeeklyScheduleStaff"');for(let a=0;a<e.length;a++)await t.query('INSERT INTO "WeeklyScheduleStaff" ("StaffID", "SortOrder") VALUES ($1, $2) ON CONFLICT ("StaffID") DO UPDATE SET "SortOrder" = $2',[e[a],a]);await t.query("COMMIT")}catch(e){throw await t.query("ROLLBACK"),e}finally{t.release()}}async getWeeklyNote(e){return(await this.getWeeklyMeta(e)).note}async getWeeklyMeta(e){await this.ensureSchema();let t=await n.Z.query('SELECT "Note", "ApprovedImageUrl", "ApprovedAt", "ApprovedBy", "CreatorSignatureUrl", "CreatorName", "CreatorSignedAt" FROM "WeeklyScheduleNote" WHERE "WeekStartDate" = $1',[e]);if(t.rows.length>0){let e=t.rows[0];return{note:e.Note||"",approvedImageUrl:e.ApprovedImageUrl||null,approvedAt:e.ApprovedAt?new Date(e.ApprovedAt).toISOString():null,approvedBy:e.ApprovedBy||null,creatorSignatureUrl:e.CreatorSignatureUrl||null,creatorName:e.CreatorName||null,creatorSignedAt:e.CreatorSignedAt?new Date(e.CreatorSignedAt).toISOString():null}}let a=await n.Z.query(`SELECT "Note", "CreatorSignatureUrl", "CreatorName" 
       FROM "WeeklyScheduleNote" 
       WHERE "WeekStartDate" < $1 
         AND ("Note" IS NOT NULL AND "Note" != '' OR "CreatorSignatureUrl" IS NOT NULL)
       ORDER BY "WeekStartDate" DESC LIMIT 1`,[e]);if(a.rows.length>0){let e=a.rows[0];return{note:e.Note||"",approvedImageUrl:null,approvedAt:null,approvedBy:null,creatorSignatureUrl:e.CreatorSignatureUrl||null,creatorName:e.CreatorName||null,creatorSignedAt:null}}return{note:"",approvedImageUrl:null,approvedAt:null,approvedBy:null,creatorSignatureUrl:null,creatorName:null,creatorSignedAt:null}}async setWeeklyNote(e,t){await this.ensureSchema(),await n.Z.query(`INSERT INTO "WeeklyScheduleNote" ("WeekStartDate", "Note", "UpdatedAt")
       VALUES ($1, $2, NOW())
       ON CONFLICT ("WeekStartDate") DO UPDATE SET "Note" = EXCLUDED."Note", "UpdatedAt" = NOW()`,[e,t])}async setApprovedImage(e,t,a){await this.ensureSchema(),await n.Z.query(`INSERT INTO "WeeklyScheduleNote" ("WeekStartDate", "ApprovedImageUrl", "ApprovedAt", "ApprovedBy", "UpdatedAt")
       VALUES ($1, $2, $3, $4, NOW())
       ON CONFLICT ("WeekStartDate") DO UPDATE SET
         "ApprovedImageUrl" = EXCLUDED."ApprovedImageUrl",
         "ApprovedAt" = EXCLUDED."ApprovedAt",
         "ApprovedBy" = EXCLUDED."ApprovedBy",
         "UpdatedAt" = NOW()`,[e,t||null,t?new Date:null,t&&a||null])}async setCreatorSignature(e,t,a){await this.ensureSchema(),await n.Z.query(`INSERT INTO "WeeklyScheduleNote" ("WeekStartDate", "CreatorSignatureUrl", "CreatorName", "CreatorSignedAt", "UpdatedAt")
       VALUES ($1, $2, $3, $4, NOW())
       ON CONFLICT ("WeekStartDate") DO UPDATE SET
         "CreatorSignatureUrl" = EXCLUDED."CreatorSignatureUrl",
         "CreatorName" = EXCLUDED."CreatorName",
         "CreatorSignedAt" = EXCLUDED."CreatorSignedAt",
         "UpdatedAt" = NOW()`,[e,t||null,a||null,t?new Date:null])}async getWeeklySchedule(e,t=0){await this.ensureSchema();let a="",r=[];t>0&&(r.push(t),a=`AND s."DepartmentID" = $${r.length}`);let o=await n.Z.query(`SELECT
         s."ID"            AS "staffId",
         s."Name"          AS "staffName",
         COALESCE(s."DepartmentID", 0) AS "departmentId",
         COALESCE(d."Name", 'Kh\xf4ng x\xe1c định') AS "departmentName"
       FROM "WeeklyScheduleStaff" wss
       INNER JOIN "Staff" s ON wss."StaffID" = s."ID"
       LEFT JOIN "Department" d ON s."DepartmentID" = d."ID"
       WHERE 1=1 ${a}
       ORDER BY wss."SortOrder", d."Name", s."Name"`,r);if(0===o.rows.length)return[];let s=o.rows.map(e=>e.staffId),l=await n.Z.query(`SELECT
         ws."ID"            AS id,
         ws."WeekStartDate" AS "weekStartDate",
         ws."StaffID"       AS "staffId",
         ws."DayOfWeek"     AS "dayOfWeek",
         ws."Content"       AS content,
         ws."Note"          AS note
       FROM "WeeklySchedule" ws
       WHERE ws."WeekStartDate" = $1
         AND ws."StaffID" = ANY($2::int[])`,[e,s]),d={};for(let e of l.rows)d[e.staffId]||(d[e.staffId]={}),d[e.staffId][e.dayOfWeek]={id:e.id,weekStartDate:e.weekStartDate,staffId:e.staffId,dayOfWeek:e.dayOfWeek,content:e.content,note:e.note};let i={};for(let e of o.rows)i[e.departmentId]||(i[e.departmentId]={departmentId:e.departmentId,departmentName:e.departmentName,staff:[]}),i[e.departmentId].staff.push({staffId:e.staffId,staffName:e.staffName,departmentId:e.departmentId,departmentName:e.departmentName,days:d[e.staffId]||{}});return Object.values(i)}async upsertBatch(e,t){if(await this.ensureSchema(),0===e.length)return;let a=await n.Z.connect();try{for(let r of(await a.query("BEGIN"),e))await a.query(`INSERT INTO "WeeklySchedule"
             ("WeekStartDate", "StaffID", "DayOfWeek", "Content", "Note", "CreatedBy", "UpdatedAt")
           VALUES ($1, $2, $3, $4, $5, $6, NOW())
           ON CONFLICT ("WeekStartDate", "StaffID", "DayOfWeek")
           DO UPDATE SET
             "Content"   = EXCLUDED."Content",
             "Note"      = EXCLUDED."Note",
             "UpdatedAt" = NOW()`,[r.weekStartDate,r.staffId,r.dayOfWeek,r.content,r.note??null,t??null]);await a.query("COMMIT")}catch(e){throw await a.query("ROLLBACK"),e}finally{a.release()}}async getForExport(e,t){await this.ensureSchema();let a="",r=[];t&&t.length>0&&(r.push(t),a=`AND s."DepartmentID" = ANY($${r.length}::int[])`);let o=await n.Z.query(`SELECT
         s."ID"            AS "staffId",
         s."Name"          AS "staffName",
         COALESCE(s."DepartmentID", 0) AS "departmentId",
         COALESCE(d."Name", 'Kh\xf4ng x\xe1c định') AS "departmentName"
       FROM "WeeklyScheduleStaff" wss
       INNER JOIN "Staff" s ON wss."StaffID" = s."ID"
       LEFT JOIN "Department" d ON s."DepartmentID" = d."ID"
       WHERE 1=1 ${a}
       ORDER BY wss."SortOrder", d."Name", s."Name"`,r);if(0===o.rows.length)return[];let s=o.rows.map(e=>e.staffId),l=await n.Z.query(`SELECT
         ws."StaffID"   AS "staffId",
         ws."DayOfWeek" AS "dayOfWeek",
         ws."Content"   AS content,
         ws."Note"      AS note
       FROM "WeeklySchedule" ws
       WHERE ws."WeekStartDate" = $1
         AND ws."StaffID" = ANY($2::int[])`,[e,s]),d={};for(let t of l.rows)d[t.staffId]||(d[t.staffId]={}),d[t.staffId][t.dayOfWeek]={weekStartDate:e,staffId:t.staffId,dayOfWeek:t.dayOfWeek,content:t.content,note:t.note};let i={};for(let e of o.rows)i[e.departmentId]||(i[e.departmentId]={departmentId:e.departmentId,departmentName:e.departmentName,staff:[]}),i[e.departmentId].staff.push({staffId:e.staffId,staffName:e.staffName,departmentId:e.departmentId,departmentName:e.departmentName,days:d[e.staffId]||{}});return Object.values(i)}}r()}catch(e){r(e)}})},16636:(e,t,a)=>{let r=a(92048),n=a(55315),o=a(19801),s=a(84770),l=a(71564).version,d=/(?:^|^)\s*(?:export\s+)?([\w.-]+)(?:\s*=\s*?|:\s+?)(\s*'(?:\\'|[^'])*'|\s*"(?:\\"|[^"])*"|\s*`(?:\\`|[^`])*`|[^#\r\n]+)?\s*(?:#.*)?(?:$|$)/mg;function i(e){console.log(`[dotenv@${l}][DEBUG] ${e}`)}function f(e){console.log(`[dotenv@${l}] ${e}`)}function p(e){return e&&e.DOTENV_KEY&&e.DOTENV_KEY.length>0?e.DOTENV_KEY:process.env.DOTENV_KEY&&process.env.DOTENV_KEY.length>0?process.env.DOTENV_KEY:""}function c(e){let t=null;if(e&&e.path&&e.path.length>0){if(Array.isArray(e.path))for(let a of e.path)r.existsSync(a)&&(t=a.endsWith(".vault")?a:`${a}.vault`);else t=e.path.endsWith(".vault")?e.path:`${e.path}.vault`}else t=n.resolve(process.cwd(),".env.vault");return r.existsSync(t)?t:null}function E(e){return"~"===e[0]?n.join(o.homedir(),e.slice(1)):e}let u={configDotenv:function(e){let t;let a=n.resolve(process.cwd(),".env"),o="utf8",s=!!(e&&e.debug),l=!e||!("quiet"in e)||e.quiet;e&&e.encoding?o=e.encoding:s&&i("No encoding is specified. UTF-8 is used by default");let d=[a];if(e&&e.path){if(Array.isArray(e.path))for(let t of(d=[],e.path))d.push(E(t));else d=[E(e.path)]}let p={};for(let a of d)try{let t=u.parse(r.readFileSync(a,{encoding:o}));u.populate(p,t,e)}catch(e){s&&i(`Failed to load ${a} ${e.message}`),t=e}let c=process.env;if(e&&null!=e.processEnv&&(c=e.processEnv),u.populate(c,p,e),s||!l){let e=Object.keys(p).length,a=[];for(let e of d)try{let t=n.relative(process.cwd(),e);a.push(t)}catch(a){s&&i(`Failed to load ${e} ${a.message}`),t=a}f(`injecting env (${e}) from ${a.join(",")}`)}return t?{parsed:p,error:t}:{parsed:p}},_configVault:function(e){let t=!!(e&&e.debug),a=!e||!("quiet"in e)||e.quiet;(t||!a)&&f("Loading env from encrypted .env.vault");let r=u._parseVault(e),n=process.env;return e&&null!=e.processEnv&&(n=e.processEnv),u.populate(n,r,e),{parsed:r}},_parseVault:function(e){let t;let a=c(e=e||{});e.path=a;let r=u.configDotenv(e);if(!r.parsed){let e=Error(`MISSING_DATA: Cannot parse ${a} for an unknown reason`);throw e.code="MISSING_DATA",e}let n=p(e).split(","),o=n.length;for(let e=0;e<o;e++)try{let a=n[e].trim(),o=function(e,t){let a;try{a=new URL(t)}catch(e){if("ERR_INVALID_URL"===e.code){let e=Error("INVALID_DOTENV_KEY: Wrong format. Must be in valid uri format like dotenv://:key_1234@dotenvx.com/vault/.env.vault?environment=development");throw e.code="INVALID_DOTENV_KEY",e}throw e}let r=a.password;if(!r){let e=Error("INVALID_DOTENV_KEY: Missing key part");throw e.code="INVALID_DOTENV_KEY",e}let n=a.searchParams.get("environment");if(!n){let e=Error("INVALID_DOTENV_KEY: Missing environment part");throw e.code="INVALID_DOTENV_KEY",e}let o=`DOTENV_VAULT_${n.toUpperCase()}`,s=e.parsed[o];if(!s){let e=Error(`NOT_FOUND_DOTENV_ENVIRONMENT: Cannot locate environment ${o} in your .env.vault file.`);throw e.code="NOT_FOUND_DOTENV_ENVIRONMENT",e}return{ciphertext:s,key:r}}(r,a);t=u.decrypt(o.ciphertext,o.key);break}catch(t){if(e+1>=o)throw t}return u.parse(t)},config:function(e){if(0===p(e).length)return u.configDotenv(e);let t=c(e);if(!t){var a;return a=`You set DOTENV_KEY but you are missing a .env.vault file at ${t}. Did you forget to build it?`,console.log(`[dotenv@${l}][WARN] ${a}`),u.configDotenv(e)}return u._configVault(e)},decrypt:function(e,t){let a=Buffer.from(t.slice(-64),"hex"),r=Buffer.from(e,"base64"),n=r.subarray(0,12),o=r.subarray(-16);r=r.subarray(12,-16);try{let e=s.createDecipheriv("aes-256-gcm",a,n);return e.setAuthTag(o),`${e.update(r)}${e.final()}`}catch(r){let e=r instanceof RangeError,t="Invalid key length"===r.message,a="Unsupported state or unable to authenticate data"===r.message;if(e||t){let e=Error("INVALID_DOTENV_KEY: It must be 64 characters long (or more)");throw e.code="INVALID_DOTENV_KEY",e}if(a){let e=Error("DECRYPTION_FAILED: Please check your DOTENV_KEY");throw e.code="DECRYPTION_FAILED",e}throw r}},parse:function(e){let t;let a={},r=e.toString();for(r=r.replace(/\r\n?/mg,"\n");null!=(t=d.exec(r));){let e=t[1],r=t[2]||"",n=(r=r.trim())[0];r=r.replace(/^(['"`])([\s\S]*)\1$/mg,"$2"),'"'===n&&(r=(r=r.replace(/\\n/g,"\n")).replace(/\\r/g,"\r")),a[e]=r}return a},populate:function(e,t,a={}){let r=!!(a&&a.debug),n=!!(a&&a.override);if("object"!=typeof t){let e=Error("OBJECT_REQUIRED: Please check the processEnv argument being passed to populate");throw e.code="OBJECT_REQUIRED",e}for(let a of Object.keys(t))Object.prototype.hasOwnProperty.call(e,a)?(!0===n&&(e[a]=t[a]),r&&(!0===n?i(`"${a}" is already defined and WAS overwritten`):i(`"${a}" is already defined and was NOT overwritten`))):e[a]=t[a]}};e.exports.configDotenv=u.configDotenv,e.exports._configVault=u._configVault,e.exports._parseVault=u._parseVault,e.exports.config=u.config,e.exports.decrypt=u.decrypt,e.exports.parse=u.parse,e.exports.populate=u.populate,e.exports=u},71564:e=>{"use strict";e.exports=JSON.parse('{"name":"dotenv","version":"16.6.1","description":"Loads environment variables from .env file","main":"lib/main.js","types":"lib/main.d.ts","exports":{".":{"types":"./lib/main.d.ts","require":"./lib/main.js","default":"./lib/main.js"},"./config":"./config.js","./config.js":"./config.js","./lib/env-options":"./lib/env-options.js","./lib/env-options.js":"./lib/env-options.js","./lib/cli-options":"./lib/cli-options.js","./lib/cli-options.js":"./lib/cli-options.js","./package.json":"./package.json"},"scripts":{"dts-check":"tsc --project tests/types/tsconfig.json","lint":"standard","pretest":"npm run lint && npm run dts-check","test":"tap run --allow-empty-coverage --disable-coverage --timeout=60000","test:coverage":"tap run --show-full-coverage --timeout=60000 --coverage-report=text --coverage-report=lcov","prerelease":"npm test","release":"standard-version"},"repository":{"type":"git","url":"git://github.com/motdotla/dotenv.git"},"homepage":"https://github.com/motdotla/dotenv#readme","funding":"https://dotenvx.com","keywords":["dotenv","env",".env","environment","variables","config","settings"],"readmeFilename":"README.md","license":"BSD-2-Clause","devDependencies":{"@types/node":"^18.11.3","decache":"^4.6.2","sinon":"^14.0.1","standard":"^17.0.0","standard-version":"^9.5.0","tap":"^19.2.0","typescript":"^4.8.4"},"engines":{"node":">=12"},"browser":{"fs":false}}')}};