"use strict";exports.id=9854,exports.ids=[9854],exports.modules={9854:(e,a,r)=>{r.a(e,async(e,t)=>{try{r.r(a),r.d(a,{StaffService:()=>d});var s=r(97395),l=r(62579),n=e([s,l]);[s,l]=n.then?(await n)():n;class d{async getStaffByDepartment(e=0){let a=`
      SELECT 
        s."ID" as id,
        s."Name" as name,
        s."Gender" as gender,
        s."Birthday" as birthday,
        s."DepartmentID" as "departmentId",
        s."UserId" as "userId",
        u."Email" as email,
        d."Name" as "departmentName"
      FROM "Staff" s
      LEFT JOIN "Department" d ON s."DepartmentID" = d."ID"
      LEFT JOIN "AspNetUsers" u ON s."UserId" = u."Id"
    `,r=[];return e>0&&(a+=' WHERE s."DepartmentID" = $1',r.push(e)),a+=' ORDER BY s."Name"',(await s.Z.query(a,r)).rows}async getById(e){let a=await s.Z.query(`SELECT 
        s."ID" as id,
        s."Name" as name,
        s."Gender" as gender,
        s."Birthday" as birthday,
        s."DepartmentID" as "departmentId",
        s."UserId" as "userId",
        u."Email" as email
      FROM "Staff" s
      LEFT JOIN "AspNetUsers" u ON s."UserId" = u."Id"
      WHERE s."ID" = $1`,[e]);if(0===a.rows.length)return null;let r=a.rows[0];return{id:r.id,name:r.name,gender:r.gender,birthday:r.birthday,departmentId:r.departmentId,userId:r.userId}}async getByUserId(e){let a=await s.Z.query(`SELECT 
        "ID" as id,
        "Name" as name,
        "Gender" as gender,
        "Birthday" as birthday,
        "DepartmentID" as "departmentId",
        "UserId" as "userId"
      FROM "Staff" WHERE "UserId" = $1`,[e]);if(0===a.rows.length)return null;let r=a.rows[0];return{id:r.id,name:r.name,email:r.email,gender:r.gender,birthday:r.birthday,departmentId:r.departmentId,userId:r.userId}}async create(e){let a=new l.K,r=null;if(e.email&&e.email.trim()){let t=await s.Z.query('SELECT "Id" FROM "AspNetUsers" WHERE "NormalizedEmail" = $1',[e.email.trim().toUpperCase()]);if(t.rows.length>0){if(r=t.rows[0].Id,(await s.Z.query('SELECT "ID" FROM "Staff" WHERE "UserId" = $1',[r])).rows.length>0)throw Error(`Email ${e.email} đ\xe3 được li\xean kết với nh\xe2n vi\xean kh\xe1c`);let a=await s.Z.query('SELECT "PasswordHash" FROM "AspNetUsers" WHERE "Id" = $1',[r]),n=a.rows[0]?.PasswordHash||null;n&&/^\$2[aby]\$/.test(n)?await s.Z.query('UPDATE "AspNetUsers" SET "FullName" = $1 WHERE "Id" = $2',[e.name,r]):await new l.K().update({id:r,password:"Staff@123",fullName:e.name});let d=await s.Z.query('SELECT "Id" FROM "AspNetRoles" WHERE "Name" = $1',["User"]);d.rows.length>0&&await s.Z.query('INSERT INTO "AspNetUserRoles" ("UserId", "RoleId") VALUES ($1, $2) ON CONFLICT DO NOTHING',[r,d.rows[0].Id]),console.log(`Linked existing user account for staff: ${e.email} (userId: ${r})`)}else r=await a.create({email:e.email.trim(),password:"Staff@123",fullName:e.name,roles:["User"]}),console.log(`Created user account for staff: ${e.email} (userId: ${r})`)}let t=(await s.Z.query('SELECT COALESCE(MAX("ID"), 0) + 1 as next_id FROM "Staff"')).rows[0].next_id;return await s.Z.query(`INSERT INTO "Staff" ("ID", "Name", "Gender", "Birthday", "DepartmentID", "UserId")
       VALUES ($1, $2, $3, $4, $5, $6)`,[t,e.name,void 0===e.gender||null===e.gender?null:e.gender,e.birthday??null,e.departmentId??null,r]),t}async update(e){let a=new l.K,r=await this.getById(e.id),t=r?.userId||null;if(t&&e.email&&e.email.trim()){let a=e.email.trim(),r=a.toUpperCase();if((await s.Z.query('SELECT "Id" FROM "AspNetUsers" WHERE "NormalizedEmail" = $1 AND "Id" <> $2',[r,t])).rows.length>0)throw Error(`Email ${a} đ\xe3 được sử dụng bởi t\xe0i khoản kh\xe1c`);await new l.K().update({id:t,email:a,fullName:e.name})}if(!r?.userId&&e.email&&e.email.trim()){let r=await s.Z.query('SELECT "Id" FROM "AspNetUsers" WHERE "NormalizedEmail" = $1',[e.email.trim().toUpperCase()]);if(r.rows.length>0){if(t=r.rows[0].Id,(await s.Z.query('SELECT "ID" FROM "Staff" WHERE "UserId" = $1 AND "ID" != $2',[t,e.id])).rows.length>0)throw Error(`Email ${e.email} đ\xe3 được li\xean kết với nh\xe2n vi\xean kh\xe1c`);let l=await s.Z.query('SELECT "PasswordHash" FROM "AspNetUsers" WHERE "Id" = $1',[t]);l.rows[0]?.PasswordHash?await s.Z.query('UPDATE "AspNetUsers" SET "FullName" = $1 WHERE "Id" = $2',[e.name,t]):await a.update({id:t,password:"Staff@123",fullName:e.name});let n=await s.Z.query('SELECT "Id" FROM "AspNetRoles" WHERE "Name" = $1',["User"]);n.rows.length>0&&await s.Z.query('INSERT INTO "AspNetUserRoles" ("UserId", "RoleId") VALUES ($1, $2) ON CONFLICT DO NOTHING',[t,n.rows[0].Id]),console.log(`Linked existing user account for staff: ${e.email} (userId: ${t})`)}else t=await a.create({email:e.email.trim(),password:"Staff@123",fullName:e.name,roles:["User"]}),console.log(`Created user account for staff: ${e.email} (userId: ${t})`)}return await s.Z.query(`UPDATE "Staff" 
       SET "Name" = $1, "Gender" = $2, "Birthday" = $3, "DepartmentID" = $4, "UserId" = $5
       WHERE "ID" = $6`,[e.name,void 0===e.gender||null===e.gender?null:e.gender,e.birthday??null,e.departmentId??null,t,e.id]),t&&await s.Z.query('UPDATE "AspNetUsers" SET "FullName" = $1 WHERE "Id" = $2',[e.name,t]),e.id}async syncNamesWithUsers(){let e=[],a=0;try{for(let r of(await s.Z.query(`
        SELECT 
          s."ID" as staffId,
          s."Name" as staffName,
          s."UserId" as userId,
          u."FullName" as userName
        FROM "Staff" s
        INNER JOIN "AspNetUsers" u ON s."UserId" = u."Id"
        WHERE s."Name" != COALESCE(u."FullName", '')
      `)).rows)try{await s.Z.query('UPDATE "AspNetUsers" SET "FullName" = $1 WHERE "Id" = $2',[r.staffName,r.userId]),a++}catch(a){e.push(`Staff ID ${r.staffId}: ${a.message}`)}}catch(a){e.push(`Sync error: ${a.message}`)}return{synced:a,errors:e}}async getNameMismatches(){return(await s.Z.query(`
      SELECT 
        s."ID" as "staffId",
        s."Name" as "staffName",
        s."UserId" as "userId",
        u."FullName" as "userName"
      FROM "Staff" s
      INNER JOIN "AspNetUsers" u ON s."UserId" = u."Id"
      WHERE s."Name" != COALESCE(u."FullName", '')
      ORDER BY s."ID"
    `)).rows}async getStaffUsage(e,a,r){let[t,s,l]=await Promise.all([e.query('SELECT COUNT(*)::int AS count FROM "Event" WHERE "StaffID" = $1',[a]),e.query('SELECT COUNT(*)::int AS count FROM "DamageReport" WHERE "HandlerID" = $1',[a]),e.query('SELECT COUNT(*)::int AS count FROM "DamageReport" WHERE "ReporterID" = $1',[a])]),n={events:t.rows[0]?.count||0,damageReportsHandled:s.rows[0]?.count||0,damageReportsReported:l.rows[0]?.count||0,reportsCreatedBy:0,reportsUpdatedBy:0,historyChanges:0};if(r){let[a,t,s]=await Promise.all([e.query('SELECT COUNT(*)::int AS count FROM "DamageReport" WHERE "CreatedBy" = $1',[r]),e.query('SELECT COUNT(*)::int AS count FROM "DamageReport" WHERE "UpdatedBy" = $1',[r]),e.query('SELECT COUNT(*)::int AS count FROM "DamageReportHistory" WHERE "ChangedBy" = $1',[r])]);n.reportsCreatedBy=a.rows[0]?.count||0,n.reportsUpdatedBy=t.rows[0]?.count||0,n.historyChanges=s.rows[0]?.count||0}return n}async delete(e,a){let r=await s.Z.connect(),t=!1;try{let s=await r.query('SELECT "UserId" FROM "Staff" WHERE "ID" = $1',[e]);if(0===s.rows.length)return{success:!1,message:"Nh\xe2n vi\xean kh\xf4ng tồn tại"};let l=s.rows[0]?.UserId||s.rows[0]?.userid||null,n=await this.getStaffUsage(r,e,l);if((n.events>0||n.damageReportsHandled>0||n.damageReportsReported>0||n.reportsCreatedBy>0||n.reportsUpdatedBy>0||n.historyChanges>0)&&!a?.force)return{success:!1,requiresConfirmation:!0,usage:n,message:"Nh\xe2n vi\xean n\xe0y đ\xe3 được sử dụng, nếu x\xf3a sẽ l\xe0m ảnh hưởng đến dữ liệu."};return await r.query("BEGIN"),t=!0,n.events>0&&await r.query('UPDATE "Event" SET "StaffID" = NULL WHERE "StaffID" = $1',[e]),n.damageReportsHandled>0&&await r.query('UPDATE "DamageReport" SET "HandlerID" = NULL WHERE "HandlerID" = $1',[e]),n.damageReportsReported>0&&await r.query('UPDATE "DamageReport" SET "ReporterID" = NULL WHERE "ReporterID" = $1',[e]),l&&(n.reportsCreatedBy>0&&await r.query('UPDATE "DamageReport" SET "CreatedBy" = NULL WHERE "CreatedBy" = $1',[l]),n.reportsUpdatedBy>0&&await r.query('UPDATE "DamageReport" SET "UpdatedBy" = NULL WHERE "UpdatedBy" = $1',[l]),n.historyChanges>0&&await r.query('UPDATE "DamageReportHistory" SET "ChangedBy" = NULL WHERE "ChangedBy" = $1',[l])),await r.query('DELETE FROM "Staff" WHERE "ID" = $1',[e]),l&&(await r.query('DELETE FROM "AspNetUserRoles" WHERE "UserId" = $1',[l]),await r.query('DELETE FROM "AspNetUsers" WHERE "Id" = $1',[l])),await r.query("COMMIT"),t=!1,{success:!0,usage:n}}catch(e){throw t&&await r.query("ROLLBACK").catch(()=>void 0),e}finally{r.release()}}}t()}catch(e){t(e)}})},62579:(e,a,r)=>{r.a(e,async(e,t)=>{try{r.d(a,{K:()=>o});var s=r(97395),l=r(42023),n=r.n(l),d=r(1013),i=e([s]);s=(i.then?(await i)():i)[0];class o{mapLockState(e,a){let r=!!e,t=null,s=!1;if(a){let e=new Date(a);Number.isNaN(e.getTime())||(t=e,s=r&&e.getTime()>Date.now())}return{lockoutEnabled:r,lockoutEnd:t,isLocked:s}}async hasAnotherAdmin(e,a){let r=a||s.Z;return(await r.query(`SELECT 1
       FROM "AspNetUsers" u
       INNER JOIN "AspNetUserRoles" ur ON u."Id" = ur."UserId"
       INNER JOIN "AspNetRoles" r ON ur."RoleId" = r."Id"
       WHERE r."Name" = 'Admin' AND u."Id" <> $1
       LIMIT 1`,[e])).rows.length>0}async getAll(){return(await s.Z.query(`SELECT 
        u."Id" as id,
        u."UserName" as "userName",
        u."Email" as email,
        u."FullName" as "fullName",
        u."CreatedDate" as "createdDate",
        u."LockoutEnabled" as "lockoutEnabled",
        u."LockoutEnd" as "lockoutEnd",
        ARRAY_AGG(r."Name") as roles
      FROM "AspNetUsers" u
      LEFT JOIN "AspNetUserRoles" ur ON u."Id" = ur."UserId"
      LEFT JOIN "AspNetRoles" r ON ur."RoleId" = r."Id"
      GROUP BY u."Id", u."UserName", u."Email", u."FullName", u."CreatedDate"
      ORDER BY u."CreatedDate" DESC`)).rows.map(e=>{let a=this.mapLockState(e.lockoutEnabled,e.lockoutEnd);return{id:e.id,userName:e.userName,email:e.email,fullName:e.fullName,createdDate:e.createdDate,roles:e.roles.filter(e=>null!==e)||[],lockoutEnabled:a.lockoutEnabled,lockoutEnd:a.lockoutEnd,isLocked:a.isLocked}})}async getById(e){let a=await s.Z.query(`SELECT 
        u."Id" as id,
        u."UserName" as "userName",
        u."Email" as email,
        u."FullName" as "fullName",
        u."CreatedDate" as "createdDate",
        u."LockoutEnabled" as "lockoutEnabled",
        u."LockoutEnd" as "lockoutEnd",
        ARRAY_AGG(r."Name") as roles
      FROM "AspNetUsers" u
      LEFT JOIN "AspNetUserRoles" ur ON u."Id" = ur."UserId"
      LEFT JOIN "AspNetRoles" r ON ur."RoleId" = r."Id"
      WHERE u."Id" = $1
      GROUP BY u."Id", u."UserName", u."Email", u."FullName", u."CreatedDate"`,[e]);if(0===a.rows.length)return null;let r=a.rows[0],t=this.mapLockState(r.lockoutEnabled,r.lockoutEnd);return{id:r.id,userName:r.userName,email:r.email,fullName:r.fullName,createdDate:r.createdDate,roles:r.roles.filter(e=>null!==e)||[],lockoutEnabled:t.lockoutEnabled,lockoutEnd:t.lockoutEnd,isLocked:t.isLocked}}async create(e){let{v4:a}=r(50267),t=a(),l=e.email.toUpperCase(),i=e.email.toUpperCase(),o=await n().hash(e.password,10);if(await s.Z.query(`INSERT INTO "AspNetUsers" (
        "Id", "UserName", "NormalizedUserName", "Email", "NormalizedEmail",
        "EmailConfirmed", "PasswordHash", "SecurityStamp", "ConcurrencyStamp",
        "FullName", "CreatedDate"
      )
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)`,[t,e.email,i,e.email,l,!1,o,a(),a(),e.fullName||null,(0,d.ud)()]),e.roles&&e.roles.length>0)for(let a of e.roles){let e=await s.Z.query('SELECT "Id" FROM "AspNetRoles" WHERE "Name" = $1',[a]);e.rows.length>0&&await s.Z.query('INSERT INTO "AspNetUserRoles" ("UserId", "RoleId") VALUES ($1, $2) ON CONFLICT DO NOTHING',[t,e.rows[0].Id])}else{let e=await s.Z.query('SELECT "Id" FROM "AspNetRoles" WHERE "Name" = $1',["User"]);e.rows.length>0&&await s.Z.query('INSERT INTO "AspNetUserRoles" ("UserId", "RoleId") VALUES ($1, $2) ON CONFLICT DO NOTHING',[t,e.rows[0].Id])}return t}async update(e){let a=[],r=[],t=1;if(e.email&&(a.push(`"Email" = $${t}`),a.push(`"NormalizedEmail" = $${t+1}`),a.push(`"UserName" = $${t}`),a.push(`"NormalizedUserName" = $${t+1}`),r.push(e.email,e.email.toUpperCase()),t+=2),void 0!==e.fullName&&(a.push(`"FullName" = $${t}`),r.push(e.fullName),t++),e.password){let s=await n().hash(e.password,10);a.push(`"PasswordHash" = $${t}`),r.push(s),t++}if(a.length>0&&(r.push(e.id),await s.Z.query(`UPDATE "AspNetUsers" SET ${a.join(", ")} WHERE "Id" = $${t}`,r)),void 0!==e.roles&&(await s.Z.query('DELETE FROM "AspNetUserRoles" WHERE "UserId" = $1',[e.id]),e.roles.length>0))for(let a of e.roles){let r=await s.Z.query('SELECT "Id" FROM "AspNetRoles" WHERE "Name" = $1',[a]);r.rows.length>0&&await s.Z.query('INSERT INTO "AspNetUserRoles" ("UserId", "RoleId") VALUES ($1, $2) ON CONFLICT DO NOTHING',[e.id,r.rows[0].Id])}}async delete(e){let a=await this.getById(e);if(a?.roles?.includes("SuperAdmin"))throw Error("Kh\xf4ng thể x\xf3a user c\xf3 quyền SuperAdmin");if(!await this.hasAnotherAdmin(e))throw Error("Kh\xf4ng thể x\xf3a user cuối c\xf9ng c\xf3 quyền Admin");return await s.Z.query('DELETE FROM "AspNetUsers" WHERE "Id" = $1',[e]),!0}async getAllRoles(){return(await s.Z.query('SELECT "Id" as id, "Name" as name FROM "AspNetRoles" ORDER BY "Name"')).rows}async setLockStatus(e,a){let r=await this.getById(e);if(r?.roles?.includes("SuperAdmin"))throw Error("Kh\xf4ng thể kh\xf3a/mở kh\xf3a t\xe0i khoản SuperAdmin");if(a&&!await this.hasAnotherAdmin(e))throw Error("Kh\xf4ng thể kh\xf3a t\xe0i khoản Admin cuối c\xf9ng");let t=a?new Date("2099-12-31T23:59:59Z"):null;await s.Z.query(`UPDATE "AspNetUsers"
       SET "LockoutEnabled" = $2,
           "LockoutEnd" = $3,
           "AccessFailedCount" = CASE WHEN $2 THEN "AccessFailedCount" ELSE 0 END
       WHERE "Id" = $1`,[e,a,t])}}t()}catch(e){t(e)}})},50267:(e,a,r)=>{let t,s;r.r(a),r.d(a,{NIL:()=>R,parse:()=>E,stringify:()=>n.Z,v1:()=>o,v3:()=>c,v4:()=>f.Z,v5:()=>p,validate:()=>u.Z,version:()=>y});var l=r(6649),n=r(16099);let d=0,i=0,o=function(e,a,r){let o=a&&r||0,u=a||Array(16),E=(e=e||{}).node||t,m=void 0!==e.clockseq?e.clockseq:s;if(null==E||null==m){let a=e.random||(e.rng||l.Z)();null==E&&(E=t=[1|a[0],a[1],a[2],a[3],a[4],a[5]]),null==m&&(m=s=(a[6]<<8|a[7])&16383)}let N=void 0!==e.msecs?e.msecs:Date.now(),I=void 0!==e.nsecs?e.nsecs:i+1,c=N-d+(I-i)/1e4;if(c<0&&void 0===e.clockseq&&(m=m+1&16383),(c<0||N>d)&&void 0===e.nsecs&&(I=0),I>=1e4)throw Error("uuid.v1(): Can't create more than 10M uuids/sec");d=N,i=I,s=m;let f=((268435455&(N+=122192928e5))*1e4+I)%4294967296;u[o++]=f>>>24&255,u[o++]=f>>>16&255,u[o++]=f>>>8&255,u[o++]=255&f;let p=N/4294967296*1e4&268435455;u[o++]=p>>>8&255,u[o++]=255&p,u[o++]=p>>>24&15|16,u[o++]=p>>>16&255,u[o++]=m>>>8|128,u[o++]=255&m;for(let e=0;e<6;++e)u[o+e]=E[e];return a||(0,n.S)(u)};var u=r(30900);let E=function(e){let a;if(!(0,u.Z)(e))throw TypeError("Invalid UUID");let r=new Uint8Array(16);return r[0]=(a=parseInt(e.slice(0,8),16))>>>24,r[1]=a>>>16&255,r[2]=a>>>8&255,r[3]=255&a,r[4]=(a=parseInt(e.slice(9,13),16))>>>8,r[5]=255&a,r[6]=(a=parseInt(e.slice(14,18),16))>>>8,r[7]=255&a,r[8]=(a=parseInt(e.slice(19,23),16))>>>8,r[9]=255&a,r[10]=(a=parseInt(e.slice(24,36),16))/1099511627776&255,r[11]=a/4294967296&255,r[12]=a>>>24&255,r[13]=a>>>16&255,r[14]=a>>>8&255,r[15]=255&a,r};function m(e,a,r){function t(e,t,s,l){var d;if("string"==typeof e&&(e=function(e){e=unescape(encodeURIComponent(e));let a=[];for(let r=0;r<e.length;++r)a.push(e.charCodeAt(r));return a}(e)),"string"==typeof t&&(t=E(t)),(null===(d=t)||void 0===d?void 0:d.length)!==16)throw TypeError("Namespace must be array-like (16 iterable integer values, 0-255)");let i=new Uint8Array(16+e.length);if(i.set(t),i.set(e,t.length),(i=r(i))[6]=15&i[6]|a,i[8]=63&i[8]|128,s){l=l||0;for(let e=0;e<16;++e)s[l+e]=i[e];return s}return(0,n.S)(i)}try{t.name=e}catch(e){}return t.DNS="6ba7b810-9dad-11d1-80b4-00c04fd430c8",t.URL="6ba7b811-9dad-11d1-80b4-00c04fd430c8",t}var N=r(84770),I=r.n(N);let c=m("v3",48,function(e){return Array.isArray(e)?e=Buffer.from(e):"string"==typeof e&&(e=Buffer.from(e,"utf8")),I().createHash("md5").update(e).digest()});var f=r(56573);let p=m("v5",80,function(e){return Array.isArray(e)?e=Buffer.from(e):"string"==typeof e&&(e=Buffer.from(e,"utf8")),I().createHash("sha1").update(e).digest()}),R="00000000-0000-0000-0000-000000000000",y=function(e){if(!(0,u.Z)(e))throw TypeError("Invalid UUID");return parseInt(e.slice(14,15),16)}},6649:(e,a,r)=>{r.d(a,{Z:()=>d});var t=r(84770),s=r.n(t);let l=new Uint8Array(256),n=l.length;function d(){return n>l.length-16&&(s().randomFillSync(l),n=0),l.slice(n,n+=16)}},16099:(e,a,r)=>{r.d(a,{S:()=>l,Z:()=>n});var t=r(30900);let s=[];for(let e=0;e<256;++e)s.push((e+256).toString(16).slice(1));function l(e,a=0){return s[e[a+0]]+s[e[a+1]]+s[e[a+2]]+s[e[a+3]]+"-"+s[e[a+4]]+s[e[a+5]]+"-"+s[e[a+6]]+s[e[a+7]]+"-"+s[e[a+8]]+s[e[a+9]]+"-"+s[e[a+10]]+s[e[a+11]]+s[e[a+12]]+s[e[a+13]]+s[e[a+14]]+s[e[a+15]]}let n=function(e,a=0){let r=l(e,a);if(!(0,t.Z)(r))throw TypeError("Stringified UUID is invalid");return r}},56573:(e,a,r)=>{r.d(a,{Z:()=>d});var t=r(84770);let s={randomUUID:r.n(t)().randomUUID};var l=r(6649),n=r(16099);let d=function(e,a,r){if(s.randomUUID&&!a&&!e)return s.randomUUID();let t=(e=e||{}).random||(e.rng||l.Z)();if(t[6]=15&t[6]|64,t[8]=63&t[8]|128,a){r=r||0;for(let e=0;e<16;++e)a[r+e]=t[e];return a}return(0,n.S)(t)}},30900:(e,a,r)=>{r.d(a,{Z:()=>s});let t=/^(?:[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}|00000000-0000-0000-0000-000000000000)$/i,s=function(e){return"string"==typeof e&&t.test(e)}}};